import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

// Common
import Header  from './components/common/Header';
import Sidebar from './components/common/Sidebar';

// Auth
import LoginPage  from './components/auth/LoginPage';
import SignUpPage from './components/auth/SignUpPage';

// Student
import StudentDashboard from './components/student/StudentDashboard';
import StudentProfile   from './components/student/StudentProfile';
import StudentMarks     from './components/student/StudentMarks';
import FocusTimer       from './components/student/FocusTimer';
import MyNotes          from './components/student/MyNotes';

// Mentor (formerly Teacher)
import TeacherDashboard    from './components/teacher/TeacherDashboard';
import StudentProgress     from './components/teacher/StudentProgress';
import TeacherStudentNotes from './components/teacher/TeacherStudentNotes';
import MentorProfile       from './components/mentor/MentorProfile';

// Parent
import ParentDashboard      from './components/parent/ParentDashboard';
import ParentMarks          from './components/parent/ParentMarks';
import ParentAttendance     from './components/parent/ParentAttendance';
import ParentDiscipline     from './components/parent/ParentDiscipline';
import ParentStudentDossier from './components/parent/ParentStudentDossier';

// Quizzes & Assessments
import MentorQuizzes  from './components/mentor/MentorQuizzes';
import StudentQuizzes from './components/student/StudentQuizzes';

// Study Materials & Locker Cart
import { LockerProvider }  from './context/LockerContext';
import StudyMaterialStore  from './components/student/StudyMaterialStore';

// GitHub Search
import GitHubSearch from './components/github/GitHubSearch';

// 404
import NotFound from './pages/NotFound';

// Academic SVG Icons
import {
  DashboardIcon,
  ProfileIcon,
  MarksIcon,
  TimerIcon,
  NotesIcon,
  GithubIcon,
  MenteeRosterIcon,
  AttendanceIcon,
  DisciplineAlertIcon,
  QuizIcon,
  LockerIcon,
} from './components/common/Icons';

// ─── Nav config per role ──────────────────────────────────────────────────────
const MENTOR_NAV = [
  { id: 'dashboard',     label: 'Dashboard',       icon: <DashboardIcon size={18} />,    path: '/mentor/dashboard'     },
  { id: 'profile',       label: 'Mentor Profile',  icon: <ProfileIcon size={18} />,      path: '/mentor/profile'       },
  { id: 'progress',      label: 'Mentee Progress', icon: <MenteeRosterIcon size={18} />, path: '/mentor/progress'      },
  { id: 'quizzes',       label: 'Quiz Management', icon: <QuizIcon size={18} />,         path: '/mentor/quizzes'       },
  { id: 'student-notes', label: 'Mentee Notes',    icon: <NotesIcon size={18} />,        path: '/mentor/student-notes' },
  { id: 'github',        label: 'GitHub Search',   icon: <GithubIcon size={18} />,       path: '/mentor/github'        },
];

const NAV_CONFIG = {
  Student: [
    { id: 'dashboard', label: 'Dashboard',    icon: <DashboardIcon size={18} />, path: '/student/dashboard' },
    { id: 'profile',   label: 'Profile',       icon: <ProfileIcon size={18} />,   path: '/student/profile'   },
    { id: 'marks',     label: 'My Marks',      icon: <MarksIcon size={18} />,     path: '/student/marks'     },
    { id: 'quizzes',   label: 'Quizzes',       icon: <QuizIcon size={18} />,      path: '/student/quizzes'   },
    { id: 'materials', label: 'Study Locker',  icon: <LockerIcon size={18} />,    path: '/student/materials' },
    { id: 'timer',     label: 'Focus Timer',   icon: <TimerIcon size={18} />,     path: '/student/timer'     },
    { id: 'notes',     label: 'Notes',         icon: <NotesIcon size={18} />,     path: '/student/notes'     },
    { id: 'github',    label: 'GitHub Search', icon: <GithubIcon size={18} />,    path: '/student/github'    },
  ],
  Mentor:  MENTOR_NAV,
  Teacher: MENTOR_NAV,
  Faculty: MENTOR_NAV,
  Parent: [
    { id: 'dashboard',  label: 'Dashboard',             icon: <DashboardIcon size={18} />,     path: '/parent/dashboard'  },
    { id: 'attendance', label: 'Attendance & Classes',  icon: <AttendanceIcon size={18} />,    path: '/parent/attendance' },
    { id: 'discipline', label: 'Discipline & UMC',      icon: <DisciplineAlertIcon size={18} />,path: '/parent/discipline' },
    { id: 'marks',      label: "Child's Marks",         icon: <MarksIcon size={18} />,         path: '/parent/marks'      },
    { id: 'profile',    label: 'Student Details',       icon: <ProfileIcon size={18} />,       path: '/parent/profile'    },
  ],
};

// ─── Protected Route wrapper with role verification ───────────────────────────
function ProtectedRoute({ children, allowedRole }) {
  const { currentUser, userRole } = useAuth();
  if (!currentUser) return <Navigate to="/login" replace />;

  if (allowedRole) {
    const currentNormalized = (userRole === 'Teacher' || userRole === 'Faculty') ? 'Mentor' : userRole;
    const allowedNormalized = (allowedRole === 'Teacher' || allowedRole === 'Faculty') ? 'Mentor' : allowedRole;

    if (currentNormalized !== allowedNormalized) {
      return <RoleRedirect />;
    }
  }

  return children;
}

// ─── Default redirect after login ────────────────────────────────────────────
function RoleRedirect() {
  const { userRole } = useAuth();
  if (userRole === 'Student')                                     return <Navigate to="/student/dashboard" replace />;
  if (userRole === 'Mentor' || userRole === 'Teacher' || userRole === 'Faculty') return <Navigate to="/mentor/dashboard"  replace />;
  if (userRole === 'Parent')                                      return <Navigate to="/parent/dashboard"   replace />;
  return <Navigate to="/login" replace />;
}

// ─── Shell layout (sidebar + header + content) ───────────────────────────────
function AppShell({ children, title }) {
  const { currentUser, userRole } = useAuth();
  const navItems = NAV_CONFIG[userRole] || NAV_CONFIG.Mentor || [];

  return (
    <div className="app-container">
      <Sidebar navItems={navItems} />
      <div className="main-wrapper">
        <Header user={currentUser} title={title} />
        <main className="main-content">{children}</main>
      </div>
    </div>
  );
}

// ─── Route tree ──────────────────────────────────────────────────────────────
function AppRoutes() {
  const { currentUser } = useAuth();

  return (
    <Routes>
      {/* Public */}
      <Route
        path="/login"
        element={currentUser ? <RoleRedirect /> : <LoginPage />}
      />
      <Route
        path="/signup"
        element={currentUser ? <RoleRedirect /> : <SignUpPage />}
      />

      {/* Student routes */}
      <Route path="/student/dashboard"  element={<ProtectedRoute allowedRole="Student"><AppShell title="🏠 Student Dashboard"><StudentDashboard user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/student/profile"    element={<ProtectedRoute allowedRole="Student"><AppShell title="👤 Student Profile"><StudentProfile user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/student/marks"      element={<ProtectedRoute allowedRole="Student"><AppShell title="📊 Semester Course Marks"><StudentMarks /></AppShell></ProtectedRoute>} />
      <Route path="/student/quizzes"    element={<ProtectedRoute allowedRole="Student"><AppShell title="📝 Course Quizzes & Assessments"><StudentQuizzes user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/student/materials"  element={<ProtectedRoute allowedRole="Student"><AppShell title="📚 Course Study Materials & Locker"><StudyMaterialStore /></AppShell></ProtectedRoute>} />
      <Route path="/student/timer"      element={<ProtectedRoute allowedRole="Student"><AppShell title="⏱️ Focus Study Timer"><FocusTimer /></AppShell></ProtectedRoute>} />
      <Route path="/student/notes"      element={<ProtectedRoute allowedRole="Student"><AppShell title="📝 Notes"><MyNotes user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/student/github"     element={<ProtectedRoute allowedRole="Student"><AppShell title="🐙 Developer GitHub Search"><GitHubSearch /></AppShell></ProtectedRoute>} />

      {/* Mentor routes */}
      <Route path="/mentor/dashboard"      element={<ProtectedRoute allowedRole="Mentor"><AppShell title="🏠 Mentor Dashboard"><TeacherDashboard user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/mentor/profile"        element={<ProtectedRoute allowedRole="Mentor"><AppShell title="👤 Mentor Profile"><MentorProfile user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/mentor/progress"       element={<ProtectedRoute allowedRole="Mentor"><AppShell title="📊 Mentee Progress Roster"><StudentProgress /></AppShell></ProtectedRoute>} />
      <Route path="/mentor/quizzes"        element={<ProtectedRoute allowedRole="Mentor"><AppShell title="📝 Faculty Quiz & Assessment Manager"><MentorQuizzes user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/mentor/student-notes"  element={<ProtectedRoute allowedRole="Mentor"><AppShell title="📋 Mentee Guidance Notes"><TeacherStudentNotes user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/mentor/github"         element={<ProtectedRoute allowedRole="Mentor"><AppShell title="🐙 Developer GitHub Search"><GitHubSearch /></AppShell></ProtectedRoute>} />

      {/* Backwards-compatible aliases for /teacher/* */}
      <Route path="/teacher/dashboard"     element={<Navigate to="/mentor/dashboard" replace />} />
      <Route path="/teacher/profile"       element={<Navigate to="/mentor/profile" replace />} />
      <Route path="/teacher/progress"      element={<Navigate to="/mentor/progress" replace />} />
      <Route path="/teacher/quizzes"       element={<Navigate to="/mentor/quizzes" replace />} />
      <Route path="/teacher/student-notes" element={<Navigate to="/mentor/student-notes" replace />} />
      <Route path="/teacher/github"        element={<Navigate to="/mentor/github" replace />} />

      {/* Parent routes */}
      <Route path="/parent/dashboard"  element={<ProtectedRoute allowedRole="Parent"><AppShell title="🏠 Parent Dashboard"><ParentDashboard user={currentUser} /></AppShell></ProtectedRoute>} />
      <Route path="/parent/attendance" element={<ProtectedRoute allowedRole="Parent"><AppShell title="📅 Class Attendance & Shortage"><ParentAttendance /></AppShell></ProtectedRoute>} />
      <Route path="/parent/discipline" element={<ProtectedRoute allowedRole="Parent"><AppShell title="⚖️ Disciplinary Actions & UMC Records"><ParentDiscipline /></AppShell></ProtectedRoute>} />
      <Route path="/parent/marks"      element={<ProtectedRoute allowedRole="Parent"><AppShell title="📊 Semester Academic Performance"><ParentMarks /></AppShell></ProtectedRoute>} />
      <Route path="/parent/profile"    element={<ProtectedRoute allowedRole="Parent"><AppShell title="👤 Comprehensive Student Dossier"><ParentStudentDossier /></AppShell></ProtectedRoute>} />

      {/* Root redirect */}
      <Route path="/" element={<RoleRedirect />} />

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

// ─── Root export ──────────────────────────────────────────────────────────────
function App() {
  return (
    <AuthProvider>
      <LockerProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </LockerProvider>
    </AuthProvider>
  );
}

export default App;
