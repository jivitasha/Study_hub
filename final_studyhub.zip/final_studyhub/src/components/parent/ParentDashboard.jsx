import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  STUDENT_COMPREHENSIVE_DOSSIER,
  STUDENT_ATTENDANCE_SUMMARY,
  STUDENT_UMC_DISCIPLINE_RECORDS,
  INITIAL_TEACHER_FEEDBACK,
} from '../../data/mockData';
import ProgressBar from '../common/ProgressBar';

const MENTOR_NOTES_STORAGE_KEY = 'studysphere_mentor_notes';

function ParentDashboard({ user }) {
  const student = STUDENT_COMPREHENSIVE_DOSSIER.personal;
  const academic = STUDENT_COMPREHENSIVE_DOSSIER.academicStanding;
  const mentor = STUDENT_COMPREHENSIVE_DOSSIER.mentor;
  const attendance = STUDENT_ATTENDANCE_SUMMARY;
  const activeUMC = STUDENT_UMC_DISCIPLINE_RECORDS.find((r) => r.currentStatus === 'Active Penalty Imposed');

  // Sync mentor notes in real-time
  const [mentorNotes, setMentorNotes] = useState(() => {
    try {
      const saved = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : INITIAL_TEACHER_FEEDBACK;
    } catch {
      return INITIAL_TEACHER_FEEDBACK;
    }
  });

  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
        if (saved) setMentorNotes(JSON.parse(saved));
      } catch {
        // fallback
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const isLowAttendance = attendance.overallPercentage < attendance.minimumRequired;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Parent Welcome Header */}
      <section className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              👨‍👩‍👦 Parent Academic &amp; Conduct Monitoring Portal
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Logged in as: <strong>{user?.name || 'Mr. Rajesh Sharma'}</strong> (Parent of {student.fullName})
            </p>
          </div>
          <span className="badge badge-ontrack" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>
            🔒 Official University Parent View
          </span>
        </div>
      </section>

      {/* ⚠️ HIGH-PRIORITY PARENTAL ACTION ALERTS */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
        {/* 1. Low Attendance Alert */}
        {isLowAttendance && (
          <div
            className="card"
            style={{
              backgroundColor: '#fff1f2',
              border: '2px solid #f43f5e',
              padding: '18px 20px',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '14px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div style={{ fontSize: '2rem' }}>⚠️</div>
              <div>
                <h4 style={{ margin: '0 0 4px 0', color: '#9f1239', fontSize: '1.1rem' }}>
                  Critical Attendance Shortage ({attendance.overallPercentage}% vs 75% Cutoff)
                </h4>
                <p style={{ margin: 0, fontSize: '0.88rem', color: '#881337' }}>
                  {student.fullName} is currently at risk of being debarred from Semester 6 examinations in 2 courses.
                </p>
              </div>
            </div>
            <Link
              to="/parent/attendance"
              className="btn-primary"
              style={{ width: 'auto', backgroundColor: '#e11d48', borderColor: '#e11d48', fontSize: '0.85rem', textDecoration: 'none' }}
            >
              📅 View Class Attendance &amp; Shortage →
            </Link>
          </div>
        )}

        {/* 2. UMC Disciplinary Action Alert */}
        {activeUMC && (
          <div
            className="card"
            style={{
              backgroundColor: '#fef2f2',
              border: '2px solid #ef4444',
              padding: '18px 20px',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '14px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div style={{ fontSize: '2rem' }}>⚖️</div>
              <div>
                <h4 style={{ margin: '0 0 4px 0', color: '#991b1b', fontSize: '1.1rem' }}>
                  Active Disciplinary / UMC Penalty on Record ({activeUMC.id})
                </h4>
                <p style={{ margin: 0, fontSize: '0.88rem', color: '#7f1d1d' }}>
                  Action taken: {activeUMC.actionTaken} Parent-proctor meeting required with Mentor {mentor.name}.
                </p>
              </div>
            </div>
            <Link
              to="/parent/discipline"
              className="btn-primary"
              style={{ width: 'auto', backgroundColor: '#dc2626', borderColor: '#dc2626', fontSize: '0.85rem', textDecoration: 'none' }}
            >
              ⚖️ View UMC Case Details &amp; Penalty →
            </Link>
          </div>
        )}
      </div>

      {/* Child Academic Overview Card */}
      <section className="card">
        <h3 style={{ color: 'var(--primary-dark)', marginBottom: '14px', fontSize: '1.25rem' }}>
          🧒 Student Profile &amp; Enrollment Summary
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '16px', fontSize: '0.92rem' }}>
          <div><strong>Student Name:</strong> {student.fullName}</div>
          <div><strong>University Roll No:</strong> {student.universityRollNo}</div>
          <div><strong>Academic Program:</strong> {student.program}</div>
          <div><strong>Semester &amp; Section:</strong> {student.semester} ({student.section})</div>
          <div><strong>Department:</strong> {student.department}</div>
          <div><strong>Batch Mentor:</strong> {mentor.name} ({mentor.cabin})</div>
          <div><strong>Admit Card Status:</strong> <span style={{ color: '#dc2626', fontWeight: 'bold' }}>⛔ On Hold (Action Req.)</span></div>
          <div><strong>Academic Standing:</strong> <span className="badge badge-ontrack">CGPA {academic.cgpa} / 10</span></div>
        </div>
      </section>

      {/* 4-Card Portal Navigation Hub */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '18px' }}>
        {/* Card 1: Attendance */}
        <Link to="/parent/attendance" style={{ textDecoration: 'none' }}>
          <div className="card" style={{ height: '100%', transition: 'transform 0.15s ease', cursor: 'pointer', borderTop: '4px solid #ea580c' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: '1.8rem' }}>📅</div>
              <span style={{ fontSize: '0.78rem', color: '#dc2626', fontWeight: 'bold', backgroundColor: '#fee2e2', padding: '3px 8px', borderRadius: '10px' }}>
                {attendance.overallPercentage}% (Shortage)
              </span>
            </div>
            <h4 style={{ margin: '12px 0 6px 0', color: 'var(--primary-dark)', fontSize: '1.1rem' }}>
              Attendance &amp; Classes
            </h4>
            <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Inspect subject-wise attendance percentages, attended lectures, and low attendance alerts.
            </p>
          </div>
        </Link>

        {/* Card 2: Disciplinary & UMC */}
        <Link to="/parent/discipline" style={{ textDecoration: 'none' }}>
          <div className="card" style={{ height: '100%', transition: 'transform 0.15s ease', cursor: 'pointer', borderTop: '4px solid #dc2626' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: '1.8rem' }}>⚖️</div>
              <span style={{ fontSize: '0.78rem', color: '#dc2626', fontWeight: 'bold', backgroundColor: '#fee2e2', padding: '3px 8px', borderRadius: '10px' }}>
                1 Active UMC
              </span>
            </div>
            <h4 style={{ margin: '12px 0 6px 0', color: 'var(--primary-dark)', fontSize: '1.1rem' }}>
              Discipline &amp; UMC
            </h4>
            <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Review exam malpractice hearings, actions taken, proctor notices, and hearing schedules.
            </p>
          </div>
        </Link>

        {/* Card 3: Semester Marks */}
        <Link to="/parent/marks" style={{ textDecoration: 'none' }}>
          <div className="card" style={{ height: '100%', transition: 'transform 0.15s ease', cursor: 'pointer', borderTop: '4px solid var(--primary-medium)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: '1.8rem' }}>📊</div>
              <span style={{ fontSize: '0.78rem', color: '#16a34a', fontWeight: 'bold', backgroundColor: '#dcfce7', padding: '3px 8px', borderRadius: '10px' }}>
                90.2% Avg
              </span>
            </div>
            <h4 style={{ margin: '12px 0 6px 0', color: 'var(--primary-dark)', fontSize: '1.1rem' }}>
              Child's Marks &amp; GPA
            </h4>
            <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Official course marksheets, sessional test grades, SGPA/CGPA, and cohort rank.
            </p>
          </div>
        </Link>

        {/* Card 4: Full Dossier */}
        <Link to="/parent/profile" style={{ textDecoration: 'none' }}>
          <div className="card" style={{ height: '100%', transition: 'transform 0.15s ease', cursor: 'pointer', borderTop: '4px solid #0284c7' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: '1.8rem' }}>👤</div>
              <span style={{ fontSize: '0.78rem', color: '#0284c7', fontWeight: 'bold', backgroundColor: '#e0f2fe', padding: '3px 8px', borderRadius: '10px' }}>
                360° Dossier
              </span>
            </div>
            <h4 style={{ margin: '12px 0 6px 0', color: 'var(--primary-dark)', fontSize: '1.1rem' }}>
              Full Student Details
            </h4>
            <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Comprehensive dossier covering fees, clearances, mentor contact, and institutional records.
            </p>
          </div>
        </Link>
      </div>

      {/* Mentor Guidance Notes (Read-Only Feed for Parents) */}
      <section className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <h3 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.25rem' }}>
            👨‍🏫 Faculty Mentor Academic Guidance &amp; Observations
          </h3>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Real-time feed from College Faculty
          </span>
        </div>

        <div className="notes-grid">
          {mentorNotes.map((note) => (
            <article key={note.id} className="note-card" style={{ borderLeft: '4px solid var(--primary-medium)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h4 className="note-card-title" style={{ margin: 0, fontSize: '1rem', color: 'var(--primary-dark)' }}>
                  📚 {note.subject}
                </h4>
                <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>📅 {note.date}</span>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '4px', fontWeight: '500' }}>
                Mentor: {note.mentorName || 'Dr. Ramesh Verma'}
              </div>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-primary)', marginTop: '8px', lineHeight: '1.5', fontStyle: 'italic', backgroundColor: 'var(--accent-cream)', padding: '10px 12px', borderRadius: '6px' }}>
                "{note.text}"
              </p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

export default ParentDashboard;
