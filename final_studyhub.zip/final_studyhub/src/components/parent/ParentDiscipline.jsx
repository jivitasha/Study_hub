import React, { useState } from 'react';
import {
  STUDENT_UMC_DISCIPLINE_RECORDS,
  STUDENT_COMPREHENSIVE_DOSSIER,
} from '../../data/mockData';
import Toast from '../common/Toast';
import Modal from '../common/Modal';

/**
 * ParentDiscipline Component
 * Dedicated parent view for disciplinary records, Unfair Means Cases (UMC),
 * exam committee verdicts, and proctorial action items.
 */
function ParentDiscipline() {
  const [toast, setToast] = useState(null);
  const [selectedCase, setSelectedCase] = useState(null);

  const student = STUDENT_COMPREHENSIVE_DOSSIER.personal;
  const mentor = STUDENT_COMPREHENSIVE_DOSSIER.mentor;
  const records = STUDENT_UMC_DISCIPLINE_RECORDS;

  const activeUMCCase = records.find((r) => r.currentStatus === 'Active Penalty Imposed');

  const handleDownloadNotice = (caseItem) => {
    setSelectedCase(caseItem);
  };

  const handleScheduleMeeting = () => {
    setToast({
      message: `Meeting request with Mentor ${mentor.name} forwarded to Academic Proctor Office. 📅`,
      type: 'info',
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid #dc2626' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              ⚖️ Disciplinary Actions &amp; UMC Case Portal
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Official records of Unfair Means Cases (UMC), examination committee verdicts, and proctorial notices for <strong>{student.fullName}</strong> ({student.universityRollNo}).
            </p>
          </div>
          <div>
            <span
              style={{
                padding: '6px 14px',
                borderRadius: '20px',
                fontSize: '0.85rem',
                fontWeight: '700',
                backgroundColor: activeUMCCase ? '#fee2e2' : '#dcfce7',
                color: activeUMCCase ? '#b91c1c' : '#15803d',
                border: `1px solid ${activeUMCCase ? '#f87171' : '#86efac'}`,
              }}
            >
              {activeUMCCase ? '⚠️ Active Disciplinary Case On File' : '✅ Clean Conduct Record'}
            </span>
          </div>
        </div>
      </div>

      {/* High-Priority UMC Action Alert Card */}
      {activeUMCCase && (
        <div
          className="card"
          style={{
            backgroundColor: '#fef2f2',
            border: '2px solid #ef4444',
            borderRadius: '12px',
            padding: '22px',
            boxShadow: '0 6px 18px rgba(239, 68, 68, 0.15)',
          }}
        >
          <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <div style={{ fontSize: '2.5rem', lineHeight: 1 }}>🚨</div>
            <div style={{ flex: 1, minWidth: '280px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                <h3 style={{ margin: 0, color: '#991b1b', fontSize: '1.35rem' }}>
                  URGENT: Active Unfair Means Case ({activeUMCCase.id})
                </h3>
                <span style={{ fontSize: '0.8rem', backgroundColor: '#dc2626', color: '#ffffff', padding: '4px 10px', borderRadius: '12px', fontWeight: 'bold' }}>
                  Exam Board Penalty Imposed
                </span>
              </div>

              <div style={{ marginTop: '12px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '10px', fontSize: '0.9rem', color: '#7f1d1d' }}>
                <div><strong>Examination:</strong> {activeUMCCase.examination}</div>
                <div><strong>Subject:</strong> {activeUMCCase.subject}</div>
                <div><strong>Incident Date:</strong> {activeUMCCase.incidentDate}</div>
                <div><strong>Reporting Officer:</strong> {activeUMCCase.reportedBy}</div>
              </div>

              <div style={{ marginTop: '14px', backgroundColor: '#ffffff', padding: '14px', borderRadius: '8px', border: '1px solid #fca5a5' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 'bold', color: '#991b1b', textTransform: 'uppercase' }}>
                  Nature of Violation / Charge:
                </div>
                <div style={{ fontSize: '0.92rem', color: '#1f2937', marginTop: '4px' }}>
                  "{activeUMCCase.charges}"
                </div>

                <div style={{ fontSize: '0.85rem', fontWeight: 'bold', color: '#991b1b', textTransform: 'uppercase', marginTop: '10px' }}>
                  Action / Penalty Taken:
                </div>
                <div style={{ fontSize: '0.92rem', color: '#b91c1c', fontWeight: '600', marginTop: '4px' }}>
                  "{activeUMCCase.actionTaken}"
                </div>
              </div>

              {/* Action Required from Parent */}
              <div style={{ marginTop: '14px', backgroundColor: '#fff7ed', borderLeft: '4px solid #ea580c', padding: '12px 14px', borderRadius: '4px' }}>
                <div style={{ fontWeight: 'bold', color: '#9a3412', fontSize: '0.9rem' }}>
                  📌 Required Parental Action:
                </div>
                <div style={{ color: '#7c2d12', fontSize: '0.9rem', marginTop: '4px' }}>
                  {activeUMCCase.parentActionRequired}
                </div>
                <div style={{ marginTop: '10px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                  <button
                    type="button"
                    className="btn-primary"
                    style={{ width: 'auto', backgroundColor: '#ea580c', borderColor: '#ea580c', fontSize: '0.85rem' }}
                    onClick={handleScheduleMeeting}
                  >
                    📅 Confirm Mentor Consultation ({mentor.consultationHours})
                  </button>
                  <button
                    type="button"
                    className="btn-secondary"
                    style={{ width: 'auto', fontSize: '0.85rem' }}
                    onClick={() => handleDownloadNotice(activeUMCCase)}
                  >
                    📄 Download Official UMC Notice PDF
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Disciplinary Clearance & Admit Card Status Banner */}
      <div className="card">
        <h3 style={{ margin: '0 0 14px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
          🛡️ Examination Clearance &amp; Admit Card Release Status
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
          <div style={{ padding: '14px', borderRadius: '8px', backgroundColor: '#f8fafc', border: '1px solid var(--border-color)' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>End-Sem Admit Card</div>
            <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: '#dc2626', marginTop: '4px' }}>
              ⛔ ON HOLD
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
              Requires UMC Committee Clearance &amp; Attendance Shortage Waiver
            </div>
          </div>

          <div style={{ padding: '14px', borderRadius: '8px', backgroundColor: '#f8fafc', border: '1px solid var(--border-color)' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Conduct Grade</div>
            <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: '#ea580c', marginTop: '4px' }}>
              C (Under Observation)
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
              Proctorial board review pending for Semester 6
            </div>
          </div>

          <div style={{ padding: '14px', borderRadius: '8px', backgroundColor: '#f8fafc', border: '1px solid var(--border-color)' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Designated Proctor</div>
            <div style={{ fontSize: '1.05rem', fontWeight: 'bold', color: 'var(--primary-dark)', marginTop: '4px' }}>
              {mentor.name}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
              {mentor.cabin} | {mentor.phone}
            </div>
          </div>
        </div>
      </div>

      {/* Complete Historical Disciplinary & Warning Register */}
      <section className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <div>
            <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
              📋 Official University Disciplinary Record History
            </h3>
            <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontSize: '0.88rem' }}>
              All documented infractions, hearings, and official notices issued during degree enrollment.
            </p>
          </div>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Total Cases: <strong>{records.length}</strong>
          </span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {records.map((item) => {
            const isActive = item.currentStatus === 'Active Penalty Imposed';
            return (
              <article
                key={item.id}
                style={{
                  border: `1px solid ${isActive ? '#f87171' : 'var(--border-color)'}`,
                  borderLeft: `6px solid ${isActive ? '#dc2626' : '#64748b'}`,
                  borderRadius: '8px',
                  padding: '18px',
                  backgroundColor: isActive ? '#fffcfc' : 'var(--bg-white)',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                    <span style={{ fontWeight: 'bold', fontSize: '1.1rem', color: 'var(--primary-dark)' }}>
                      {item.id}
                    </span>
                    <span
                      style={{
                        padding: '3px 8px',
                        borderRadius: '6px',
                        fontSize: '0.75rem',
                        fontWeight: '700',
                        backgroundColor: isActive ? '#fee2e2' : '#f1f5f9',
                        color: isActive ? '#b91c1c' : '#475569',
                      }}
                    >
                      {item.caseType}
                    </span>
                  </div>
                  <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                    📅 Incident Date: <strong>{item.incidentDate}</strong>
                  </span>
                </div>

                <div style={{ marginTop: '12px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '8px', fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                  <div><strong>Course / Exam:</strong> {item.subject}</div>
                  <div><strong>Venue:</strong> {item.examHall}</div>
                  <div><strong>Reported By:</strong> {item.reportedBy}</div>
                  <div><strong>Status:</strong> <span style={{ fontWeight: 'bold', color: isActive ? '#dc2626' : '#16a34a' }}>{item.currentStatus}</span></div>
                </div>

                <div style={{ marginTop: '12px', fontSize: '0.9rem', color: 'var(--text-primary)', backgroundColor: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                  <div><strong>Charge:</strong> {item.charges}</div>
                  <div style={{ marginTop: '6px', color: '#b91c1c' }}><strong>Penalty &amp; Action:</strong> {item.actionTaken}</div>
                  <div style={{ marginTop: '6px', fontSize: '0.85rem', color: 'var(--text-secondary)' }}><strong>Committee Verdict:</strong> {item.committeeVerdict}</div>
                </div>

                <div style={{ marginTop: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    Issued by: {item.issuedBy}
                  </span>
                  <button
                    type="button"
                    className="btn-secondary"
                    style={{ width: 'auto', fontSize: '0.8rem', padding: '5px 12px' }}
                    onClick={() => handleDownloadNotice(item)}
                  >
                    📥 Download Order Letter
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* University UMC Regulations Excerpt */}
      <div className="card" style={{ backgroundColor: '#f8fafc', borderLeft: '4px solid #dc2626', padding: '16px 20px' }}>
        <h4 style={{ margin: '0 0 6px 0', color: '#991b1b', fontSize: '0.95rem' }}>
          ⚖️ Examination Code of Conduct (UMC Ordinance Section 9)
        </h4>
        <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
          Any candidate found in possession of unauthorized books, notes, digital electronics, or mobile devices in the examination hall, whether used or unused, is liable for booking under Unfair Means (UMC Category II). Penalties include cancellation of the relevant examination paper and debarment from supplementary sessions until personal representation before the Proctorial Disciplinary Committee.
        </p>
      </div>

      {/* Official UMC Document Modal */}
      <Modal
        isOpen={Boolean(selectedCase)}
        onClose={() => setSelectedCase(null)}
        title={selectedCase ? `Official Proctorial Order: ${selectedCase.id}` : 'Order Notice'}
        maxWidth="680px"
        footer={
          <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Printed from Controller of Examinations Registry
            </span>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                type="button"
                className="btn-secondary"
                style={{ width: 'auto', fontSize: '0.85rem' }}
                onClick={() => setSelectedCase(null)}
              >
                Close
              </button>
              <button
                type="button"
                className="btn-primary"
                style={{ width: 'auto', fontSize: '0.85rem' }}
                onClick={() => {
                  window.print();
                }}
              >
                🖨️ Print Order Letter
              </button>
            </div>
          </div>
        }
      >
        {selectedCase && (
          <div style={{ fontSize: '0.92rem', color: '#1e293b', lineHeight: 1.6 }}>
            {/* Letterhead */}
            <div style={{ textAlign: 'center', borderBottom: '2px solid #0f172a', paddingBottom: '12px', marginBottom: '16px' }}>
              <div style={{ fontWeight: 'bold', fontSize: '1.2rem', color: 'var(--primary-dark)', textTransform: 'uppercase' }}>
                StudySphere University Institute of Technology
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                Office of the Chief Proctor &amp; Controller of Examinations
              </div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                Ref No: UIT/EXAM/UMC/2026/042 · Date: {selectedCase.incidentDate}
              </div>
            </div>

            {/* Recipient */}
            <div style={{ marginBottom: '14px' }}>
              <div><strong>To:</strong> Mr. Rajesh Sharma (Parent / Guardian)</div>
              <div><strong>Ward:</strong> {student.fullName} (Roll No: {student.universityRollNo}, Program: {student.program})</div>
            </div>

            {/* Subject */}
            <div style={{ backgroundColor: '#f1f5f9', padding: '10px', borderRadius: '6px', fontWeight: 'bold', marginBottom: '14px', color: '#991b1b' }}>
              Subject: Formal Notice Regarding Unfair Means Case (UMC) under Examination Ordinance
            </div>

            {/* Body */}
            <p>
              Sir/Madam, this is to formally bring to your attention that during the <strong>{selectedCase.examination}</strong> conducted on <strong>{selectedCase.incidentDate}</strong> for course <strong>{selectedCase.subject}</strong> in <strong>{selectedCase.examHall}</strong>, candidate <strong>{student.fullName}</strong> was booked under the University Malpractice Code.
            </p>

            <div style={{ backgroundColor: '#fff5f5', borderLeft: '4px solid #dc2626', padding: '12px', borderRadius: '4px', margin: '14px 0' }}>
              <div><strong>Charge Alleged:</strong> {selectedCase.charges}</div>
              <div style={{ marginTop: '6px' }}><strong>Investigating Officer:</strong> {selectedCase.reportedBy}</div>
              <div style={{ marginTop: '6px' }}><strong>Proctorial Board Verdict:</strong> {selectedCase.committeeVerdict}</div>
              <div style={{ marginTop: '6px', color: '#dc2626', fontWeight: 'bold' }}><strong>Penalty Imposed:</strong> {selectedCase.actionTaken}</div>
            </div>

            <p style={{ fontWeight: '600', color: '#9a3412' }}>
              📌 Directive: You are requested to attend a mandatory proctorial counseling conference with Batch Mentor {mentor.name} ({mentor.cabin}) before the student's admit card for Semester End Examinations can be released.
            </p>

            <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #e2e8f0', paddingTop: '12px', fontSize: '0.85rem' }}>
              <div>
                <strong>Chief Proctor</strong><br />
                Office of Student Affairs
              </div>
              <div style={{ textAlign: 'right' }}>
                <strong>Controller of Examinations</strong><br />
                UIT Central Examination Cell
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

export default ParentDiscipline;

