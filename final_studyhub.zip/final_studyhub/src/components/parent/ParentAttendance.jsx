import React, { useState } from 'react';
import {
  STUDENT_ATTENDANCE_SUMMARY,
  STUDENT_SUBJECT_ATTENDANCE,
  STUDENT_RECENT_ATTENDANCE_LOG,
  STUDENT_COMPREHENSIVE_DOSSIER,
} from '../../data/mockData';
import ProgressBar from '../common/ProgressBar';

/**
 * ParentAttendance Component
 * Dedicated parent view for monitoring student class attendance,
 * tracking low attendance debarment warnings, and reviewing subject logs.
 */
function ParentAttendance() {
  const [filterSubject, setFilterSubject] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All'); // 'All' | 'Absent' | 'Present'

  const student = STUDENT_COMPREHENSIVE_DOSSIER.personal;
  const summary = STUDENT_ATTENDANCE_SUMMARY;

  const filteredLogs = STUDENT_RECENT_ATTENDANCE_LOG.filter((log) => {
    const matchSub = filterSubject === 'All' || log.subject === filterSubject;
    const matchStatus = statusFilter === 'All' || log.status === statusFilter;
    return matchSub && matchStatus;
  });

  const isLowAttendance = summary.overallPercentage < summary.minimumRequired;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              📅 Class Attendance &amp; Lecture Register
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Student: <strong>{student.fullName}</strong> ({student.universityRollNo}) | {student.program} - {student.semester}
            </p>
          </div>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <span
              style={{
                padding: '6px 14px',
                borderRadius: '20px',
                fontSize: '0.85rem',
                fontWeight: '700',
                backgroundColor: isLowAttendance ? '#fee2e2' : '#dcfce7',
                color: isLowAttendance ? '#b91c1c' : '#15803d',
                border: `1px solid ${isLowAttendance ? '#f87171' : '#86efac'}`,
              }}
            >
              {isLowAttendance ? '⚠️ Low Attendance Shortage' : '✅ Attendance On Track'}
            </span>
          </div>
        </div>
      </div>

      {/* Critical Low Attendance Warning Alert */}
      {isLowAttendance && (
        <div
          className="card"
          style={{
            backgroundColor: '#fff1f2',
            border: '2px solid #f43f5e',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: '0 4px 12px rgba(244, 63, 94, 0.12)',
          }}
        >
          <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
            <div style={{ fontSize: '2rem', lineHeight: 1 }}>🚨</div>
            <div style={{ flex: 1 }}>
              <h3 style={{ margin: '0 0 6px 0', color: '#9f1239', fontSize: '1.25rem' }}>
                Action Required: Attendance Shortage Alert ({summary.overallPercentage}% vs {summary.minimumRequired}% Mandatory)
              </h3>
              <p style={{ margin: '0 0 10px 0', color: '#881337', fontSize: '0.95rem', lineHeight: '1.6' }}>
                Your ward <strong>{student.fullName}</strong> has fallen below the university's mandatory{' '}
                <strong>75.0% attendance requirement</strong>. If attendance is not improved immediately, the student will be{' '}
                <strong>Debarred from End-Semester Examinations</strong>.
              </p>
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px',
                  backgroundColor: '#ffe4e6',
                  padding: '8px 14px',
                  borderRadius: '8px',
                  fontSize: '0.9rem',
                  fontWeight: '600',
                  color: '#9f1239',
                }}
              >
                ⚡ <strong>Shortage Recovery:</strong> Must attend at least <strong>{summary.shortageCount} consecutive lectures</strong> without absence.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* High-Level Attendance Stats Cards */}
      <div className="dashboard-grid">
        <article className="card" style={{ borderLeft: '4px solid var(--primary-medium)' }}>
          <div className="stat-card-lbl">📊 Aggregate Attendance</div>
          <div
            className="stat-card-val"
            style={{ color: isLowAttendance ? '#dc2626' : 'var(--primary-dark)', fontSize: '2rem' }}
          >
            {summary.overallPercentage}%
          </div>
          <div style={{ marginTop: '8px' }}>
            <ProgressBar percentage={summary.overallPercentage} height="8px" />
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '6px' }}>
            Min. University Cutoff: 75.0%
          </div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">🏫 Total Conducted Classes</div>
          <div className="stat-card-val" style={{ color: 'var(--primary-dark)', fontSize: '2rem' }}>
            {summary.totalConducted}
          </div>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '8px' }}>
            Sem 6 Lectures &amp; Labs Held
          </div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">✅ Classes Attended</div>
          <div className="stat-card-val" style={{ color: '#16a34a', fontSize: '2rem' }}>
            {summary.totalAttended}
          </div>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '8px' }}>
            Verified biometric + faculty marks
          </div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">❌ Classes Absent / Missed</div>
          <div className="stat-card-val" style={{ color: '#dc2626', fontSize: '2rem' }}>
            {summary.totalAbsent}
          </div>
          <div style={{ fontSize: '0.85rem', color: '#b91c1c', marginTop: '8px', fontWeight: '500' }}>
            {summary.shortageCount} classes deficit for 75%
          </div>
        </article>
      </div>

      {/* Subject-Wise Attendance Breakdown Table */}
      <section className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <div>
            <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
              📚 Subject-Wise Attendance &amp; Shortage Status
            </h3>
            <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontSize: '0.88rem' }}>
              Detailed compliance for each theory course and laboratory session.
            </p>
          </div>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Updated as of: <strong>{summary.lastUpdated}</strong>
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="custom-table" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '2px solid var(--border-color)' }}>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem' }}>Course Code &amp; Subject</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem' }}>Faculty</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem', textAlign: 'center' }}>Held</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem', textAlign: 'center' }}>Attended</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem', textAlign: 'center' }}>Absent</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem', minWidth: '160px' }}>Attendance %</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem', textAlign: 'center' }}>Eligibility Status</th>
                <th style={{ padding: '12px 14px', fontSize: '0.85rem' }}>Shortage Action</th>
              </tr>
            </thead>
            <tbody>
              {STUDENT_SUBJECT_ATTENDANCE.map((sub) => {
                const isShort = sub.percentage < 75.0;
                return (
                  <tr
                    key={sub.id}
                    style={{
                      borderBottom: '1px solid var(--border-color)',
                      backgroundColor: isShort ? '#fff8f8' : 'transparent',
                    }}
                  >
                    <td style={{ padding: '14px' }}>
                      <div style={{ fontWeight: 'bold', color: 'var(--primary-dark)' }}>{sub.subject}</div>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{sub.code}</div>
                    </td>
                    <td style={{ padding: '14px', fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                      {sub.faculty}
                    </td>
                    <td style={{ padding: '14px', textAlign: 'center', fontWeight: '500' }}>{sub.conducted}</td>
                    <td style={{ padding: '14px', textAlign: 'center', fontWeight: 'bold', color: '#16a34a' }}>
                      {sub.attended}
                    </td>
                    <td style={{ padding: '14px', textAlign: 'center', fontWeight: 'bold', color: isShort ? '#dc2626' : 'var(--text-muted)' }}>
                      {sub.absent}
                    </td>
                    <td style={{ padding: '14px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', fontWeight: 'bold', marginBottom: '4px' }}>
                        <span style={{ color: isShort ? '#dc2626' : '#16a34a' }}>{sub.percentage}%</span>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Req: 75%</span>
                      </div>
                      <ProgressBar percentage={sub.percentage} height="6px" />
                    </td>
                    <td style={{ padding: '14px', textAlign: 'center' }}>
                      <span
                        style={{
                          padding: '4px 10px',
                          borderRadius: '12px',
                          fontSize: '0.78rem',
                          fontWeight: '700',
                          backgroundColor: isShort ? '#fee2e2' : '#dcfce7',
                          color: isShort ? '#b91c1c' : '#15803d',
                          display: 'inline-block',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {isShort ? '❌ Debarred Risk' : '✅ Eligible'}
                      </span>
                    </td>
                    <td style={{ padding: '14px', fontSize: '0.82rem' }}>
                      {isShort ? (
                        <span style={{ color: '#dc2626', fontWeight: '600' }}>
                          ⚠️ Must attend next <strong>{sub.requiredClassesToReach75}</strong> classes
                        </span>
                      ) : (
                        <span style={{ color: 'var(--text-muted)' }}>
                          Safe (can miss up to {sub.allowBunk} classes)
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Day-to-Day Lecture Attendance Register Log */}
      <section className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
              📋 Recent Lecture-by-Lecture Attendance Log
            </h3>
            <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontSize: '0.88rem' }}>
              Daily biometric and faculty roll-call entries for parental verification.
            </p>
          </div>

          {/* Filters */}
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <select
              className="form-select"
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              style={{ width: 'auto', fontSize: '0.85rem' }}
            >
              <option value="All">All Subjects</option>
              {STUDENT_SUBJECT_ATTENDANCE.map((s) => (
                <option key={s.id} value={s.subject}>
                  {s.subject}
                </option>
              ))}
            </select>

            <select
              className="form-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={{ width: 'auto', fontSize: '0.85rem' }}
            >
              <option value="All">All Statuses</option>
              <option value="Absent">Absent Only</option>
              <option value="Present">Present Only</option>
            </select>
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="custom-table" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '2px solid var(--border-color)' }}>
                <th style={{ padding: '10px 12px', fontSize: '0.82rem' }}>Date &amp; Time</th>
                <th style={{ padding: '10px 12px', fontSize: '0.82rem' }}>Subject</th>
                <th style={{ padding: '10px 12px', fontSize: '0.82rem' }}>Faculty In-Charge</th>
                <th style={{ padding: '10px 12px', fontSize: '0.82rem' }}>Hall / Room</th>
                <th style={{ padding: '10px 12px', fontSize: '0.82rem', textAlign: 'center' }}>Attendance</th>
                <th style={{ padding: '10px 12px', fontSize: '0.82rem' }}>Faculty Note</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.map((log) => (
                <tr key={log.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
                  <td style={{ padding: '12px' }}>
                    <div style={{ fontWeight: '600', color: 'var(--primary-dark)', fontSize: '0.88rem' }}>{log.date}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{log.time}</div>
                  </td>
                  <td style={{ padding: '12px', fontWeight: '500', fontSize: '0.9rem' }}>{log.subject}</td>
                  <td style={{ padding: '12px', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{log.faculty}</td>
                  <td style={{ padding: '12px', fontSize: '0.85rem', color: 'var(--text-muted)' }}>{log.room}</td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>
                    <span
                      style={{
                        padding: '4px 10px',
                        borderRadius: '12px',
                        fontSize: '0.78rem',
                        fontWeight: '700',
                        backgroundColor: log.status === 'Present' ? '#dcfce7' : '#fee2e2',
                        color: log.status === 'Present' ? '#15803d' : '#b91c1c',
                        display: 'inline-block',
                      }}
                    >
                      {log.status === 'Present' ? '✓ Present' : '✗ Absent'}
                    </span>
                  </td>
                  <td style={{ padding: '12px', fontSize: '0.85rem', color: 'var(--text-secondary)', fontStyle: 'italic' }}>
                    {log.remarks}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* University Policy Footer Note */}
      <div className="card" style={{ backgroundColor: '#f8fafc', borderLeft: '4px solid #64748b', padding: '16px 20px' }}>
        <h4 style={{ margin: '0 0 6px 0', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>
          ℹ️ University Attendance Regulation Rule 14.1
        </h4>
        <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
          Every enrolled undergraduate student must secure a minimum aggregate attendance of 75% in each registered course to be eligible to sit for the Semester End Examinations. Medical certificates must be countersigned by the Chief Medical Officer and submitted to the Dean's Office within 3 working days of resumption.
        </p>
      </div>
    </div>
  );
}

export default ParentAttendance;
