import React from 'react';
import { STUDENT_COMPREHENSIVE_DOSSIER, STUDENT_ATTENDANCE_SUMMARY } from '../../data/mockData';
import { StudentAvatarIcon } from '../common/Icons';

/**
 * ParentStudentDossier Component
 * Provides parents with a complete 360-degree dossier of their ward's
 * academic, personal, mentor, conduct, and institutional clearance records.
 */
function ParentStudentDossier() {
  const dossier = STUDENT_COMPREHENSIVE_DOSSIER;
  const { personal, academicStanding, mentor, parentContact, institutionalClearances } = dossier;
  const attendance = STUDENT_ATTENDANCE_SUMMARY;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Dossier Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              👤 Comprehensive Student Academic Dossier
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Official university student record file for <strong>{personal.fullName}</strong>.
            </p>
          </div>
          <span style={{ backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '6px 14px', borderRadius: '16px', fontWeight: 'bold', fontSize: '0.85rem' }}>
            🔒 Verified University Record
          </span>
        </div>
      </div>

      {/* Main Profile Summary Card */}
      <div className="card" style={{ padding: '24px' }}>
        <div style={{ display: 'flex', gap: '24px', alignItems: 'center', flexWrap: 'wrap' }}>
          {/* Avatar Icon */}
          <div
            style={{
              width: '96px',
              height: '96px',
              borderRadius: '50%',
              backgroundColor: 'var(--primary-subtle)',
              border: '3px solid var(--primary-medium)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--primary-medium)',
              boxShadow: 'var(--shadow-sm)',
            }}
          >
            <StudentAvatarIcon size={56} />
          </div>

          {/* Student Info */}
          <div style={{ flex: 1, minWidth: '260px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
              <h2 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.8rem' }}>
                {personal.fullName}
              </h2>
              <span style={{ backgroundColor: '#e0f2fe', color: '#0369a1', padding: '4px 10px', borderRadius: '12px', fontSize: '0.82rem', fontWeight: 'bold' }}>
                Roll No: {personal.universityRollNo}
              </span>
              <span style={{ backgroundColor: '#f1f5f9', color: '#475569', padding: '4px 10px', borderRadius: '12px', fontSize: '0.82rem' }}>
                Reg: {personal.registrationNo}
              </span>
            </div>

            <div style={{ marginTop: '8px', color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
              <strong>{personal.program}</strong> | {personal.department}
            </div>

            <div style={{ marginTop: '4px', color: 'var(--text-muted)', fontSize: '0.88rem' }}>
              Specialization: <strong>{personal.specialization}</strong> | Batch: <strong>{personal.batch}</strong> ({personal.semester}, Section {personal.section})
            </div>
          </div>
        </div>
      </div>

      {/* 2-Column Grid: Academic Performance & Clearance Status */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {/* Column 1: Academic Standing */}
        <section className="card">
          <h3 style={{ margin: '0 0 16px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
            🎓 Academic Standing &amp; Degree Progress
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div style={{ backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Cumulative CGPA</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 'bold', color: 'var(--primary-medium)', marginTop: '2px' }}>
                {academicStanding.cgpa} / 10.0
              </div>
            </div>

            <div style={{ backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Semester SGPA</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 'bold', color: 'var(--primary-dark)', marginTop: '2px' }}>
                {academicStanding.sgpaLastSem}
              </div>
            </div>

            <div style={{ backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Rank in Cohort</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: 'var(--primary-dark)', marginTop: '4px' }}>
                {academicStanding.rankInBatch}
              </div>
            </div>

            <div style={{ backgroundColor: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Degree Credits</div>
              <div style={{ fontSize: '1.1rem', fontWeight: 'bold', color: 'var(--primary-dark)', marginTop: '4px' }}>
                {academicStanding.creditsEarnedToDate} / {academicStanding.totalCreditsRequired}
              </div>
            </div>
          </div>

          <div style={{ marginTop: '16px', padding: '12px', borderRadius: '8px', backgroundColor: '#fef3c7', border: '1px solid #fde68a' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 'bold', color: '#92400e' }}>
              Academic Standing Assessment:
            </div>
            <div style={{ fontSize: '0.88rem', color: '#78350f', marginTop: '2px' }}>
              {academicStanding.academicStatus} (Zero Backlogs)
            </div>
          </div>
        </section>

        {/* Column 2: Institutional Clearances & Examination Eligibility */}
        <section className="card">
          <h3 style={{ margin: '0 0 16px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
            📋 Institutional Clearances &amp; Examination Eligibility
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', backgroundColor: '#f8fafc', borderRadius: '6px', fontSize: '0.88rem' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Tuition Fee Dues:</span>
              <span style={{ fontWeight: 'bold', color: '#16a34a' }}>{institutionalClearances.tuitionFeeStatus}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', backgroundColor: '#f8fafc', borderRadius: '6px', fontSize: '0.88rem' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Semester Exam Fee:</span>
              <span style={{ fontWeight: 'bold', color: '#16a34a' }}>{institutionalClearances.examinationFeeStatus}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', backgroundColor: '#f8fafc', borderRadius: '6px', fontSize: '0.88rem' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Central Library Dues:</span>
              <span style={{ fontWeight: 'bold', color: '#16a34a' }}>{institutionalClearances.libraryDues}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', backgroundColor: '#f8fafc', borderRadius: '6px', fontSize: '0.88rem' }}>
              <span style={{ color: 'var(--text-secondary)' }}>Laboratory Clearance:</span>
              <span style={{ fontWeight: 'bold', color: '#16a34a' }}>{institutionalClearances.laboratoryClearance}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', backgroundColor: '#fee2e2', borderRadius: '6px', fontSize: '0.88rem', border: '1px solid #fca5a5' }}>
              <span style={{ color: '#991b1b', fontWeight: 'bold' }}>Disciplinary Conduct:</span>
              <span style={{ fontWeight: 'bold', color: '#dc2626' }}>{institutionalClearances.disciplinaryClearance}</span>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 12px', backgroundColor: '#fee2e2', borderRadius: '6px', fontSize: '0.88rem', border: '1px solid #fca5a5' }}>
              <span style={{ color: '#991b1b', fontWeight: 'bold' }}>Admit Card Release:</span>
              <span style={{ fontWeight: 'bold', color: '#dc2626' }}>{institutionalClearances.admitCardStatus}</span>
            </div>
          </div>
        </section>
      </div>

      {/* 2-Column Grid: Faculty Mentor & Parent Contact Info */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {/* Mentor Details */}
        <section className="card">
          <h3 style={{ margin: '0 0 14px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
            👨‍🏫 Assigned Faculty Mentor &amp; Proctor
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.9rem' }}>
            <div><strong>Faculty Name:</strong> {mentor.name}</div>
            <div><strong>Designation:</strong> {mentor.designation}</div>
            <div><strong>Department:</strong> {mentor.department}</div>
            <div><strong>Cabin / Office:</strong> {mentor.cabin}</div>
            <div><strong>Email:</strong> <a href={`mailto:${mentor.email}`} style={{ color: 'var(--primary-medium)' }}>{mentor.email}</a></div>
            <div><strong>Official Phone:</strong> {mentor.phone}</div>
            <div style={{ backgroundColor: '#f1f5f9', padding: '10px', borderRadius: '6px', marginTop: '4px' }}>
              <strong>Consultation Hours:</strong> {mentor.consultationHours}
            </div>
          </div>
        </section>

        {/* Parent & Family Information */}
        <section className="card">
          <h3 style={{ margin: '0 0 14px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
            👨‍👩‍👦 Registered Parent &amp; Residence Records
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '0.9rem' }}>
            <div><strong>Father's Name:</strong> {parentContact.fatherName} ({parentContact.fatherOccupation})</div>
            <div><strong>Mother's Name:</strong> {parentContact.motherName}</div>
            <div><strong>Registered Mobile:</strong> {parentContact.registeredPhone}</div>
            <div><strong>Emergency Contact:</strong> {parentContact.emergencyContact}</div>
            <div><strong>Registered Email:</strong> {parentContact.registeredEmail}</div>
            <div><strong>Permanent Address:</strong> {parentContact.permanentAddress}</div>
            <div><strong>Transport Route:</strong> {personal.residentialStatus}</div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default ParentStudentDossier;
