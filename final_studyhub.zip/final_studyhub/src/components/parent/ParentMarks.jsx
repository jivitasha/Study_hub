import React from 'react';
import { DEMO_STUDENT_MARKS } from '../../data/mockData';
import MarksSummary from '../marks/MarksSummary';
import MarksTable from '../marks/MarksTable';
import SubjectMarkCard from '../marks/SubjectMarkCard';
import Sidebar from '../common/Sidebar';



function ParentMarks() {
  const childName = 'Aarav Sharma';
  const totalObtained = DEMO_STUDENT_MARKS.reduce((acc, item) => acc + item.obtained, 0);
  const grandTotal = DEMO_STUDENT_MARKS.reduce((acc, item) => acc + item.total, 0);
  const overallPercentage = (totalObtained / grandTotal * 100).toFixed(1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h2>📊 {childName}'s Academic Performance</h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px' }}>
              Term 1 Examination Official Subject-Wise Report Card
            </p>
          </div>
          <span className="badge badge-ontrack" style={{ padding: '6px 14px' }}>
            🔒 Read-Only Parent Access
          </span>
        </div>
      </div>

      {/* Parent Encouragement Message Card */}
      <div className="card" style={{ backgroundColor: '#d8f3dc', borderLeft: '5px solid var(--primary-medium)' }}>
        <p style={{ color: 'var(--primary-dark)', fontSize: '1rem', fontWeight: '600' }}>
          🌟 "{childName} is performing excellently overall, with an average score of {overallPercentage}%."
        </p>
      </div>

      {/* Reusable Marks Summary */}
      <MarksSummary
        totalObtained={totalObtained}
        grandTotal={grandTotal}
        overallPercentage={overallPercentage}
        overallGrade="A+"
        rank={4}
      />

      {/* Subject-Wise Marks Listing */}
      <div className="card">
        <h3 style={{ color: 'var(--primary-dark)', marginBottom: '16px' }}>📚 Detailed Subject Breakdown</h3>
        
        {/* Desktop Table View */}
        <div className="desktop-view">
          <MarksTable marksList={DEMO_STUDENT_MARKS} />
        </div>

        {/* Mobile Stacked Card View */}
        <div className="mobile-view" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {DEMO_STUDENT_MARKS.map((mark) => (
            <SubjectMarkCard key={mark.id} subjectData={mark} />
          ))}
        </div>
      </div>

    </div>
  );
}

export default ParentMarks;
