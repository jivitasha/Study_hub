import React from 'react';

export function getGradeDetails(percentage) {
  if (percentage >= 90) {
    return { grade: 'A+', label: 'Outstanding (A+)', color: '#1e3a8a', bg: '#eff6ff', barColor: '#2563eb' };
  } else if (percentage >= 80) {
    return { grade: 'A', label: 'Very Good (A)', color: '#1e40af', bg: '#dbeafe', barColor: '#3b82f6' };
  } else if (percentage >= 70) {
    return { grade: 'B', label: 'Good', color: '#92400e', bg: '#fef3c7', barColor: '#f59e0b' };
  } else {
    return { grade: 'C', label: 'Needs Improvement', color: '#991b1b', bg: '#fee2e2', barColor: '#ef4444' };
  }
}


function SubjectMarkCard({ subjectData }) {
  const percentage = Math.round((subjectData.obtained / subjectData.total) * 100);
  const gradeInfo = getGradeDetails(percentage);

  return (
    <article className="card" style={{ borderLeft: `5px solid ${gradeInfo.barColor}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
        <h4 style={{ fontSize: '20px', color: 'var(--primary-dark)' }}>📚 {subjectData.subject}</h4>
        <span 
          style={{ 
            fontSize: '20px', 
            fontWeight: 'bold', 
            backgroundColor: gradeInfo.bg, 
            color: gradeInfo.color,
            padding: '4px 10px',
            borderRadius: '12px'
          }}
        >
          {gradeInfo.grade} ({gradeInfo.label})
        </span>
      </div>

      <div style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '8px' }}>
        Marks Obtained: <strong>{subjectData.obtained}</strong> / {subjectData.total} ({percentage}%)
      </div>

      {/* Progress Bar*/}
      <div className="progress-container" style={{ height: '10px' }}>
        <div 
          className="progress-fill" 
          style={{ width: `${percentage}%`, backgroundColor: gradeInfo.barColor }} 
        />
      </div>
    </article>
  );
}

export default SubjectMarkCard;
