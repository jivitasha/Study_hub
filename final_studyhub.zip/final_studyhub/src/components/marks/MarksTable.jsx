import React from 'react';
import { getGradeDetails } from './SubjectMarkCard';

function MarksTable({ marksList }) {
  return (
    <div className="table-container">
      <table className="custom-table">
        <thead>
          <tr>
            <th>Subject</th>
            <th>Marks Obtained</th>
            <th>Total Marks</th>
            <th>Percentage & Visual Progress</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>
         
          {marksList.map((item) => {
            const percentage = Math.round((item.obtained / item.total) * 100);
            const gradeInfo = getGradeDetails(percentage);

            return (
              <tr key={item.id}>
                <td><strong>📚 {item.subject}</strong></td>
                <td><strong>{item.obtained}</strong></td>
                <td>{item.total}</td>
                <td style={{ minWidth: '180px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div className="progress-container" >
                      <div 
                        className="progress-fill" 
                        style={{ width: `${percentage}%`, backgroundColor: gradeInfo.barColor }} 
                      />
                    </div>
                    <span style={{ fontSize: '0.85rem', fontWeight: 'bold' }}>{percentage}%</span>
                  </div>
                </td>
                <td>
                  <span 
                    style={{ 
                      fontSize: '0.8rem', 
                      fontWeight: 'bold', 
                      backgroundColor: gradeInfo.bg, 
                      color: gradeInfo.color,
                      padding: '4px 10px',
                      borderRadius: '12px'
                    }}
                  >
                    {gradeInfo.grade} ({gradeInfo.label})
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default MarksTable;
