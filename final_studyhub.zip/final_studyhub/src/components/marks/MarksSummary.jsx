import React from 'react';


function MarksSummary({ totalObtained, grandTotal, overallPercentage, overallGrade, rank }) {
  return (
    <div className="dashboard-grid" style={{ marginBottom: '24px' }}>
      <article className="card">
        <div className="stat-card-lbl">💯 Total Marks</div>
        <div className="stat-card-val">{totalObtained} / {grandTotal}</div>
      </article>

      <article className="card">
        <div className="stat-card-lbl">📈 Overall Percentage</div>
        <div className="stat-card-val">{overallPercentage}%</div>
      </article>

      <article className="card">
        <div className="stat-card-lbl">🌟 Overall Grade</div>
        <div className="stat-card-val" style={{ color: 'var(--primary-medium)' }}>
          {overallGrade}
        </div>
      </article>

      <article className="card">
        <div className="stat-card-lbl">🏆 Semester Batch Rank</div>
        <div className="stat-card-val" style={{ color: 'var(--primary-medium)' }}>
          #{rank}
        </div>
      </article>
    </div>
  );
}

export default MarksSummary;
