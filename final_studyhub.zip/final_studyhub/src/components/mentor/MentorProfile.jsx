import React, { useState, useEffect, useRef } from 'react';
import Toast from '../common/Toast';
import { MentorAvatarIcon, ProfileIcon } from '../common/Icons';

export function MentorStatCard({ title, value, icon }) {
  return (
    <article className="card">
      <div style={{ fontSize: '28px', marginBottom: '8px' }}>{icon}</div>
      <div className="stat-card-lbl">{title}</div>
      <div className="stat-card-val">{value}</div>
    </article>
  );
}

function MentorProfile({ user = {} }) {
  const fileInputRef = useRef(null);

  const [profile, setProfile] = useState(() => {
    const storageKey = user.id ? `studysphere_mentor_profile_${user.id}` : 'studysphere_mentor_profile';
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return {
      name: user.name || 'Dr. Ramesh Verma',
      mentorId: user.id || 'MTR2026',
      email: user.email || 'ramesh.verma@studysphere.edu',
      designation: 'Associate Professor & Academic Mentor',
      department: user.department || 'Computer Science & Engineering',
      college: 'College of Engineering & Technology',
      cabin: 'Block B - Room 402',
      officeHours: 'Mon-Thu 2:00 PM - 4:00 PM',
      specialization: 'Artificial Intelligence & Distributed Systems',
      avatar: null,
    };
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(profile.name);
  const [editDesignation, setEditDesignation] = useState(profile.designation);
  const [editDepartment, setEditDepartment] = useState(profile.department);
  const [editCabin, setEditCabin] = useState(profile.cabin);
  const [editEmail, setEditEmail] = useState(profile.email);
  const [editOfficeHours, setEditOfficeHours] = useState(profile.officeHours);
  const [editSpecialization, setEditSpecialization] = useState(profile.specialization);
  const [editAvatar, setEditAvatar] = useState(profile.avatar);
  const [toastMessage, setToastMessage] = useState('');

  // Persist mentor profile in localStorage
  useEffect(() => {
    const storageKey = user.id ? `studysphere_mentor_profile_${user.id}` : 'studysphere_mentor_profile';
    localStorage.setItem(storageKey, JSON.stringify(profile));
  }, [profile, user.id]);

  // Handle mentor picture upload
  const handleImageChange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Please choose an image under 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result;
        if (isEditing) {
          setEditAvatar(result);
        } else {
          setProfile((prev) => ({ ...prev, avatar: result }));
          setEditAvatar(result);
          setToastMessage('Mentor profile photo updated successfully! 📸');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    if (isEditing) {
      setEditAvatar(null);
    } else {
      setProfile((prev) => ({ ...prev, avatar: null }));
      setEditAvatar(null);
      setToastMessage('Profile photo removed.');
    }
  };

  const handleSaveProfile = (e) => {
    e.preventDefault();
    const updated = {
      ...profile,
      name: editName,
      designation: editDesignation,
      department: editDepartment,
      cabin: editCabin,
      email: editEmail,
      officeHours: editOfficeHours,
      specialization: editSpecialization,
      avatar: editAvatar,
    };
    setProfile(updated);
    setIsEditing(false);
    setToastMessage('Mentor profile updated successfully! ✅');
  };

  const handleCancelEdit = () => {
    setEditName(profile.name);
    setEditDesignation(profile.designation);
    setEditDepartment(profile.department);
    setEditCabin(profile.cabin);
    setEditEmail(profile.email);
    setEditOfficeHours(profile.officeHours);
    setEditSpecialization(profile.specialization);
    setEditAvatar(profile.avatar);
    setIsEditing(false);
  };

  const displayAvatar = isEditing ? editAvatar : profile.avatar;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toastMessage && (
        <Toast
          message={toastMessage}
          type="success"
          onClose={() => setToastMessage('')}
        />
      )}

      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleImageChange}
        accept="image/*"
        style={{ display: 'none' }}
      />

      {/* SECTION: Main Mentor Profile Card */}
      <section className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px', flexWrap: 'wrap' }}>
            {/* Picture Circle with Camera Button */}
            <div style={{ position: 'relative' }}>
              <div
                style={{
                  width: '90px',
                  height: '90px',
                  borderRadius: '50%',
                  backgroundColor: 'var(--primary-dark)',
                  color: 'var(--bg-white)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '2.5rem',
                  fontWeight: 'bold',
                  overflow: 'hidden',
                  border: '3px solid var(--primary-light, #3b82f6)',
                  boxShadow: '0 3px 10px rgba(0,0,0,0.12)',
                  cursor: 'pointer',
                }}
                onClick={() => fileInputRef.current?.click()}
                title="Click to upload mentor photo"
              >
                {displayAvatar ? (
                  <img
                    src={displayAvatar}
                    alt={profile.name}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                ) : (
                  <MentorAvatarIcon size={90} />
                )}
              </div>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Upload Photo"
                style={{
                  position: 'absolute',
                  bottom: '-2px',
                  right: '-2px',
                  backgroundColor: 'var(--primary-dark)',
                  color: '#fff',
                  border: '2px solid #fff',
                  borderRadius: '50%',
                  width: '30px',
                  height: '30px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  fontSize: '0.9rem',
                }}
              >
                📷
              </button>
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                <h2 style={{ color: 'var(--primary-dark)', fontSize: '1.7rem', margin: 0 }}>
                  {profile.name}
                </h2>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => fileInputRef.current?.click()}
                  style={{ fontSize: '0.8rem', padding: '4px 10px', height: 'auto' }}
                >
                  📷 Change Photo
                </button>
                {displayAvatar && (
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#dc2626',
                      cursor: 'pointer',
                      fontSize: '0.8rem',
                      textDecoration: 'underline',
                    }}
                  >
                    Remove
                  </button>
                )}
              </div>

              <p style={{ color: 'var(--text-secondary)', fontSize: '1rem', marginTop: '6px', fontWeight: '500' }}>
                🎓 {profile.designation} | 🏛️ {profile.department}
              </p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginTop: '4px' }}>
                🆔 Mentor ID: <strong>{profile.mentorId}</strong> | ✉️ College Email: <strong>{profile.email}</strong>
              </p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginTop: '4px' }}>
                📍 Cabin: <strong>{profile.cabin}</strong> | 🕒 Office Hours: <strong>{profile.officeHours}</strong>
              </p>
            </div>
          </div>

          {!isEditing && (
            <button className="btn-secondary" onClick={() => setIsEditing(true)}>
              ✏️ Edit Mentor Profile
            </button>
          )}
        </div>

        {/* Edit Form */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
            <h3 style={{ marginBottom: '16px', color: 'var(--primary-dark)' }}>✏️ Edit Mentor Information</h3>

            <div className="form-group">
              <label className="form-label">Profile Photo</label>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => fileInputRef.current?.click()}
                >
                  📁 Select Photo From Computer
                </button>
                {editAvatar && (
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handleRemovePhoto}
                    style={{ color: '#dc2626' }}
                  >
                    🗑️ Remove Photo
                  </button>
                )}
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
              <div className="form-group">
                <label className="form-label" htmlFor="mentor-name">Full Name & Title</label>
                <input
                  id="mentor-name"
                  type="text"
                  className="form-input"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="mentor-designation">Designation / Role</label>
                <input
                  id="mentor-designation"
                  type="text"
                  className="form-input"
                  value={editDesignation}
                  onChange={(e) => setEditDesignation(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="mentor-dept">College Department</label>
                <input
                  id="mentor-dept"
                  type="text"
                  className="form-input"
                  value={editDepartment}
                  onChange={(e) => setEditDepartment(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="mentor-cabin">Cabin / Office Room</label>
                <input
                  id="mentor-cabin"
                  type="text"
                  className="form-input"
                  value={editCabin}
                  onChange={(e) => setEditCabin(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="mentor-email">College Email Address</label>
                <input
                  id="mentor-email"
                  type="email"
                  className="form-input"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="mentor-hours">Consultation / Office Hours</label>
                <input
                  id="mentor-hours"
                  type="text"
                  className="form-input"
                  value={editOfficeHours}
                  onChange={(e) => setEditOfficeHours(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-group" style={{ marginTop: '12px' }}>
              <label className="form-label" htmlFor="mentor-spec">Specialization & Research Focus</label>
              <input
                id="mentor-spec"
                type="text"
                className="form-input"
                value={editSpecialization}
                onChange={(e) => setEditSpecialization(e.target.value)}
                placeholder="e.g. Data Science, Cloud Computing, Neural Networks"
              />
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '16px' }}>
              <button type="submit" className="btn-primary" style={{ width: 'auto' }}>
                💾 Save Changes
              </button>
              <button type="button" className="btn-secondary" onClick={handleCancelEdit}>
                ✖️ Cancel
              </button>
            </div>
          </form>
        )}
      </section>

      {/* SECTION: Academic Mentorship Stats */}
      <section>
        <h3 style={{ marginBottom: '14px', color: 'var(--primary-dark)' }}>📊 Academic Mentorship Overview</h3>
        <div className="dashboard-grid">
          <MentorStatCard title="Assigned Mentees" value="28 Undergrads" icon="👥" />
          <MentorStatCard title="Active Courses / Labs" value="4 Courses" icon="📚" />
          <MentorStatCard title="Capstone Projects" value="6 Batches" icon="💡" />
          <MentorStatCard title="Office Consultations" value="18 This Month" icon="💬" />
        </div>
      </section>

      {/* SECTION: College Mentor Duties */}
      <section className="card">
        <h3 style={{ color: 'var(--primary-dark)', marginBottom: '8px' }}>🎯 College Mentor Responsibilities</h3>
        <ul style={{ paddingLeft: '20px', lineHeight: '1.8', color: 'var(--text-secondary)' }}>
          <li>Conduct bi-weekly 1-on-1 mentorship reviews for assigned undergraduate students.</li>
          <li>Review semester attendance, mid-term test scores, and lab practical performance.</li>
          <li>Provide academic guidance for final year capstone projects and internship opportunities.</li>
          <li>Approve technical symposium and hackathon participation clearances.</li>
        </ul>
      </section>
    </div>
  );
}

export default MentorProfile;
