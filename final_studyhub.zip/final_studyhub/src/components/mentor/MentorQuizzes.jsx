import React, { useState, useEffect } from 'react';
import { INITIAL_COLLEGE_QUIZZES, INITIAL_QUIZ_SUBMISSIONS } from '../../data/mockData';
import Toast from '../common/Toast';

const STORAGE_QUIZZES_KEY = 'studysphere_quizzes';
const STORAGE_SUBMISSIONS_KEY = 'studysphere_quiz_submissions';

function MentorQuizzes({ user = {} }) {
  const [toast, setToast] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [viewingSubmissionsQuiz, setViewingSubmissionsQuiz] = useState(null);

  // Quizzes list from localStorage
  const [quizzes, setQuizzes] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_QUIZZES_KEY);
      return saved ? JSON.parse(saved) : INITIAL_COLLEGE_QUIZZES;
    } catch {
      return INITIAL_COLLEGE_QUIZZES;
    }
  });

  // Submissions list from localStorage
  const [submissions, setSubmissions] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SUBMISSIONS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_QUIZ_SUBMISSIONS;
    } catch {
      return INITIAL_QUIZ_SUBMISSIONS;
    }
  });

  // Persist quizzes
  useEffect(() => {
    localStorage.setItem(STORAGE_QUIZZES_KEY, JSON.stringify(quizzes));
  }, [quizzes]);

  // Sync with student submissions from storage events
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const savedSubs = localStorage.getItem(STORAGE_SUBMISSIONS_KEY);
        if (savedSubs) setSubmissions(JSON.parse(savedSubs));
        const savedQz = localStorage.getItem(STORAGE_QUIZZES_KEY);
        if (savedQz) setQuizzes(JSON.parse(savedQz));
      } catch {
        // fallback
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Form State for creating a new Quiz
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('DBMS & SQL');
  const [targetAudience, setTargetAudience] = useState('All Students');
  const [durationMinutes, setDurationMinutes] = useState(15);
  const [dueDate, setDueDate] = useState('2026-10-30');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([
    {
      id: 'q1',
      questionText: '',
      options: ['', '', '', ''],
      correctIndex: 0,
      explanation: '',
    },
  ]);
  const [formErrors, setFormErrors] = useState({});

  // Question helpers
  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      {
        id: `q${Date.now()}`,
        questionText: '',
        options: ['', '', '', ''],
        correctIndex: 0,
        explanation: '',
      },
    ]);
  };

  const handleRemoveQuestion = (idx) => {
    if (questions.length <= 1) {
      setToast({ message: 'A quiz must contain at least one question.', type: 'error' });
      return;
    }
    setQuestions(questions.filter((_, i) => i !== idx));
  };

  const handleQuestionTextChange = (idx, text) => {
    const updated = [...questions];
    updated[idx].questionText = text;
    setQuestions(updated);
  };

  const handleOptionChange = (qIdx, optIdx, val) => {
    const updated = [...questions];
    updated[qIdx].options[optIdx] = val;
    setQuestions(updated);
  };

  const handleCorrectIndexChange = (qIdx, correctIdx) => {
    const updated = [...questions];
    updated[qIdx].correctIndex = correctIdx;
    setQuestions(updated);
  };

  const handleExplanationChange = (qIdx, exp) => {
    const updated = [...questions];
    updated[qIdx].explanation = exp;
    setQuestions(updated);
  };

  // Validate form
  const validate = () => {
    const errs = {};
    if (!title.trim()) errs.title = 'Quiz title is required.';
    if (!dueDate) errs.dueDate = 'Due date is required.';
    if (questions.some((q) => !q.questionText.trim())) {
      errs.questions = 'All questions must have a question statement.';
    }
    if (questions.some((q) => q.options.some((opt) => !opt.trim()))) {
      errs.options = 'All 4 options for every question must be filled in.';
    }
    return errs;
  };

  // Submit new Quiz
  const handlePublishQuiz = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setFormErrors(errs);
      setToast({ message: 'Please correct the validation errors before publishing.', type: 'error' });
      return;
    }
    setFormErrors({});

    const newQuiz = {
      id: `quiz-${Date.now()}`,
      title: title.trim(),
      subject,
      mentorName: user?.name || 'Dr. Ramesh Verma',
      mentorRole: user?.designation || 'Faculty Mentor',
      targetAudience,
      durationMinutes: Number(durationMinutes) || 15,
      totalMarks: questions.length * 10,
      dueDate,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'Published',
      description: description.trim() || `Course evaluation quiz for ${subject}.`,
      questions,
    };

    setQuizzes([newQuiz, ...quizzes]);
    setIsCreating(false);
    setTitle('');
    setDescription('');
    setQuestions([
      {
        id: 'q1',
        questionText: '',
        options: ['', '', '', ''],
        correctIndex: 0,
        explanation: '',
      },
    ]);
    setToast({
      message: `Quiz "${newQuiz.title}" published successfully to ${newQuiz.targetAudience}! 🚀`,
      type: 'success',
    });
  };

  // Delete Quiz
  const handleDeleteQuiz = (id) => {
    if (window.confirm('Are you sure you want to delete this quiz?')) {
      setQuizzes(quizzes.filter((q) => q.id !== id));
      setToast({ message: 'Quiz removed.', type: 'info' });
    }
  };

  // Total submissions evaluated
  const totalSubmissionsCount = submissions.length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              📝 Faculty Quiz &amp; Assessment Manager
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Create multiple-choice quizzes, schedule online tests, and broadcast assessments to all undergraduate mentees.
            </p>
          </div>
          <div>
            <button
              type="button"
              className="btn-primary"
              style={{ width: 'auto', padding: '10px 20px', fontSize: '0.92rem' }}
              onClick={() => setIsCreating(!isCreating)}
            >
              {isCreating ? '✖ Close Form' : '➕ Create New Quiz'}
            </button>
          </div>
        </div>
      </div>

      {/* Top Stats Cards */}
      <div className="dashboard-grid">
        <article className="card" style={{ borderLeft: '4px solid var(--primary-medium)' }}>
          <div className="stat-card-lbl">📚 Total Quizzes Created</div>
          <div className="stat-card-val" style={{ color: 'var(--primary-dark)' }}>{quizzes.length}</div>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '6px' }}>Active and archived</div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">🚀 Published &amp; Live</div>
          <div className="stat-card-val" style={{ color: '#16a34a' }}>
            {quizzes.filter((q) => q.status === 'Published').length}
          </div>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '6px' }}>Available to students</div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">👥 Student Submissions</div>
          <div className="stat-card-val" style={{ color: 'var(--primary-medium)' }}>
            {totalSubmissionsCount}
          </div>
          <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '6px' }}>Total attempts evaluated</div>
        </article>
      </div>

      {/* CREATE NEW QUIZ FORM MODAL/DRAWER */}
      {isCreating && (
        <section className="card" style={{ border: '2px solid var(--primary-medium)', padding: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.3rem' }}>
              ➕ Author New Quiz for Students
            </h3>
            <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              Total Marks Auto-Calculated (10 Marks / Question)
            </span>
          </div>

          <form onSubmit={handlePublishQuiz}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '16px' }}>
              {/* Title */}
              <div className="form-group" style={{ gridColumn: 'span 2' }}>
                <label className="form-label">Quiz Title *</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g., OOPS in Java: Inheritance & Polymorphism Quiz"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
                {formErrors.title && <div className="error-message">{formErrors.title}</div>}
              </div>

              {/* Subject */}
              <div className="form-group">
                <label className="form-label">Course / Subject *</label>
                <select className="form-select" value={subject} onChange={(e) => setSubject(e.target.value)}>
                  <option value="DBMS & SQL">DBMS &amp; SQL</option>
                  <option value="Applied Statistics">Applied Statistics</option>
                  <option value="OOPS in Java">OOPS in Java</option>
                  <option value="FEE (Electrical Eng.)">FEE (Electrical Eng.)</option>
                  <option value="Database Systems Lab">Database Systems Lab</option>
                  <option value="Coursera NPTEL Elective">Coursera NPTEL Elective</option>
                </select>
              </div>

              {/* Target Audience */}
              <div className="form-group">
                <label className="form-label">Target Audience *</label>
                <select
                  className="form-select"
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                >
                  <option value="All Students">📢 All Students (Broadcast)</option>
                  <option value="Aarav Sharma (22CS101)">👤 Aarav Sharma (22CS101)</option>
                  <option value="Priya Patel (22CS102)">👤 Priya Patel (22CS102)</option>
                  <option value="Rohan Gupta (22CS103)">👤 Rohan Gupta (22CS103)</option>
                </select>
              </div>

              {/* Duration */}
              <div className="form-group">
                <label className="form-label">Duration (Minutes) *</label>
                <input
                  type="number"
                  min="5"
                  max="120"
                  className="form-input"
                  value={durationMinutes}
                  onChange={(e) => setDurationMinutes(e.target.value)}
                />
              </div>

              {/* Due Date */}
              <div className="form-group">
                <label className="form-label">Submission Deadline *</label>
                <input
                  type="date"
                  className="form-input"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                />
                {formErrors.dueDate && <div className="error-message">{formErrors.dueDate}</div>}
              </div>
            </div>

            {/* Description */}
            <div className="form-group">
              <label className="form-label">Instructions / Description</label>
              <textarea
                className="form-textarea"
                rows="2"
                placeholder="Write instructions, topics covered, or syllabus hints for students..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            {/* QUESTIONS BUILDER */}
            <div style={{ marginTop: '24px', borderTop: '2px dashed var(--border-color)', paddingTop: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
                <h4 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.15rem' }}>
                  ❓ Quiz Questions ({questions.length})
                </h4>
                <button
                  type="button"
                  className="btn-secondary"
                  style={{ width: 'auto', fontSize: '0.85rem' }}
                  onClick={handleAddQuestion}
                >
                  ➕ Add Question
                </button>
              </div>

              {formErrors.questions && <div className="error-message" style={{ marginBottom: '12px' }}>{formErrors.questions}</div>}
              {formErrors.options && <div className="error-message" style={{ marginBottom: '12px' }}>{formErrors.options}</div>}

              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                {questions.map((q, qIndex) => (
                  <div
                    key={q.id || qIndex}
                    style={{
                      border: '1px solid var(--border-color)',
                      borderRadius: '8px',
                      padding: '18px',
                      backgroundColor: '#f8fafc',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                      <span style={{ fontWeight: 'bold', color: 'var(--primary-medium)' }}>
                        Question {qIndex + 1}
                      </span>
                      {questions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveQuestion(qIndex)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#dc2626',
                            cursor: 'pointer',
                            fontSize: '0.85rem',
                            fontWeight: '600',
                          }}
                        >
                          🗑️ Remove
                        </button>
                      )}
                    </div>

                    <div className="form-group">
                      <label className="form-label">Question Statement *</label>
                      <input
                        type="text"
                        className="form-input"
                        placeholder="Enter the question here..."
                        value={q.questionText}
                        onChange={(e) => handleQuestionTextChange(qIndex, e.target.value)}
                      />
                    </div>

                    {/* 4 Options with Radio Button for Correct Answer */}
                    <div style={{ marginTop: '12px' }}>
                      <label className="form-label">Options (Mark radio button for the correct option) *</label>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '10px' }}>
                        {q.options.map((opt, optIndex) => (
                          <div
                            key={optIndex}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px',
                              backgroundColor: '#ffffff',
                              padding: '8px 12px',
                              borderRadius: '6px',
                              border: `1px solid ${q.correctIndex === optIndex ? '#16a34a' : 'var(--border-color)'}`,
                            }}
                          >
                            <input
                              type="radio"
                              name={`correct-${qIndex}`}
                              checked={q.correctIndex === optIndex}
                              onChange={() => handleCorrectIndexChange(qIndex, optIndex)}
                              style={{ cursor: 'pointer' }}
                              id={`q-${qIndex}-opt-${optIndex}`}
                            />
                            <label
                              htmlFor={`q-${qIndex}-opt-${optIndex}`}
                              style={{ fontWeight: 'bold', fontSize: '0.85rem', color: q.correctIndex === optIndex ? '#16a34a' : 'var(--text-secondary)' }}
                            >
                              {String.fromCharCode(65 + optIndex)}:
                            </label>
                            <input
                              type="text"
                              className="form-input"
                              style={{ flex: 1, padding: '4px 8px', fontSize: '0.88rem' }}
                              placeholder={`Option ${String.fromCharCode(65 + optIndex)}`}
                              value={opt}
                              onChange={(e) => handleOptionChange(qIndex, optIndex, e.target.value)}
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Explanation */}
                    <div className="form-group" style={{ marginTop: '12px', marginBottom: 0 }}>
                      <label className="form-label">Explanation / Solution Hint (Shown after student submission)</label>
                      <input
                        type="text"
                        className="form-input"
                        placeholder="Explain why the selected option is correct..."
                        value={q.explanation}
                        onChange={(e) => handleExplanationChange(qIndex, e.target.value)}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div style={{ marginTop: '24px', display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
              <button
                type="button"
                className="btn-secondary"
                style={{ width: 'auto' }}
                onClick={() => setIsCreating(false)}
              >
                Cancel
              </button>
              <button type="submit" className="btn-primary" style={{ width: 'auto', padding: '10px 24px' }}>
                🚀 Publish Quiz to Students
              </button>
            </div>
          </form>
        </section>
      )}

      {/* VIEW SUBMISSIONS MODAL */}
      {viewingSubmissionsQuiz && (
        <section className="card" style={{ border: '2px solid var(--primary-medium)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <div>
              <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
                👥 Student Submissions for: "{viewingSubmissionsQuiz.title}"
              </h3>
              <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontSize: '0.88rem' }}>
                Course: <strong>{viewingSubmissionsQuiz.subject}</strong> | Total Marks: {viewingSubmissionsQuiz.totalMarks}
              </p>
            </div>
            <button
              type="button"
              className="btn-secondary"
              style={{ width: 'auto', fontSize: '0.85rem' }}
              onClick={() => setViewingSubmissionsQuiz(null)}
            >
              ✖ Close Submissions
            </button>
          </div>

          {(() => {
            const quizSubs = submissions.filter((s) => s.quizId === viewingSubmissionsQuiz.id);
            if (quizSubs.length === 0) {
              return (
                <div style={{ padding: '24px', textAlign: 'center', color: 'var(--text-muted)' }}>
                  No students have attempted this quiz yet. Submissions will appear in real time once submitted.
                </div>
              );
            }
            return (
              <div style={{ overflowX: 'auto' }}>
                <table className="custom-table" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#f8fafc', borderBottom: '2px solid var(--border-color)' }}>
                      <th style={{ padding: '10px 12px', fontSize: '0.85rem' }}>Student Name</th>
                      <th style={{ padding: '10px 12px', fontSize: '0.85rem' }}>Roll No</th>
                      <th style={{ padding: '10px 12px', fontSize: '0.85rem' }}>Score Obtained</th>
                      <th style={{ padding: '10px 12px', fontSize: '0.85rem' }}>Percentage</th>
                      <th style={{ padding: '10px 12px', fontSize: '0.85rem' }}>Status</th>
                      <th style={{ padding: '10px 12px', fontSize: '0.85rem' }}>Submitted At</th>
                    </tr>
                  </thead>
                  <tbody>
                    {quizSubs.map((sub, sIdx) => (
                      <tr key={sIdx} style={{ borderBottom: '1px solid var(--border-color)' }}>
                        <td style={{ padding: '12px', fontWeight: 'bold' }}>{sub.studentName}</td>
                        <td style={{ padding: '12px', color: 'var(--text-muted)' }}>{sub.studentRoll || '22CS101'}</td>
                        <td style={{ padding: '12px', fontWeight: 'bold', color: 'var(--primary-dark)' }}>
                          {sub.score} / {sub.totalMarks}
                        </td>
                        <td style={{ padding: '12px', fontWeight: 'bold', color: sub.percentage >= 60 ? '#16a34a' : '#dc2626' }}>
                          {sub.percentage}%
                        </td>
                        <td style={{ padding: '12px' }}>
                          <span
                            style={{
                              padding: '3px 8px',
                              borderRadius: '12px',
                              fontSize: '0.78rem',
                              fontWeight: 'bold',
                              backgroundColor: sub.percentage >= 60 ? '#dcfce7' : '#fee2e2',
                              color: sub.percentage >= 60 ? '#15803d' : '#b91c1c',
                            }}
                          >
                            {sub.percentage >= 60 ? 'Passed' : 'Needs Support'}
                          </span>
                        </td>
                        <td style={{ padding: '12px', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                          {sub.submittedAt}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })()}
        </section>
      )}

      {/* PUBLISHED QUIZZES LIST */}
      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.3rem' }}>
            📋 Live Assigned Quizzes ({quizzes.length})
          </h3>
          <span style={{ fontSize: '0.8rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '4px 10px', borderRadius: '12px', fontWeight: 'bold' }}>
            Delivered to Students
          </span>
        </div>

        {quizzes.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '40px', color: 'var(--text-secondary)' }}>
            No quizzes created yet. Click <strong>"➕ Create New Quiz"</strong> above to author your first assessment!
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {quizzes.map((quiz) => {
              const quizSubs = submissions.filter((s) => s.quizId === quiz.id);
              return (
                <article
                  key={quiz.id}
                  className="card"
                  style={{
                    borderLeft: '5px solid var(--primary-medium)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem', fontWeight: 'bold' }}>
                          📚 {quiz.subject}
                        </span>
                        <span style={{ backgroundColor: '#f1f5f9', color: '#475569', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem' }}>
                          🎯 {quiz.targetAudience}
                        </span>
                        <span style={{ backgroundColor: '#dcfce7', color: '#15803d', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem', fontWeight: 'bold' }}>
                          ● {quiz.status}
                        </span>
                      </div>
                      <h4 style={{ margin: '8px 0 4px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
                        {quiz.title}
                      </h4>
                      <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                        {quiz.description}
                      </p>
                    </div>

                    <div style={{ textAlign: 'right', minWidth: '120px' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: 'var(--primary-dark)' }}>
                        {quiz.totalMarks} Marks
                      </div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                        {quiz.questions ? quiz.questions.length : 0} Questions · {quiz.durationMinutes} Mins
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px', paddingTop: '10px', borderTop: '1px solid var(--border-color)' }}>
                    <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                      📅 Due: <strong>{quiz.dueDate}</strong> | Author: <strong>{quiz.mentorName}</strong>
                    </div>

                    <div style={{ display: 'flex', gap: '10px' }}>
                      <button
                        type="button"
                        className="btn-secondary"
                        style={{ width: 'auto', fontSize: '0.85rem', padding: '6px 14px' }}
                        onClick={() => setViewingSubmissionsQuiz(quiz)}
                      >
                        👥 Submissions ({quizSubs.length})
                      </button>
                      <button
                        type="button"
                        style={{
                          background: 'none',
                          border: 'none',
                          color: '#dc2626',
                          cursor: 'pointer',
                          fontSize: '0.85rem',
                          fontWeight: '600',
                          padding: '6px 8px',
                        }}
                        onClick={() => handleDeleteQuiz(quiz.id)}
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

export default MentorQuizzes;
