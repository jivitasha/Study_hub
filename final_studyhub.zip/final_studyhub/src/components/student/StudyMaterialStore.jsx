import React, { useState } from 'react';
import { useLocker } from '../../context/LockerContext';
import Toast from '../common/Toast';
import Modal from '../common/Modal';

const STUDY_MATERIALS = [
  {
    id: 'mat-1',
    title: 'Database System Concepts (7th Edition) - Silberschatz & Korth',
    subject: 'DBMS & SQL',
    type: 'Core Textbook',
    fileSize: '18.4 MB · PDF',
    downloads: 1420,
    facultyTag: 'Mandatory Reading by Dr. Ramesh Verma',
    description: 'The primary reference textbook covering ER models, relational algebra, SQL DDL/DML, normalization up to 5NF, and transaction processing.',
  },
  {
    id: 'mat-2',
    title: 'DBMS Sessional Test 1 & 2 Solved Question Papers (2022-2025)',
    subject: 'DBMS & SQL',
    type: 'Solved Papers',
    fileSize: '4.2 MB · PDF',
    downloads: 980,
    facultyTag: 'Exam Cell Archive',
    description: 'Previous 3 years university question papers with model answers, SQL queries, and normalization schema derivations.',
  },
  {
    id: 'mat-3',
    title: 'Applied Probability & Statistical Inference Quick Formula Sheet',
    subject: 'Applied Statistics',
    type: 'Formula Sheet',
    fileSize: '1.8 MB · PDF',
    downloads: 2150,
    facultyTag: 'Recommended by Prof. Sunita Rao',
    description: 'Comprehensive formula cheat sheet covering Poisson, Binomial, Normal Gaussian distributions, Hypothesis testing (Z-test, t-test, Chi-square), and ANOVA tables.',
  },
  {
    id: 'mat-4',
    title: 'Core Java & Object-Oriented Programming Lab Code Manual',
    subject: 'OOPS in Java',
    type: 'Lab Manual',
    fileSize: '6.5 MB · ZIP',
    downloads: 870,
    facultyTag: 'Lab In-Charge Approved',
    description: 'Complete source code repository and lab assignments covering multithreading, inheritance, abstract classes, collections framework, and JDBC connectivity.',
  },
  {
    id: 'mat-5',
    title: 'Foundations of Electrical Engineering (FEE) Circuit Analysis Handbook',
    subject: 'FEE (Electrical Eng.)',
    type: 'Lecture Notes',
    fileSize: '8.1 MB · PDF',
    downloads: 760,
    facultyTag: 'Dr. Harish Chandra Lecture Series',
    description: 'Detailed derivations for Thevenin, Norton, Superposition theorems, AC resonance circuits, and 3-phase transformers.',
  },
  {
    id: 'mat-6',
    title: 'Database Systems Lab SQL Queries & Triggers Worksheets',
    subject: 'Database Systems Lab',
    type: 'Lab Manual',
    fileSize: '3.1 MB · SQL Scripts',
    downloads: 1100,
    facultyTag: 'Er. Neha Gupta Verified',
    description: 'Hands-on practice scripts for PostgreSQL & MySQL: complex nested subqueries, stored procedures, PL/SQL triggers, and indexing experiments.',
  },
];

function StudyMaterialStore() {
  const { lockerItems, totalCount, addToLocker, removeFromLocker, clearLocker, isInLocker } = useLocker();
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLockerModalOpen, setIsLockerModalOpen] = useState(false);
  const [toast, setToast] = useState(null);

  const subjects = ['All', 'DBMS & SQL', 'Applied Statistics', 'OOPS in Java', 'FEE (Electrical Eng.)', 'Database Systems Lab'];

  const filteredMaterials = STUDY_MATERIALS.filter((item) => {
    const matchSub = selectedSubject === 'All' || item.subject === selectedSubject;
    const q = searchQuery.toLowerCase().trim();
    const matchSearch =
      !q ||
      item.title.toLowerCase().includes(q) ||
      item.subject.toLowerCase().includes(q) ||
      item.type.toLowerCase().includes(q);
    return matchSub && matchSearch;
  });

  const handleToggleLocker = (item) => {
    if (isInLocker(item.id)) {
      removeFromLocker(item.id);
      setToast({ message: `Removed "${item.title.slice(0, 30)}..." from locker.`, type: 'info' });
    } else {
      addToLocker(item);
      setToast({ message: `Added "${item.title.slice(0, 30)}..." to study locker! 🛒`, type: 'success' });
    }
  };

  const handleDownloadAll = () => {
    if (lockerItems.length === 0) return;
    setToast({
      message: `Packaging ${lockerItems.length} study items for offline semester bundle download... 📦✅`,
      type: 'success',
    });
    setIsLockerModalOpen(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              📚 Course Study Materials &amp; Academic Locker
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Official textbooks, solved previous year papers, and lab manuals. Save items into your study locker for one-click bundle access.
            </p>
          </div>

          {/* Floating Cart / Locker Trigger Button */}
          <div>
            <button
              type="button"
              className="btn-primary"
              style={{
                width: 'auto',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 18px',
                fontSize: '0.95rem',
              }}
              onClick={() => setIsLockerModalOpen(true)}
            >
              <span>🛒 Open Study Locker</span>
              <span
                style={{
                  backgroundColor: '#ffffff',
                  color: 'var(--primary-medium)',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  fontWeight: 'bold',
                  fontSize: '0.85rem',
                }}
              >
                {totalCount}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Search and Subject Filter Bar */}
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
          <input
            type="text"
            className="form-input"
            placeholder="🔍 Search textbooks, formulas, past papers, lab manuals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{ flex: 1, minWidth: '240px' }}
          />

          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {subjects.map((sub) => (
              <button
                key={sub}
                type="button"
                className={selectedSubject === sub ? 'btn-primary' : 'btn-secondary'}
                style={{ width: 'auto', padding: '6px 12px', fontSize: '0.82rem' }}
                onClick={() => setSelectedSubject(sub)}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Materials Grid */}
      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.3rem' }}>
            Available Course Resources ({filteredMaterials.length})
          </h3>
          <span style={{ fontSize: '0.8rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '4px 10px', borderRadius: '12px', fontWeight: 'bold' }}>
            Verified Faculty Resources
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '18px' }}>
          {filteredMaterials.map((item) => {
            const inLocker = isInLocker(item.id);

            return (
              <article
                key={item.id}
                className="card"
                style={{
                  borderLeft: `5px solid ${inLocker ? '#16a34a' : 'var(--primary-medium)'}`,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  gap: '14px',
                  backgroundColor: inLocker ? '#fcfdfd' : 'var(--bg-white)',
                }}
              >
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '6px' }}>
                    <span style={{ fontSize: '0.75rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '3px 8px', borderRadius: '4px', fontWeight: 'bold' }}>
                      {item.subject}
                    </span>
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                      📥 {item.downloads} downloads
                    </span>
                  </div>

                  <h4 style={{ margin: '10px 0 6px 0', fontSize: '1.15rem', color: 'var(--primary-dark)', lineHeight: '1.4' }}>
                    {item.title}
                  </h4>

                  <div style={{ display: 'inline-block', backgroundColor: '#f1f5f9', color: '#475569', padding: '2px 8px', borderRadius: '4px', fontSize: '0.78rem', fontWeight: '600', marginBottom: '8px' }}>
                    🏷️ {item.type} · {item.fileSize}
                  </div>

                  <p style={{ margin: 0, fontSize: '0.88rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
                    {item.description}
                  </p>

                  <div style={{ marginTop: '10px', fontSize: '0.8rem', color: '#0369a1', fontStyle: 'italic' }}>
                    ⭐ {item.facultyTag}
                  </div>
                </div>

                <div style={{ paddingTop: '10px', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8rem', color: inLocker ? '#16a34a' : 'var(--text-muted)', fontWeight: inLocker ? 'bold' : 'normal' }}>
                    {inLocker ? '✓ Saved in Locker' : 'Available for Offline Study'}
                  </span>

                  <button
                    type="button"
                    className={inLocker ? 'btn-secondary' : 'btn-primary'}
                    style={{
                      width: 'auto',
                      fontSize: '0.85rem',
                      padding: '6px 14px',
                      backgroundColor: inLocker ? undefined : '#2563eb',
                      borderColor: inLocker ? undefined : '#2563eb',
                    }}
                    onClick={() => handleToggleLocker(item)}
                  >
                    {inLocker ? '❌ Remove' : '🛒 Add to Locker'}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* ───────────────────────────────────────────────────────────── */}
      {/* STUDY LOCKER / CART MODAL (Shopping Cart Pattern)              */}
      {/* ───────────────────────────────────────────────────────────── */}
      <Modal
        isOpen={isLockerModalOpen}
        onClose={() => setIsLockerModalOpen(false)}
        title={`🛒 My Study Locker & Cart (${totalCount} Items)`}
        maxWidth="640px"
        footer={
          <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', alignItems: 'center' }}>
            <button
              type="button"
              className="btn-secondary"
              style={{ width: 'auto', fontSize: '0.85rem', color: '#dc2626' }}
              onClick={clearLocker}
              disabled={lockerItems.length === 0}
            >
              Empty Locker
            </button>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button
                type="button"
                className="btn-secondary"
                style={{ width: 'auto', fontSize: '0.85rem' }}
                onClick={() => setIsLockerModalOpen(false)}
              >
                Continue Browsing
              </button>
              <button
                type="button"
                className="btn-primary"
                style={{ width: 'auto', fontSize: '0.85rem', backgroundColor: '#16a34a', borderColor: '#16a34a' }}
                onClick={handleDownloadAll}
                disabled={lockerItems.length === 0}
              >
                📦 Checkout &amp; Download Bundle
              </button>
            </div>
          </div>
        }
      >
        {lockerItems.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '36px', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: '3rem', marginBottom: '12px' }}>🛒</div>
            <h4 style={{ margin: '0 0 6px 0', color: 'var(--primary-dark)' }}>Your Study Locker is Empty</h4>
            <p style={{ margin: 0, fontSize: '0.9rem' }}>
              Browse the course textbooks, lab manuals, and question banks above, and click <strong>"Add to Locker"</strong> to collect your study bundle!
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '4px' }}>
              Review your collected semester study materials before downloading the study package:
            </div>

            {lockerItems.map((item, idx) => (
              <div
                key={item.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '12px 14px',
                  backgroundColor: '#f8fafc',
                  borderRadius: '8px',
                  border: '1px solid var(--border-color)',
                  gap: '10px',
                }}
              >
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ fontSize: '0.72rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '2px 6px', borderRadius: '4px', fontWeight: 'bold' }}>
                      {item.subject}
                    </span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{item.fileSize}</span>
                  </div>
                  <div style={{ fontWeight: 'bold', fontSize: '0.92rem', color: 'var(--primary-dark)', marginTop: '4px' }}>
                    {item.title}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => removeFromLocker(item.id)}
                  style={{
                    background: 'none',
                    border: 'none',
                    color: '#dc2626',
                    cursor: 'pointer',
                    fontSize: '0.85rem',
                    fontWeight: 'bold',
                    padding: '4px 8px',
                  }}
                  title="Remove from locker"
                >
                  ✕ Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}

export default StudyMaterialStore;
