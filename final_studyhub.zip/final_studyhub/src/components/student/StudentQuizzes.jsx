import React, { useState, useEffect } from 'react';
import { INITIAL_COLLEGE_QUIZZES, INITIAL_QUIZ_SUBMISSIONS } from '../../data/mockData';
import Toast from '../common/Toast';
import ProgressBar from '../common/ProgressBar';

const STORAGE_QUIZZES_KEY = 'studysphere_quizzes';
const STORAGE_SUBMISSIONS_KEY = 'studysphere_quiz_submissions';

function StudentQuizzes({ user = {} }) {
  const [toast, setToast] = useState(null);
  const [activeQuiz, setActiveQuiz] = useState(null); // Quiz currently being attempted
  const [reviewingQuiz, setReviewingQuiz] = useState(null); // Quiz being reviewed

  // Quiz taking state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState({}); // { [qId]: optionIndex }
  const [secondsRemaining, setSecondsRemaining] = useState(0);
  const [filterView, setFilterView] = useState('All'); // 'All' | 'Pending' | 'Completed'

  // Load quizzes from localStorage
  const [quizzes, setQuizzes] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_QUIZZES_KEY);
      return saved ? JSON.parse(saved) : INITIAL_COLLEGE_QUIZZES;
    } catch {
      return INITIAL_COLLEGE_QUIZZES;
    }
  });

  // Load student submissions from localStorage
  const [submissions, setSubmissions] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_SUBMISSIONS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_QUIZ_SUBMISSIONS;
    } catch {
      return INITIAL_QUIZ_SUBMISSIONS;
    }
  });

  // Persist submissions
  useEffect(() => {
    localStorage.setItem(STORAGE_SUBMISSIONS_KEY, JSON.stringify(submissions));
  }, [submissions]);

  // Sync quizzes and submissions when storage changes (e.g. mentor added a quiz)
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const savedQz = localStorage.getItem(STORAGE_QUIZZES_KEY);
        if (savedQz) setQuizzes(JSON.parse(savedQz));
        const savedSubs = localStorage.getItem(STORAGE_SUBMISSIONS_KEY);
        if (savedSubs) setSubmissions(JSON.parse(savedSubs));
      } catch {
        // fallback
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Timer countdown effect when quiz is active
  useEffect(() => {
    if (!activeQuiz || secondsRemaining <= 0) return;
    const interval = setInterval(() => {
      setSecondsRemaining((sec) => {
        if (sec <= 1) {
          clearInterval(interval);
          handleAutoSubmit();
          return 0;
        }
        return sec - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeQuiz, secondsRemaining]);

  // Start taking a quiz
  const handleStartQuiz = (quiz) => {
    setActiveQuiz(quiz);
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setSecondsRemaining((quiz.durationMinutes || 10) * 60);
    window.scrollTo({ top: 100, behavior: 'smooth' });
  };

  // Option select
  const handleSelectOption = (qId, optionIdx) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [qId]: optionIdx,
    });
  };

  // Auto-submit on time expired
  const handleAutoSubmit = () => {
    setToast({ message: 'Time expired! Auto-submitting your quiz answers...', type: 'warning' });
    handleSubmitQuiz();
  };

  // Submit Quiz Calculation
  const handleSubmitQuiz = () => {
    if (!activeQuiz) return;

    let score = 0;
    const questions = activeQuiz.questions || [];
    const pointsPerQuestion = questions.length > 0 ? activeQuiz.totalMarks / questions.length : 10;

    questions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        score += pointsPerQuestion;
      }
    });

    const percentage = Math.round((score / activeQuiz.totalMarks) * 100);

    const newSubmission = {
      quizId: activeQuiz.id,
      studentId: user?.id || 'STU2026',
      studentName: user?.name || 'Aarav Sharma',
      studentRoll: user?.roll || '22CS101',
      score: Math.round(score),
      totalMarks: activeQuiz.totalMarks,
      percentage,
      submittedAt: new Date().toLocaleString(),
      answers: selectedAnswers,
      timeTakenSeconds: (activeQuiz.durationMinutes * 60) - secondsRemaining,
    };

    setSubmissions([newSubmission, ...submissions.filter((s) => s.quizId !== activeQuiz.id)]);
    setActiveQuiz(null);
    setReviewingQuiz({ quiz: activeQuiz, submission: newSubmission });
    setToast({
      message: `Quiz submitted successfully! Score: ${newSubmission.score} / ${newSubmission.totalMarks} (${percentage}%) 🎉`,
      type: 'success',
    });
  };

  // Format MM:SS
  const formatTime = (secs) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
  };

  // Check if a quiz is already submitted
  const getSubmission = (quizId) => {
    return submissions.find((s) => s.quizId === quizId);
  };

  // Filter quizzes
  const filteredQuizzes = quizzes.filter((quiz) => {
    const hasSubmitted = !!getSubmission(quiz.id);
    if (filterView === 'Pending') return !hasSubmitted;
    if (filterView === 'Completed') return hasSubmitted;
    return true;
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              📝 Assigned Quizzes &amp; Tests
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Interactive assessments and preparation tests published by your faculty mentors for continuous evaluation.
            </p>
          </div>
          {/* Filter Pills */}
          <div style={{ display: 'flex', gap: '8px' }}>
            {['All', 'Pending', 'Completed'].map((tab) => (
              <button
                key={tab}
                type="button"
                className={filterView === tab ? 'btn-primary' : 'btn-secondary'}
                style={{ width: 'auto', padding: '6px 14px', fontSize: '0.85rem' }}
                onClick={() => setFilterView(tab)}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ───────────────────────────────────────────────────────────── */}
      {/* ACTIVE QUIZ TAKING INTERFACE                                  */}
      {/* ───────────────────────────────────────────────────────────── */}
      {activeQuiz && (
        <section
          className="card"
          style={{
            border: '2px solid var(--primary-medium)',
            boxShadow: '0 8px 24px rgba(37, 99, 235, 0.15)',
            padding: '24px',
          }}
        >
          {/* Quiz Header & Live Timer */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', borderBottom: '1px solid var(--border-color)', paddingBottom: '14px' }}>
            <div>
              <span style={{ fontSize: '0.8rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '3px 8px', borderRadius: '4px', fontWeight: 'bold' }}>
                {activeQuiz.subject}
              </span>
              <h3 style={{ margin: '6px 0 0 0', color: 'var(--primary-dark)', fontSize: '1.3rem' }}>
                {activeQuiz.title}
              </h3>
            </div>

            {/* Countdown Badge */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                backgroundColor: secondsRemaining < 120 ? '#fee2e2' : '#eff6ff',
                color: secondsRemaining < 120 ? '#dc2626' : 'var(--primary-medium)',
                border: `1px solid ${secondsRemaining < 120 ? '#fca5a5' : '#bfdbfe'}`,
                padding: '8px 16px',
                borderRadius: '24px',
                fontWeight: 'bold',
                fontSize: '1.1rem',
              }}
            >
              ⏱️ Time Left: {formatTime(secondsRemaining)}
            </div>
          </div>

          {/* Progress Bar */}
          <div style={{ marginTop: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '6px' }}>
              <span>Question {currentQuestionIndex + 1} of {activeQuiz.questions.length}</span>
              <span>{Math.round(((currentQuestionIndex + 1) / activeQuiz.questions.length) * 100)}% Completed</span>
            </div>
            <ProgressBar
              percentage={Math.round(((currentQuestionIndex + 1) / activeQuiz.questions.length) * 100)}
              height="8px"
            />
          </div>

          {/* Current Question Body */}
          {(() => {
            const currentQ = activeQuiz.questions[currentQuestionIndex];
            const currentSelected = selectedAnswers[currentQ.id];

            return (
              <div style={{ marginTop: '24px' }}>
                <h4 style={{ fontSize: '1.15rem', color: 'var(--primary-dark)', lineHeight: '1.5', margin: '0 0 18px 0' }}>
                  {currentQuestionIndex + 1}. {currentQ.questionText}
                </h4>

                {/* Options List */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {currentQ.options.map((opt, oIdx) => {
                    const isSelected = currentSelected === oIdx;
                    return (
                      <div
                        key={oIdx}
                        onClick={() => handleSelectOption(currentQ.id, oIdx)}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '12px',
                          padding: '14px 18px',
                          borderRadius: '8px',
                          border: `2px solid ${isSelected ? 'var(--primary-medium)' : 'var(--border-color)'}`,
                          backgroundColor: isSelected ? 'var(--primary-subtle)' : 'var(--bg-white)',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        <div
                          style={{
                            width: '24px',
                            height: '24px',
                            borderRadius: '50%',
                            border: `2px solid ${isSelected ? 'var(--primary-medium)' : '#94a3b8'}`,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '0.8rem',
                            fontWeight: 'bold',
                            backgroundColor: isSelected ? 'var(--primary-medium)' : 'transparent',
                            color: isSelected ? '#ffffff' : '#64748b',
                          }}
                        >
                          {String.fromCharCode(65 + oIdx)}
                        </div>
                        <span style={{ fontSize: '0.95rem', color: isSelected ? 'var(--primary-dark)' : 'var(--text-primary)', fontWeight: isSelected ? '600' : 'normal' }}>
                          {opt}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Quiz Navigation Controls */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '28px', paddingTop: '16px', borderTop: '1px solid var(--border-color)' }}>
                  <button
                    type="button"
                    className="btn-secondary"
                    style={{ width: 'auto' }}
                    disabled={currentQuestionIndex === 0}
                    onClick={() => setCurrentQuestionIndex((i) => i - 1)}
                  >
                    ← Previous Question
                  </button>

                  <div style={{ display: 'flex', gap: '10px' }}>
                    {currentQuestionIndex < activeQuiz.questions.length - 1 ? (
                      <button
                        type="button"
                        className="btn-primary"
                        style={{ width: 'auto' }}
                        onClick={() => setCurrentQuestionIndex((i) => i + 1)}
                      >
                        Next Question →
                      </button>
                    ) : (
                      <button
                        type="button"
                        className="btn-primary"
                        style={{ width: 'auto', backgroundColor: '#16a34a', borderColor: '#16a34a' }}
                        onClick={handleSubmitQuiz}
                      >
                        🏁 Submit Quiz
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}
        </section>
      )}

      {/* ───────────────────────────────────────────────────────────── */}
      {/* REVIEW ANSWERS / RESULT MODAL                                 */}
      {/* ───────────────────────────────────────────────────────────── */}
      {reviewingQuiz && (
        <section className="card" style={{ border: '2px solid var(--primary-medium)', padding: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '10px' }}>
            <div>
              <span style={{ backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '3px 8px', borderRadius: '4px', fontSize: '0.8rem', fontWeight: 'bold' }}>
                {reviewingQuiz.quiz.subject}
              </span>
              <h3 style={{ margin: '6px 0 0 0', color: 'var(--primary-dark)', fontSize: '1.3rem' }}>
                Scorecard &amp; Solution Review: {reviewingQuiz.quiz.title}
              </h3>
            </div>
            <button
              type="button"
              className="btn-secondary"
              style={{ width: 'auto', fontSize: '0.85rem' }}
              onClick={() => setReviewingQuiz(null)}
            >
              ✖ Close Review
            </button>
          </div>

          {/* Scorecard Hero */}
          <div
            style={{
              backgroundColor: reviewingQuiz.submission.percentage >= 60 ? '#f0fdf4' : '#fef2f2',
              border: `2px solid ${reviewingQuiz.submission.percentage >= 60 ? '#86efac' : '#fca5a5'}`,
              borderRadius: '10px',
              padding: '18px 24px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '12px',
              marginBottom: '20px',
            }}
          >
            <div>
              <div style={{ fontSize: '0.85rem', color: reviewingQuiz.submission.percentage >= 60 ? '#166534' : '#991b1b', textTransform: 'uppercase', fontWeight: 'bold' }}>
                Assessment Result
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 'bold', color: reviewingQuiz.submission.percentage >= 60 ? '#15803d' : '#b91c1c' }}>
                {reviewingQuiz.submission.score} / {reviewingQuiz.submission.totalMarks} Marks ({reviewingQuiz.submission.percentage}%)
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <span
                style={{
                  padding: '6px 16px',
                  borderRadius: '20px',
                  fontWeight: 'bold',
                  fontSize: '0.9rem',
                  backgroundColor: reviewingQuiz.submission.percentage >= 60 ? '#15803d' : '#b91c1c',
                  color: '#ffffff',
                }}
              >
                {reviewingQuiz.submission.percentage >= 60 ? 'Passed ✅' : 'Needs Support ⚠️'}
              </span>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Submitted: {reviewingQuiz.submission.submittedAt}
              </div>
            </div>
          </div>

          {/* Question-by-Question Solution Breakdown */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {reviewingQuiz.quiz.questions.map((q, idx) => {
              const studentAnswerIdx = reviewingQuiz.submission.answers[q.id];
              const isCorrect = studentAnswerIdx === q.correctIndex;

              return (
                <div
                  key={q.id || idx}
                  style={{
                    padding: '16px',
                    borderRadius: '8px',
                    border: `1px solid ${isCorrect ? '#86efac' : '#fca5a5'}`,
                    backgroundColor: isCorrect ? '#fcfdfd' : '#fffcfc',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <span style={{ fontWeight: 'bold', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>
                      Question {idx + 1}
                    </span>
                    <span style={{ fontSize: '0.85rem', fontWeight: 'bold', color: isCorrect ? '#16a34a' : '#dc2626' }}>
                      {isCorrect ? '✓ Correct (+10 Marks)' : '✗ Incorrect (0 Marks)'}
                    </span>
                  </div>

                  <p style={{ margin: '0 0 10px 0', fontSize: '0.95rem', color: 'var(--text-primary)' }}>
                    {q.questionText}
                  </p>

                  {/* Options */}
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '8px', fontSize: '0.88rem' }}>
                    {q.options.map((opt, oIdx) => {
                      const isStudentPick = studentAnswerIdx === oIdx;
                      const isTargetCorrect = q.correctIndex === oIdx;

                      let bg = '#f8fafc';
                      let border = 'var(--border-color)';
                      let label = '';

                      if (isTargetCorrect) {
                        bg = '#dcfce7';
                        border = '#86efac';
                        label = '✓ Correct Answer';
                      } else if (isStudentPick && !isCorrect) {
                        bg = '#fee2e2';
                        border = '#fca5a5';
                        label = '✗ Your Choice';
                      }

                      return (
                        <div
                          key={oIdx}
                          style={{
                            padding: '8px 12px',
                            borderRadius: '6px',
                            backgroundColor: bg,
                            border: `1px solid ${border}`,
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                          }}
                        >
                          <span>
                            <strong>{String.fromCharCode(65 + oIdx)}:</strong> {opt}
                          </span>
                          {label && (
                            <span style={{ fontSize: '0.72rem', fontWeight: 'bold', color: isTargetCorrect ? '#15803d' : '#b91c1c' }}>
                              {label}
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {/* Explanation */}
                  {q.explanation && (
                    <div style={{ marginTop: '10px', backgroundColor: '#f1f5f9', padding: '10px 12px', borderRadius: '6px', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                      💡 <strong>Faculty Explanation:</strong> {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* ───────────────────────────────────────────────────────────── */}
      {/* QUIZ LIST                                                     */}
      {/* ───────────────────────────────────────────────────────────── */}
      <section>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <h3 style={{ margin: 0, color: 'var(--primary-dark)', fontSize: '1.3rem' }}>
            📚 Available Course Quizzes ({filteredQuizzes.length})
          </h3>
          <span style={{ fontSize: '0.8rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '4px 10px', borderRadius: '12px', fontWeight: 'bold' }}>
            Faculty Mentor Assessments
          </span>
        </div>

        {filteredQuizzes.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '40px', color: 'var(--text-secondary)' }}>
            No quizzes match this filter. Check back soon for new assignments!
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {filteredQuizzes.map((quiz) => {
              const submission = getSubmission(quiz.id);

              return (
                <article
                  key={quiz.id}
                  className="card"
                  style={{
                    borderLeft: `5px solid ${submission ? '#16a34a' : 'var(--primary-medium)'}`,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                        <span style={{ backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem', fontWeight: 'bold' }}>
                          📚 {quiz.subject}
                        </span>
                        <span style={{ backgroundColor: '#f1f5f9', color: '#475569', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem' }}>
                          ⏱️ {quiz.durationMinutes} Minutes
                        </span>
                        <span style={{ backgroundColor: '#f1f5f9', color: '#475569', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem' }}>
                          ❓ {quiz.questions ? quiz.questions.length : 0} Questions
                        </span>
                      </div>

                      <h4 style={{ margin: '8px 0 4px 0', color: 'var(--primary-dark)', fontSize: '1.25rem' }}>
                        {quiz.title}
                      </h4>
                      <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
                        {quiz.description}
                      </p>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '1.2rem', fontWeight: 'bold', color: 'var(--primary-dark)' }}>
                        {quiz.totalMarks} Marks
                      </div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                        Due: <strong>{quiz.dueDate}</strong>
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px', paddingTop: '10px', borderTop: '1px solid var(--border-color)' }}>
                    <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                      👨‍🏫 Mentor: <strong>{quiz.mentorName}</strong>
                    </div>

                    <div>
                      {submission ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <span
                            style={{
                              padding: '5px 12px',
                              borderRadius: '16px',
                              fontSize: '0.82rem',
                              fontWeight: 'bold',
                              backgroundColor: submission.percentage >= 60 ? '#dcfce7' : '#fee2e2',
                              color: submission.percentage >= 60 ? '#15803d' : '#b91c1c',
                            }}
                          >
                            Score: {submission.score} / {submission.totalMarks} ({submission.percentage}%)
                          </span>
                          <button
                            type="button"
                            className="btn-secondary"
                            style={{ width: 'auto', fontSize: '0.85rem', padding: '6px 14px' }}
                            onClick={() => setReviewingQuiz({ quiz, submission })}
                          >
                            📊 Review Answers
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          className="btn-primary"
                          style={{ width: 'auto', fontSize: '0.88rem', padding: '8px 20px' }}
                          onClick={() => handleStartQuiz(quiz)}
                        >
                          🚀 Start Quiz ({quiz.durationMinutes}m)
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

export default StudentQuizzes;
