import React, { useState, useEffect } from 'react';
import { TimerIcon } from '../common/Icons';

function FocusTimer() {
  const [selectedDuration, setSelectedDuration] = useState(25 * 60);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let interval;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
      alert('🔔 Focus session completed! Great job taking a well-deserved break.');
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => setIsActive(true);
  const handlePause = () => setIsActive(false);
  const handleReset = () => {
    setIsActive(false);
    setTimeLeft(selectedDuration);
  };

  const handleSelectPreset = (minutes) => {
    const totalSeconds = minutes * 60;
    setSelectedDuration(totalSeconds);
    setTimeLeft(totalSeconds);
    setIsActive(false);
  };

  return (
    <div className="card timer-card">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', marginBottom: '8px', color: 'var(--primary-dark)' }}>
        <TimerIcon size={32} />
        <h2 style={{ margin: 0, fontSize: '1.7rem' }}>Academic Focus &amp; Study Timer</h2>
      </div>
      <p style={{ color: 'var(--text-secondary)', fontSize: '1rem', marginBottom: '20px' }}>
        Boost concentration and retention with structured study intervals.
      </p>

      {/* Preset Duration Buttons */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginBottom: '24px', flexWrap: 'wrap' }}>
        {[
          { label: '25m Pomodoro', mins: 25 },
          { label: '45m Deep Study', mins: 45 },
          { label: '60m Lab Session', mins: 60 },
        ].map((preset) => (
          <button
            key={preset.mins}
            type="button"
            className={selectedDuration === preset.mins * 60 ? 'btn-primary' : 'btn-secondary'}
            style={{ width: 'auto', padding: '6px 14px', fontSize: '0.88rem' }}
            onClick={() => handleSelectPreset(preset.mins)}
          >
            {preset.label}
          </button>
        ))}
      </div>

      <div className="timer-display">
        {formatTime(timeLeft)}
      </div>

      <div className="timer-controls">
        {!isActive ? (
          <button className="btn-primary" onClick={handleStart} style={{ minWidth: '120px' }}>
            ▶️ Start Session
          </button>
        ) : (
          <button className="btn-secondary" onClick={handlePause} style={{ minWidth: '120px' }}>
            ⏸️ Pause
          </button>
        )}
        <button className="btn-secondary" onClick={handleReset} style={{ minWidth: '100px' }}>
          🔄 Reset
        </button>
      </div>
    </div>
  );
}

export default FocusTimer;
