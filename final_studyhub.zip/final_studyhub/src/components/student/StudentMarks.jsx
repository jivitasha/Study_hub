import React, { useState } from 'react';
import { DEMO_STUDENT_MARKS } from '../../data/mockData';
import MarksSummary from '../marks/MarksSummary';
import MarksTable from '../marks/MarksTable';
import SubjectMarkCard from '../marks/SubjectMarkCard';
import { MarksIcon } from '../common/Icons';

function StudentMarks() {
  const [selectedFilter, setSelectedFilter] = useState('All Subjects');
  const filteredMarks = selectedFilter === 'All Subjects' 
    ? DEMO_STUDENT_MARKS 
    : DEMO_STUDENT_MARKS.filter((item) => item.subject === selectedFilter);

  const totalObtained = DEMO_STUDENT_MARKS.reduce((acc, item) => acc + item.obtained, 0);
  const grandTotal = DEMO_STUDENT_MARKS.reduce((acc, item) => acc + item.total, 0);
  const overallPercentage = (totalObtained / grandTotal * 100).toFixed(1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      
      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ color: 'var(--primary-medium)', display: 'flex', alignItems: 'center' }}>
            <MarksIcon size={28} />
          </div>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              Semester Evaluation &amp; Course Marks
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Detailed breakdown of your semester evaluation scores, percentages, and course grades.
            </p>
          </div>
        </div>
      </div>

      <MarksSummary
        totalObtained={totalObtained}
        grandTotal={grandTotal}
        overallPercentage={overallPercentage}
        overallGrade="Outstanding (A+)"
        rank={4}
      />

      {/* Performance Insight Card */}
      <div className="card" style={{ borderLeft: '5px solid var(--primary-medium)' }}>
        <h3 style={{ color: 'var(--primary-dark)', marginBottom: '6px' }}>💡 Performance Insight</h3>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          "Your strongest course is <strong>Coursera NPTEL Elective (95/100)</strong>. Keep practicing numerical exercises in <strong>Applied Statistics (86/100)</strong> to boost your cumulative semester score."
        </p>
      </div>

      {/* Drop down section */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', marginBottom: '16px' }}>
          <h3 style={{ color: 'var(--primary-dark)', margin: 0 }}>📋 Subject-Wise Marks Breakdown</h3>
          
          {/* Controlled Select Input */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <label htmlFor="subject-filter" style={{ fontWeight: '600', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
              Filter Course:
            </label>
            <select
              id="subject-filter"
              className="form-select"
              value={selectedFilter}
              onChange={(e) => setSelectedFilter(e.target.value)}
              style={{ width: 'auto', minWidth: '180px', padding: '6px 12px' }}
            >
              <option value="All Subjects">All Courses</option>
              {DEMO_STUDENT_MARKS.map((m) => (
                <option key={m.id} value={m.subject}>{m.subject}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Desktop View Table */}
        <div className="desktop-view">
          <MarksTable marksList={filteredMarks} />
        </div>

        {/* Mobile View Cards */}
        <div className="mobile-view" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {filteredMarks.map((m) => (
            <SubjectMarkCard key={m.id} subjectData={m} />
          ))}
        </div>
      </div>

    </div>
  );
}

export default StudentMarks;
