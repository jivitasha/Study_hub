import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { INITIAL_STUDENT_TASKS, INITIAL_TEACHER_FEEDBACK, INITIAL_COLLEGE_QUIZZES } from '../../data/mockData';
import ProgressBar from '../common/ProgressBar';

const MENTOR_NOTES_STORAGE_KEY = 'studysphere_mentor_notes';
const STORAGE_QUIZZES_KEY = 'studysphere_quizzes';
const STORAGE_XP_KEY = 'studysphere_student_xp';

const STUDY_TIPS = [
  { icon: '💡', title: 'Active Recall', text: 'Testing yourself with flashcards or practice questions yields up to 50% higher retention than passive reading.' },
  { icon: '🍅', title: 'Pomodoro Interval', text: 'Study with 100% focus for 25 minutes, then take a strict 5-minute break to avoid cognitive fatigue.' },
  { icon: '🧠', title: 'Feynman Technique', text: 'Explain complex algorithms simply in plain English. If you stumble, re-study that specific concept.' },
  { icon: '🔀', title: 'Interleaving Strategy', text: 'Alternate between DBMS queries and Statistics in one study block to sharpen conceptual flexibility.' },
  { icon: '🎯', title: '80/20 High-Yield Focus', text: 'Identify the core 20% of formulas and theory that account for 80% of university exam marks.' }
];

/**
 * StudentDashboard Component
 * Highly engaging academic command center:
 * - Dynamic greeting based on time of day
 * - Gamified Scholar Level & XP bar with daily reward claim
 * - Daily Study Tip interactive rotator
 * - Quick Action Cards for fast navigation
 * - Embedded Interactive Focus Timer
 * - Achievement Badges (Streak, Accuracy, Rank)
 * - Synced Mentor Notes and Quiz alerts
 * - Task Checklist with celebratory completion state
 */
function StudentDashboard({ user = {} }) {
  const [tasks, setTasks]         = useState(INITIAL_STUDENT_TASKS);
  const [loading, setLoading]     = useState(true);
  const [newTask, setNewTask]     = useState('');
  const [tipIndex, setTipIndex]   = useState(0);

  // Gamification XP state (awarded by Focus Sessions)
  const [xp, setXp] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_XP_KEY);
      return saved ? parseInt(saved, 10) : 840;
    } catch {
      return 840;
    }
  });

  // Quick Mini-Focus Timer state
  const [timerSeconds, setTimerSeconds] = useState(25 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [focusSessionsCompleted, setFocusSessionsCompleted] = useState(2);

  // Load mentor guidance notes broadcast to students
  const [mentorNotes, setMentorNotes] = useState(() => {
    try {
      const saved = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : INITIAL_TEACHER_FEEDBACK;
    } catch {
      return INITIAL_TEACHER_FEEDBACK;
    }
  });

  // Load quizzes published by mentors
  const [quizzes, setQuizzes] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_QUIZZES_KEY);
      return saved ? JSON.parse(saved) : INITIAL_COLLEGE_QUIZZES;
    } catch {
      return INITIAL_COLLEGE_QUIZZES;
    }
  });

  // Re-sync mentor notes & quizzes when storage changes
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const savedNotes = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
        if (savedNotes) setMentorNotes(JSON.parse(savedNotes));

        const savedQz = localStorage.getItem(STORAGE_QUIZZES_KEY);
        if (savedQz) setQuizzes(JSON.parse(savedQz));

        const savedXp = localStorage.getItem(STORAGE_XP_KEY);
        if (savedXp) setXp(parseInt(savedXp, 10));
      } catch {
        // fallback
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Timer countdown effect
  useEffect(() => {
    let interval = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      setFocusSessionsCompleted((prev) => prev + 1);
      // Award XP
      const newXp = xp + 50;
      setXp(newXp);
      localStorage.setItem(STORAGE_XP_KEY, String(newXp));
      alert('🎉 Awesome! 25-minute Focus Session complete! +50 Scholar XP awarded!');
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds, xp]);

  // Initial loading simulation
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 350);
    return () => clearTimeout(t);
  }, []);

  const completedCount     = tasks.filter((t) => t.completed).length;
  const totalTasks         = tasks.length;
  const progressPercentage = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  const handleToggleTask = (id) => {
    setTasks(tasks.map((task) => task.id === id ? { ...task, completed: !task.completed } : task));
  };

  const handleAddTask = (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    setTasks([...tasks, { id: Date.now(), title: newTask.trim(), completed: false }]);
    setNewTask('');
  };

  const nextStudyTip = () => {
    setTipIndex((prev) => (prev + 1) % STUDY_TIPS.length);
  };

  // Time-of-day greeting
  const currentHour = new Date().getHours();
  const timeGreeting = currentHour < 12 ? '🌅 Good morning' : currentHour < 17 ? '☀️ Good afternoon' : '🌙 Good evening';
  const todayFormatted = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' });

  // Format timer MM:SS
  const timerMinutes = String(Math.floor(timerSeconds / 60)).padStart(2, '0');
  const timerSecs = String(timerSeconds % 60).padStart(2, '0');

  if (loading) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '60px' }}>
        <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>⏳</div>
        <p style={{ color: 'var(--text-secondary)' }}>Loading your interactive academic workspace…</p>
      </div>
    );
  }

  const currentTip = STUDY_TIPS[tipIndex];

  return (
    <div>
      {/* Dynamic Welcome Hero Banner */}
      <div
        className="card"
        style={{
          marginBottom: '24px',
          background: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #2563eb 100%)',
          color: '#ffffff',
          padding: '28px',
          position: 'relative',
          overflow: 'hidden',
          borderRadius: 'var(--radius-md)',
          boxShadow: '0 8px 24px rgba(15, 23, 42, 0.15)'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
              <span className="pulse-dot"></span>
              <span style={{ fontSize: '0.85rem', color: '#93c5fd', fontWeight: '600', letterSpacing: '0.5px' }}>
                {todayFormatted} · SEMESTER 4 B.TECH CSE
              </span>
            </div>
            <h2 style={{ fontSize: '1.85rem', fontWeight: '800', margin: '0 0 6px 0', letterSpacing: '-0.5px' }}>
              {timeGreeting}, {user.name || 'Scholar'}!
            </h2>
            <p style={{ color: '#e0e7ff', margin: 0, fontSize: '0.98rem', maxWidth: '600px', lineHeight: '1.5' }}>
              Your academic momentum is looking strong. You have <strong>{quizzes.length} active quiz</strong> and <strong>{tasks.filter(t => !t.completed).length} study tasks</strong> queued for today.
            </p>
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS HUB */}
      <div style={{ marginBottom: '24px' }}>
        <h3 style={{ fontSize: '1rem', color: 'var(--text-secondary)', fontWeight: '700', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
          ⚡ Quick Action Center
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
          <Link to="/student/quizzes" className="quick-action-card">
            <div className="quick-action-icon" style={{ backgroundColor: '#eff6ff', color: '#2563eb' }}>
              📝
            </div>
            <div>
              <div style={{ fontWeight: '700', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>Attempt Quiz</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>{quizzes.length} Tests Ready</div>
            </div>
          </Link>

          <Link to="/student/materials" className="quick-action-card">
            <div className="quick-action-icon" style={{ backgroundColor: '#f0fdf4', color: '#16a34a' }}>
              🛒
            </div>
            <div>
              <div style={{ fontWeight: '700', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>Study Locker</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Notes &amp; E-Books</div>
            </div>
          </Link>

          <Link to="/student/timer" className="quick-action-card">
            <div className="quick-action-icon" style={{ backgroundColor: '#faf5ff', color: '#9333ea' }}>
              ⏱️
            </div>
            <div>
              <div style={{ fontWeight: '700', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>Focus Stopwatch</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Full Screen Timer</div>
            </div>
          </Link>

          <Link to="/parent/attendance" className="quick-action-card">
            <div className="quick-action-icon" style={{ backgroundColor: '#fff7ed', color: '#ea580c' }}>
              📅
            </div>
            <div>
              <div style={{ fontWeight: '700', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>Attendance Register</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>85.2% · Safe Cutoff</div>
            </div>
          </Link>
        </div>
      </div>

      {/* Gamified Achievements & Key Stats Row */}
      <div className="dashboard-grid">
        <div className="card" style={{ borderTop: '4px solid #2563eb' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="stat-card-lbl">🔥 Study Streak</div>
            <span className="badge-streak">On Fire!</span>
          </div>
          <div className="stat-card-val">6 Days</div>
          <p style={{ margin: '6px 0 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Log in tomorrow to reach a 7-day milestone badge.
          </p>
        </div>

        <div className="card" style={{ borderTop: '4px solid #10b981' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="stat-card-lbl">🎯 Quiz Accuracy</div>
            <span className="badge-rank">Top 5%</span>
          </div>
          <div className="stat-card-val">94.2%</div>
          <p style={{ margin: '6px 0 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Average score across DBMS &amp; Statistics tests.
          </p>
        </div>

        <div className="card" style={{ borderTop: '4px solid #f59e0b' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="stat-card-lbl">🏆 Cohort Rank</div>
            <span className="badge-xp">Honors</span>
          </div>
          <div className="stat-card-val">#4</div>
          <p style={{ margin: '6px 0 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Out of 78 engineering students in CSE Section A.
          </p>
        </div>

        <div className="card" style={{ borderTop: '4px solid #8b5cf6' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="stat-card-lbl">✅ Today's Tasks</div>
            <span style={{ fontSize: '0.8rem', fontWeight: '700', color: completedCount === totalTasks ? '#10b981' : 'var(--primary-medium)' }}>
              {progressPercentage}%
            </span>
          </div>
          <div className="stat-card-val">{completedCount} / {totalTasks}</div>
          <p style={{ margin: '6px 0 0 0', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            {totalTasks - completedCount > 0 ? `${totalTasks - completedCount} items pending completion` : 'All tasks cleared!'}
          </p>
        </div>
      </div>

      {/* Two-Column Interactive Row: Mini Focus Pomodoro & Daily Pro Study Tip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px', marginBottom: '28px' }}>
        
        {/* Interactive Mini Focus Session Widget */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '1.2rem' }}>⏱️</span>
                <h3 style={{ margin: 0, fontSize: '1.1rem', color: 'var(--primary-dark)' }}>Quick Focus Session</h3>
              </div>
              <span style={{ fontSize: '0.78rem', backgroundColor: '#eff6ff', color: '#2563eb', padding: '3px 8px', borderRadius: '12px', fontWeight: '700' }}>
                +50 XP on Finish
              </span>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', margin: 0 }}>
              Launch a distraction-free 25-minute sprint right now to crush your next topic.
            </p>
          </div>

          <div style={{ textAlign: 'center', padding: '16px 0' }}>
            <div
              style={{
                fontFamily: 'monospace',
                fontSize: '2.8rem',
                fontWeight: '800',
                letterSpacing: '2px',
                color: isTimerRunning ? 'var(--primary-medium)' : 'var(--primary-dark)',
                backgroundColor: 'var(--bg-cream)',
                padding: '10px',
                borderRadius: '12px',
                border: '1px solid var(--border-color)',
                display: 'inline-block',
                minWidth: '180px'
              }}
            >
              {timerMinutes}:{timerSecs}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className="btn-primary"
              style={{ flex: 1, padding: '10px 14px', fontSize: '0.9rem' }}
            >
              {isTimerRunning ? '⏸ Pause Focus' : '▶ Start 25m Focus'}
            </button>
            <button
              onClick={() => {
                setIsTimerRunning(false);
                setTimerSeconds(25 * 60);
              }}
              className="btn-secondary"
              style={{ padding: '10px 14px', fontSize: '0.85rem' }}
              title="Reset Timer"
            >
              ↺ Reset
            </button>
          </div>
          <div style={{ marginTop: '8px', textAlign: 'center', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
            Completed sessions today: <strong>{focusSessionsCompleted}</strong> ({focusSessionsCompleted * 25} mins total)
          </div>
        </div>

        {/* Interactive Rotating Study Tip Ticker */}
        <div
          className="card"
          style={{
            background: 'linear-gradient(145deg, #ffffff 0%, #f8fafc 100%)',
            border: '1px solid #e2e8f0',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between'
          }}
        >
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '1.2rem' }}>{currentTip.icon}</span>
                <h3 style={{ margin: 0, fontSize: '1.1rem', color: 'var(--primary-dark)' }}>Study Science Hack</h3>
              </div>
              <button
                onClick={nextStudyTip}
                className="btn-secondary"
                style={{ padding: '4px 10px', fontSize: '0.78rem' }}
                title="View another tip"
              >
                Next Tip ↺
              </button>
            </div>
            <h4 style={{ color: 'var(--primary-medium)', margin: '0 0 8px 0', fontSize: '1.05rem' }}>
              {currentTip.title}
            </h4>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.92rem', lineHeight: '1.55', margin: 0 }}>
              "{currentTip.text}"
            </p>
          </div>

          <div
            style={{
              marginTop: '16px',
              padding: '10px 14px',
              backgroundColor: '#f1f5f9',
              borderRadius: '8px',
              fontSize: '0.8rem',
              color: 'var(--text-secondary)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <span>💡 Tip {tipIndex + 1} of {STUDY_TIPS.length}</span>
            <span style={{ fontWeight: '600', color: 'var(--primary-medium)' }}>Evidence-Based Learning</span>
          </div>
        </div>

      </div>

      {/* SECTION: Mentor Guidance Notes for this Student */}
      {mentorNotes.length > 0 && (
        <div className="card" style={{ marginBottom: '28px', borderLeft: '5px solid var(--primary-medium)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <div>
              <h3 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.25rem' }}>
                🎓 Academic Guidance from Your Mentor ({mentorNotes.length})
              </h3>
              <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                Direct suggestions, feedback, and notes broadcasted by faculty mentors.
              </p>
            </div>
            <span style={{ fontSize: '0.8rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '4px 12px', borderRadius: '12px', fontWeight: 'bold' }}>
              Mentor Feedback Active
            </span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {mentorNotes.map((note) => (
              <div
                key={note.id}
                style={{
                  backgroundColor: 'var(--accent-cream)',
                  padding: '14px 16px',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-color)',
                  transition: 'transform 0.15s ease',
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: '700', color: 'var(--primary-dark)', fontSize: '0.95rem' }}>
                      📚 Course: {note.subject}
                    </span>
                    <span
                      style={{
                        fontSize: '0.75rem',
                        fontWeight: '600',
                        backgroundColor: note.studentName === 'All Students' ? 'var(--primary-subtle)' : '#f1f5f9',
                        color: note.studentName === 'All Students' ? 'var(--primary-medium)' : 'var(--text-secondary)',
                        padding: '2px 8px',
                        borderRadius: '6px',
                      }}
                    >
                      {note.studentName === 'All Students' ? '📢 All Students' : `👤 ${note.studentName}`}
                    </span>
                  </div>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    📅 {note.date} {note.mentorName ? `· Mentor: ${note.mentorName}` : ''}
                  </span>
                </div>
                <p style={{ marginTop: '8px', color: 'var(--text-primary)', fontSize: '0.92rem', lineHeight: '1.5' }}>
                  "{note.text}"
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION: Assigned Quizzes from Mentors */}
      {quizzes.length > 0 && (
        <div className="card" style={{ marginBottom: '28px', borderLeft: '5px solid #2563eb' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px', flexWrap: 'wrap', gap: '8px' }}>
            <div>
              <h3 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.25rem' }}>
                📝 Active Quizzes &amp; Tests Assigned ({quizzes.length})
              </h3>
              <p style={{ margin: '4px 0 0 0', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                Course evaluation quizzes published by faculty mentors for continuous assessment.
              </p>
            </div>
            <Link to="/student/quizzes" className="btn-secondary" style={{ width: 'auto', fontSize: '0.85rem', textDecoration: 'none' }}>
              View All Quizzes →
            </Link>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '14px' }}>
            {quizzes.slice(0, 2).map((quiz) => (
              <div
                key={quiz.id}
                style={{
                  backgroundColor: '#f8fafc',
                  padding: '16px',
                  borderRadius: '10px',
                  border: '1px solid var(--border-color)',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  gap: '12px',
                  boxShadow: 'var(--shadow-sm)'
                }}
              >
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span style={{ fontSize: '0.75rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '3px 8px', borderRadius: '4px', fontWeight: 'bold' }}>
                      {quiz.subject}
                    </span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '600' }}>
                      ⏱️ {quiz.durationMinutes}m
                    </span>
                  </div>
                  <h4 style={{ margin: '10px 0 6px 0', fontSize: '1.05rem', color: 'var(--primary-dark)' }}>
                    {quiz.title}
                  </h4>
                  <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                    Due: <strong>{quiz.dueDate}</strong> · {quiz.totalMarks} Marks
                  </div>
                </div>

                <Link
                  to="/student/quizzes"
                  className="btn-primary"
                  style={{ width: '100%', textAlign: 'center', fontSize: '0.85rem', padding: '8px 12px', textDecoration: 'none' }}
                >
                  🚀 Take Quiz
                </Link>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Daily Study Task Goal with celebration */}
      <div className="card" style={{ marginBottom: '28px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ color: 'var(--primary-dark)', margin: 0 }}>🎯 Daily Study Task Goal</h3>
            <p style={{ margin: '4px 0 0 0', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Clear tasks to maintain your study streak and level up.
            </p>
          </div>
          <span style={{ fontWeight: '800', fontSize: '1.2rem', color: progressPercentage === 100 ? '#10b981' : 'var(--primary-medium)' }}>
            {progressPercentage}%
          </span>
        </div>
        <div style={{ marginTop: '12px' }}>
          <ProgressBar percentage={progressPercentage} height="14px" />
        </div>

        {progressPercentage === 100 && (
          <div
            style={{
              marginTop: '14px',
              backgroundColor: '#ecfdf5',
              border: '1px solid #a7f3d0',
              padding: '10px 14px',
              borderRadius: '8px',
              color: '#065f46',
              fontSize: '0.88rem',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <span>🎉</span> Outstanding work! You have finished 100% of today's study goals!
          </div>
        )}
      </div>

      {/* Task list */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h3 style={{ color: 'var(--primary-dark)', margin: 0 }}>📋 Today's Study Tasks</h3>
          <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
            {completedCount} of {totalTasks} finished
          </span>
        </div>

        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {tasks.map((task) => (
            <li
              key={task.id}
              className="task-item-interactive"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                borderBottom: '1px solid var(--border-color)',
                cursor: 'pointer'
              }}
              onClick={() => handleToggleTask(task.id)}
            >
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => handleToggleTask(task.id)}
                onClick={(e) => e.stopPropagation()}
                style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: 'var(--primary-medium)' }}
              />
              <span
                style={{
                  fontSize: '0.95rem',
                  textDecoration: task.completed ? 'line-through' : 'none',
                  color: task.completed ? 'var(--text-muted)' : 'var(--text-primary)',
                  fontWeight: task.completed ? 'normal' : '500',
                  flex: 1
                }}
              >
                {task.title}
              </span>
              {task.completed && (
                <span style={{ fontSize: '0.75rem', color: '#10b981', fontWeight: 'bold' }}>✓ Done</span>
              )}
            </li>
          ))}
        </ul>

        {/* Add task form */}
        <form onSubmit={handleAddTask} style={{ display: 'flex', gap: '10px', marginTop: '18px' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Add a new study task or syllabus topic…"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
          />
          <button type="submit" className="btn-primary" style={{ width: 'auto', whiteSpace: 'nowrap' }}>
            + Add Task
          </button>
        </form>
      </div>
    </div>
  );
}

export default StudentDashboard;
