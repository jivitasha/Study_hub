import React, { useState, useEffect, useMemo } from 'react';
import { INITIAL_TEACHER_FEEDBACK } from '../../data/mockData';
import Toast from '../common/Toast';

const MENTOR_NOTES_STORAGE_KEY = 'studysphere_mentor_notes';

/**
 * Notes Component (Student View)
 * Displays mentor guidance notes, lecture tips, and recommendations published by faculty mentors.
 */
function MyNotes({ user = {} }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('All');
  const [toast, setToast] = useState(null);

  // Mentor guidance notes broadcast to students
  const [mentorNotes, setMentorNotes] = useState(() => {
    try {
      const saved = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
      return saved ? JSON.parse(saved) : INITIAL_TEACHER_FEEDBACK;
    } catch {
      return INITIAL_TEACHER_FEEDBACK;
    }
  });

  // Re-sync mentor notes if updated in another tab or mentor session
  useEffect(() => {
    const handleStorageChange = () => {
      try {
        const saved = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
        if (saved) {
          setMentorNotes(JSON.parse(saved));
        }
      } catch {
        // fallback
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Extract distinct subjects
  const subjects = useMemo(() => {
    const set = new Set();
    mentorNotes.forEach((n) => {
      if (n.subject) set.add(n.subject);
    });
    return ['All', ...Array.from(set)];
  }, [mentorNotes]);

  // Filter notes based on search keyword and selected subject
  const filteredNotes = useMemo(() => {
    return mentorNotes.filter((note) => {
      const matchesSubject = selectedSubject === 'All' || note.subject === selectedSubject;
      const term = searchTerm.toLowerCase().trim();
      const matchesSearch =
        !term ||
        (note.subject && note.subject.toLowerCase().includes(term)) ||
        (note.text && note.text.toLowerCase().includes(term)) ||
        (note.mentorName && note.mentorName.toLowerCase().includes(term)) ||
        (note.studentName && note.studentName.toLowerCase().includes(term));
      return matchesSubject && matchesSearch;
    });
  }, [mentorNotes, selectedSubject, searchTerm]);

  // Copy note text directly to clipboard
  const handleCopyNote = (note) => {
    const textToCopy = `Course: ${note.subject}\nMentor: ${note.mentorName || 'Faculty Mentor'}\nDate: ${note.date}\nGuidance: ${note.text}`;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(textToCopy);
      setToast({ message: 'Note copied to clipboard! 📋', type: 'success' });
    } else {
      setToast({ message: 'Guidance text selected! 📝', type: 'info' });
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Header Banner */}
      <div className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              📚 Notes &amp; Faculty Guidance
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '6px', fontSize: '0.95rem', maxWidth: '720px' }}>
              Official course study notes, lecture takeaways, and recommendations published by your mentors for all students.
            </p>
          </div>

          {/* Quick Stats */}
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <div
              style={{
                backgroundColor: 'var(--bg-white)',
                padding: '10px 16px',
                borderRadius: '8px',
                border: '1px solid var(--border-color)',
                textAlign: 'center',
                minWidth: '100px',
              }}
            >
              <div style={{ fontSize: '1.4rem', fontWeight: 'bold', color: 'var(--primary-medium)' }}>
                {mentorNotes.length}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                Total Notes
              </div>
            </div>

            <div
              style={{
                backgroundColor: 'var(--bg-white)',
                padding: '10px 16px',
                borderRadius: '8px',
                border: '1px solid var(--border-color)',
                textAlign: 'center',
                minWidth: '100px',
              }}
            >
              <div style={{ fontSize: '1.4rem', fontWeight: 'bold', color: 'var(--primary-dark)' }}>
                {subjects.length > 1 ? subjects.length - 1 : 1}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                Courses
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: '12px', flex: 1, minWidth: '260px', flexWrap: 'wrap' }}>
            {/* Search Input */}
            <input
              type="text"
              className="form-input"
              placeholder="🔍 Search notes by topic, keyword, or mentor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ flex: 1, minWidth: '220px' }}
            />

            {/* Subject Dropdown */}
            <select
              className="form-select"
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              style={{ width: 'auto', minWidth: '180px' }}
            >
              {subjects.map((sub) => (
                <option key={sub} value={sub}>
                  {sub === 'All' ? '📂 All Subjects' : `📚 ${sub}`}
                </option>
              ))}
            </select>
          </div>

          {/* Quick subject pills */}
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {subjects.slice(0, 4).map((sub) => (
              <button
                key={sub}
                type="button"
                className={selectedSubject === sub ? 'btn-primary' : 'btn-secondary'}
                style={{ width: 'auto', padding: '6px 12px', fontSize: '0.8rem' }}
                onClick={() => setSelectedSubject(sub)}
              >
                {sub === 'All' ? 'All' : sub}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Notes Grid */}
      <section>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px', flexWrap: 'wrap', gap: '8px' }}>
          <h3 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.3rem' }}>
            📖 Mentor Guidance Notes ({filteredNotes.length})
          </h3>
          <span style={{ fontSize: '0.8rem', backgroundColor: 'var(--primary-subtle)', color: 'var(--primary-medium)', padding: '4px 10px', borderRadius: '12px', fontWeight: 'bold' }}>
            Shared by Faculty Mentors
          </span>
        </div>

        {filteredNotes.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', padding: '48px 24px', color: 'var(--text-secondary)' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>📭</div>
            <h4 style={{ margin: '0 0 6px 0', color: 'var(--primary-dark)' }}>No Notes Found</h4>
            <p style={{ margin: 0, fontSize: '0.9rem' }}>
              {searchTerm || selectedSubject !== 'All'
                ? 'Try adjusting your search query or subject filter.'
                : 'No mentor notes have been posted yet. Any notes shared by faculty mentors will appear here!'}
            </p>
          </div>
        ) : (
          <div className="notes-grid">
            {filteredNotes.map((item) => (
              <article
                key={item.id}
                className="note-card"
                style={{
                  borderLeft: '5px solid var(--primary-medium)',
                  backgroundColor: 'var(--bg-white)',
                  boxShadow: 'var(--shadow-sm)',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  gap: '14px',
                }}
              >
                <div>
                  {/* Top Badges */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '6px' }}>
                    <span
                      style={{
                        fontSize: '0.78rem',
                        backgroundColor: item.studentName === 'All Students' ? 'var(--primary-subtle)' : '#f1f5f9',
                        color: item.studentName === 'All Students' ? 'var(--primary-medium)' : 'var(--text-secondary)',
                        padding: '3px 8px',
                        borderRadius: '6px',
                        fontWeight: '700',
                      }}
                    >
                      {item.studentName === 'All Students' ? '📢 All Students' : `👤 Mentee: ${item.studentName}`}
                    </span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      📅 {item.date}
                    </span>
                  </div>

                  {/* Course Title */}
                  <h4 className="note-card-title" style={{ marginTop: '12px', color: 'var(--primary-dark)', fontSize: '1.15rem' }}>
                    📚 {item.subject}
                  </h4>

                  {/* Faculty details */}
                  <div style={{ fontSize: '0.88rem', color: 'var(--text-secondary)', marginTop: '2px', fontWeight: '500' }}>
                    👨‍🏫 Faculty Mentor: <strong>{item.mentorName || 'Faculty Mentor'}</strong>
                  </div>

                  {/* Note Body */}
                  <div
                    style={{
                      fontSize: '0.93rem',
                      color: 'var(--text-primary)',
                      marginTop: '12px',
                      lineHeight: '1.65',
                      backgroundColor: 'var(--accent-cream)',
                      padding: '12px 14px',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      whiteSpace: 'pre-wrap',
                    }}
                  >
                    "{item.text}"
                  </div>
                </div>

                {/* Footer Actions */}
                <div style={{ paddingTop: '10px', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    Verified Academic Note
                  </span>
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={() => handleCopyNote(item)}
                    style={{ fontSize: '0.8rem', padding: '5px 12px', width: 'auto' }}
                    title="Copy note text to clipboard"
                  >
                    📋 Copy Text
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default MyNotes;
