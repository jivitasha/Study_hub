import React, { useState, useEffect, useRef } from 'react';
import ProgressBar from '../common/ProgressBar';
import Toast from '../common/Toast';
import { StudentAvatarIcon, ProfileIcon } from '../common/Icons';

export function StatCard({ title, value, icon }) {
  return (
    <div className="card">
      <div style={{ fontSize: '30px', marginBottom: '8px' }}>{icon}</div>
      <div className="stat-card-lbl">{title}</div>
      <div className="stat-card-val">{value}</div>
    </div>
  );
}

function StudentProfile({ user = {} }) {
  const fileInputRef = useRef(null);

  const [profile, setProfile] = useState(() => {
    const storageKey = user.id ? `studysphere_profile_${user.id}` : 'studysphere_profile';
    const savedProfile = localStorage.getItem(storageKey);
    if (savedProfile) {
      try {
        return JSON.parse(savedProfile);
      } catch {
        // fallback
      }
    }
    return {
      name: user.name || 'Aarav Sharma',
      studentClass: user.class || 'B.Tech CSE - Semester 6',
      studentId: user.id || 'STU2026',
      email: user.email || 'aarav@studysphere.edu',
      role: user.role || 'Student',
      avatar: null,
    };
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(profile.name);
  const [editClass, setEditClass] = useState(profile.studentClass);
  const [editEmail, setEditEmail] = useState(profile.email);
  const [editAvatar, setEditAvatar] = useState(profile.avatar);
  const [toastMessage, setToastMessage] = useState('');

  const [completedSessions, setCompletedSessions] = useState(() => {
    const savedSessions = localStorage.getItem('studysphere_sessions');
    return savedSessions !== null ? Number(savedSessions) : 3;
  });

  // Save profile to localStorage whenever updated
  useEffect(() => {
    const storageKey = user.id ? `studysphere_profile_${user.id}` : 'studysphere_profile';
    localStorage.setItem(storageKey, JSON.stringify(profile));
  }, [profile, user.id]);

  // Save completed study sessions count to localStorage
  useEffect(() => {
    localStorage.setItem('studysphere_sessions', completedSessions.toString());
  }, [completedSessions]);

  // Handle image upload via file reader
  const handleImageChange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      // Limit file size to 2MB to keep localStorage healthy
      if (file.size > 2 * 1024 * 1024) {
        alert('Please choose an image under 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result;
        if (isEditing) {
          setEditAvatar(result);
        } else {
          setProfile((prev) => ({ ...prev, avatar: result }));
          setEditAvatar(result);
          setToastMessage('Profile picture updated successfully! 📸');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    if (isEditing) {
      setEditAvatar(null);
    } else {
      setProfile((prev) => ({ ...prev, avatar: null }));
      setEditAvatar(null);
      setToastMessage('Profile picture removed.');
    }
  };

  // Save profile
  const handleSaveProfile = (e) => {
    e.preventDefault();
    const updatedProfile = {
      ...profile,
      name: editName,
      studentClass: editClass,
      email: editEmail,
      avatar: editAvatar,
    };
    setProfile(updatedProfile);
    setIsEditing(false);
    setToastMessage('Profile updated successfully! ✅');
  };

  // Cancel edit
  const handleCancelEdit = () => {
    setEditName(profile.name);
    setEditClass(profile.studentClass);
    setEditEmail(profile.email);
    setEditAvatar(profile.avatar);
    setIsEditing(false);
  };

  const handleAddSession = () => {
    if (completedSessions < 5) {
      setCompletedSessions((prev) => prev + 1);
    }
  };

  const totalGoalSessions = 5;
  const goalPercentage = Math.round((completedSessions / totalGoalSessions) * 100);

  const displayAvatar = isEditing ? editAvatar : profile.avatar;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {toastMessage && (
        <Toast
          message={toastMessage}
          type="success"
          onClose={() => setToastMessage('')}
        />
      )}

      {/* Hidden file input for photo upload */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleImageChange}
        accept="image/*"
        style={{ display: 'none' }}
      />

      {/* SECTION: Main Student Profile Card */}
      <section className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap' }}>
            {/* Profile Picture / Avatar */}
            <div style={{ position: 'relative' }}>
              <div
                style={{
                  width: '84px',
                  height: '84px',
                  borderRadius: '50%',
                  backgroundColor: 'var(--primary-dark)',
                  color: 'var(--bg-white)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '2.4rem',
                  fontWeight: 'bold',
                  overflow: 'hidden',
                  border: '3px solid var(--primary-light, #3b82f6)',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                  cursor: 'pointer',
                }}
                onClick={() => fileInputRef.current?.click()}
                title="Click to upload or change picture"
              >
                {displayAvatar ? (
                  <img
                    src={displayAvatar}
                    alt={profile.name}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                ) : (
                  <StudentAvatarIcon size={84} />
                )}
              </div>

              {/* Camera Icon Overlay */}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                title="Change Photo"
                style={{
                  position: 'absolute',
                  bottom: '-2px',
                  right: '-2px',
                  backgroundColor: 'var(--primary-dark)',
                  color: '#fff',
                  border: '2px solid #fff',
                  borderRadius: '50%',
                  width: '28px',
                  height: '28px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  fontSize: '0.85rem',
                }}
              >
                📷
              </button>
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <h2 style={{ color: 'var(--primary-dark)', fontSize: '1.6rem', margin: 0 }}>
                  {profile.name}
                </h2>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => fileInputRef.current?.click()}
                  style={{ fontSize: '0.8rem', padding: '4px 10px', height: 'auto' }}
                >
                  📷 Change Photo
                </button>
                {displayAvatar && (
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#dc2626',
                      cursor: 'pointer',
                      fontSize: '0.8rem',
                      textDecoration: 'underline',
                    }}
                  >
                    Remove
                  </button>
                )}
              </div>

              <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', marginTop: '6px' }}>
                🆔 ID: <strong>{profile.studentId}</strong> | 🏛️ Program: <strong>{profile.studentClass}</strong>
              </p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem', marginTop: '4px' }}>
                ✉️ Email: {profile.email} | 🏷️ Role: <span className="badge badge-ontrack">{profile.role}</span>
              </p>
            </div>
          </div>

          {!isEditing && (
            <button className="btn-secondary" onClick={() => setIsEditing(true)}>
              ✏️ Edit Profile
            </button>
          )}
        </div>

        {/* Profile edit section */}
        {isEditing && (
          <form onSubmit={handleSaveProfile} style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px solid var(--border-color)' }}>
            <h3 style={{ marginBottom: '16px', color: 'var(--primary-dark)' }}>✏️ Edit Profile Details</h3>

            <div className="form-group">
              <label className="form-label">Profile Picture</label>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => fileInputRef.current?.click()}
                >
                  📁 Choose New Photo
                </button>
                {editAvatar && (
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handleRemovePhoto}
                    style={{ color: '#dc2626' }}
                  >
                    🗑️ Remove Photo
                  </button>
                )}
              </div>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="edit-name">Student Name</label>
              <input
                id="edit-name"
                type="text"
                className="form-input"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="edit-class">Academic Program &amp; Semester</label>
              <input
                id="edit-class"
                type="text"
                className="form-input"
                value={editClass}
                onChange={(e) => setEditClass(e.target.value)}
                placeholder="e.g. B.Tech CSE - Semester 6"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="edit-email">Email Address</label>
              <input
                id="edit-email"
                type="email"
                className="form-input"
                value={editEmail}
                onChange={(e) => setEditEmail(e.target.value)}
                required
              />
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '16px' }}>
              <button type="submit" className="btn-primary" style={{ width: 'auto' }}>
                💾 Save Changes
              </button>
              <button type="button" className="btn-secondary" onClick={handleCancelEdit}>
                ✖️ Cancel
              </button>
            </div>
          </form>
        )}
      </section>

      {/* SECTION 1: Study Statistics */}
      <section>
        <h3 style={{ marginBottom: '14px', color: 'var(--primary-dark)' }}>📊 Study Statistics</h3>
        <div className="dashboard-grid">
          <StatCard title="Focus Time" value="12h 40m" icon="⏱️" />
          <StatCard title="Notes Created" value="8" icon="📝" />
          <StatCard title="Study Streak" value="6 days" icon="🔥" />
        </div>
      </section>

      {/* SECTION 2: Learning Goals */}
      <section className="card">
        <h3 style={{ color: 'var(--primary-dark)', marginBottom: '8px' }}>🎯 Weekly Learning Goals</h3>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
          Target: <strong>Complete 5 study sessions this week</strong>
        </p>

        <div style={{ margin: '16px 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.9rem', fontWeight: 'bold' }}>
            <span>Progress: {completedSessions}/{totalGoalSessions} Sessions</span>
            <span>{goalPercentage}%</span>
          </div>
          <ProgressBar percentage={goalPercentage} height="14px" />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
          <button
            className="btn-primary"
            style={{ width: 'auto' }}
            onClick={handleAddSession}
            disabled={completedSessions >= totalGoalSessions}
          >
            ➕ Add Study Session
          </button>

          {completedSessions >= totalGoalSessions && (
            <span style={{ color: '#1e40af', fontWeight: 'bold', backgroundColor: '#dbeafe', padding: '6px 12px', borderRadius: '8px' }}>
              🎉 Goal Completed! Amazing dedication this week!
            </span>
          )}
        </div>
      </section>

      {/* SECTION 3: Achievement */}
      <section className="achievement-card">
        <div className="achievement-icon">🔥</div>
        <div>
          <h4 style={{ fontSize: '1.2rem', marginBottom: '4px' }}>Achievement Unlocked: 6-day study streak!</h4>
          <p style={{ fontSize: '0.9rem', opacity: 0.9 }}>Keep studying consistently to reach 7 days!</p>
        </div>
      </section>
    </div>
  );
}

export default StudentProfile;
