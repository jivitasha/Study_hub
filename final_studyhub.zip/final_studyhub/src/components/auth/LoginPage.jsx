import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { BrandLogo } from '../common/Icons';

function LoginPage() {
  const { login } = useAuth();
  const location = useLocation();

  // If navigated from signup, pre-select the role and email that was just registered
  const [selectedRole, setSelectedRole] = useState(() => location.state?.registeredRole || 'Student');
  const [email, setEmail]               = useState(() => location.state?.registeredEmail || '');
  const [password, setPassword]         = useState('');
  const [errors, setErrors]             = useState({});
  const [errorMessage, setErrorMessage] = useState('');
  const [successBanner, setSuccessBanner] = useState(() => location.state?.registrationSuccessMessage || '');

  // Field-level validation
  const validate = () => {
    const e = {};
    if (!email.trim()) {
      e.email = 'Email address is required.';
    } else if (!/\S+@\S+\.\S+/.test(email.trim())) {
      e.email = 'Please enter a valid college or personal email address.';
    }

    if (!password) {
      e.password = 'Password is required.';
    } else if (password.length < 6) {
      e.password = 'Password must be at least 6 characters.';
    }
    return e;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSuccessBanner('');
    const fieldErrors = validate();
    if (Object.keys(fieldErrors).length > 0) {
      setErrors(fieldErrors);
      setErrorMessage('');
      return;
    }
    setErrors({});
    setErrorMessage('');

    const res = login(selectedRole, { email: email.trim(), password });
    if (!res.ok) {
      setErrorMessage(res.message);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <header className="login-header">
          <div className="login-logo" style={{ color: 'var(--primary-medium)', display: 'flex', justifyContent: 'center' }}>
            <BrandLogo size={46} />
          </div>
          <h1 className="login-title">StudySphere</h1>
          <p className="login-subtitle">College Student &amp; Academic Mentorship Portal</p>
        </header>

        {/* Role Tabs */}
        <div className="role-tabs">
          {['Student', 'Mentor', 'Parent'].map((role) => (
            <button
              key={role}
              type="button"
              className={`role-tab ${selectedRole === role ? 'active' : ''}`}
              onClick={() => {
                setSelectedRole(role);
                setErrors({});
                setErrorMessage('');
              }}
            >
              {role}
            </button>
          ))}
        </div>

        {/* Registration Success Banner */}
        {successBanner && (
          <div
            style={{
              backgroundColor: '#ecfdf5',
              color: '#065f46',
              border: '1px solid #a7f3d0',
              padding: '10px 14px',
              borderRadius: '8px',
              marginBottom: '16px',
              fontSize: '0.9rem',
              fontWeight: 500,
              textAlign: 'center',
            }}
          >
            {successBanner}
          </div>
        )}

        {/* Global error */}
        {errorMessage && <div className="error-message">{errorMessage}</div>}

        {/* Login Form */}
        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label" htmlFor="user-email">
              {selectedRole} College Email
            </label>
            <input
              id="user-email"
              type="email"
              className="form-input"
              placeholder={`Enter your ${selectedRole.toLowerCase()} email (e.g. name@studysphere.edu)`}
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setErrors((err) => ({ ...err, email: '' }));
                setErrorMessage('');
              }}
            />
            {errors.email && (
              <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>
                {errors.email}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="user-password">
              Password
            </label>
            <input
              id="user-password"
              type="password"
              className="form-input"
              placeholder="Enter your account password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setErrors((err) => ({ ...err, password: '' }));
                setErrorMessage('');
              }}
            />
            {errors.password && (
              <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>
                {errors.password}
              </div>
            )}
          </div>

          <button type="submit" className="btn-primary" style={{ width: '100%', marginTop: '8px' }}>
            Sign In as {selectedRole}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
          Don't have an account?{' '}
          <Link to="/signup" style={{ color: 'var(--primary-dark)', fontWeight: '600', textDecoration: 'none' }}>
            Sign Up
          </Link>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
