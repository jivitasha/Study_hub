import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { BrandLogo } from '../common/Icons';

function SignUpPage() {
  const navigate = useNavigate();
  const { register } = useAuth();

  const [role, setRole] = useState('Student');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const validate = () => {
    const errs = {};
    if (!name.trim()) {
      errs.name = 'Full Name is required.';
    }
    if (!email.trim()) {
      errs.email = 'Email address is required.';
    } else if (!/\S+@\S+\.\S+/.test(email.trim())) {
      errs.email = 'Please enter a valid email address.';
    }
    if (!password) {
      errs.password = 'Password is required.';
    } else if (password.length < 6) {
      errs.password = 'Password must be at least 6 characters.';
    }
    if (confirmPassword !== password) {
      errs.confirmPassword = 'Passwords do not match.';
    }
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setServerError('');
    setSuccessMessage('');

    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});

    const result = register({
      name: name.trim(),
      email: email.trim(),
      password,
      role,
    });

    if (!result.ok) {
      setServerError(result.message);
    } else {
      setSuccessMessage('Account created successfully! Redirecting to login...');
      setTimeout(() => {
        navigate('/login', {
          state: {
            registeredRole: role,
            registeredEmail: email.trim(),
            registrationSuccessMessage: `Account created successfully for ${name.trim()} (${role})! Please sign in below.`,
          },
        });
      }, 1200);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <header className="login-header">
          <div className="login-logo" style={{ color: 'var(--primary-medium)', display: 'flex', justifyContent: 'center' }}>
            <BrandLogo size={46} />
          </div>
          <h1 className="login-title">Create Account</h1>
          <p className="login-subtitle">Join StudySphere for College Studies &amp; Mentorship</p>
        </header>

        {/* Role Tabs */}
        <div className="role-tabs">
          {['Student', 'Mentor', 'Parent'].map((r) => (
            <button
              key={r}
              type="button"
              className={`role-tab ${role === r ? 'active' : ''}`}
              onClick={() => {
                setRole(r);
                setErrors({});
                setServerError('');
              }}
            >
              {r}
            </button>
          ))}
        </div>

        {serverError && <div className="error-message">{serverError}</div>}
        {successMessage && (
          <div
            style={{
              backgroundColor: '#eff6ff',
              color: '#1e40af',
              border: '1px solid #bfdbfe',
              padding: '10px 14px',
              borderRadius: '8px',
              marginBottom: '16px',
              fontSize: '0.9rem',
              fontWeight: 500,
              textAlign: 'center',
            }}
          >
            {successMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label" htmlFor="reg-name">
              Full Name {role === 'Mentor' ? '(with Title)' : ''}
            </label>
            <input
              id="reg-name"
              type="text"
              className="form-input"
              placeholder={role === 'Mentor' ? 'e.g. Dr. Ramesh Verma' : 'e.g. Aarav Sharma'}
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setErrors((prev) => ({ ...prev, name: '' }));
                setServerError('');
              }}
            />
            {errors.name && (
              <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>
                {errors.name}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="reg-email">
              College Email Address
            </label>
            <input
              id="reg-email"
              type="email"
              className="form-input"
              placeholder={role === 'Mentor' ? 'mentor@studysphere.edu' : 'student@studysphere.edu'}
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setErrors((prev) => ({ ...prev, email: '' }));
                setServerError('');
              }}
            />
            {errors.email && (
              <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>
                {errors.email}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="reg-password">
              Password
            </label>
            <input
              id="reg-password"
              type="password"
              className="form-input"
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setErrors((prev) => ({ ...prev, password: '' }));
                setServerError('');
              }}
            />
            {errors.password && (
              <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>
                {errors.password}
              </div>
            )}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="reg-confirm-password">
              Confirm Password
            </label>
            <input
              id="reg-confirm-password"
              type="password"
              className="form-input"
              placeholder="Re-enter your password"
              value={confirmPassword}
              onChange={(e) => {
                setConfirmPassword(e.target.value);
                setErrors((prev) => ({ ...prev, confirmPassword: '' }));
                setServerError('');
              }}
            />
            {errors.confirmPassword && (
              <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>
                {errors.confirmPassword}
              </div>
            )}
          </div>

          <button type="submit" className="btn-primary" style={{ width: '100%', marginTop: '8px' }}>
            Sign Up as {role}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: 'var(--primary-dark)', fontWeight: '600', textDecoration: 'none' }}>
            Log In
          </Link>
        </div>
      </div>
    </div>
  );
}

export default SignUpPage;
