import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';

const REPOS_PER_PAGE = 6;

/**
 * GitHubSearch Component (Modules 67-72: Consuming REST APIs, Debounce, Retry, Pagination)
 * Features:
 * - Public GitHub REST API integration via fetch
 * - Debounced input handling (300 ms) with visual typing/debounce indicator
 * - Loading spinner, empty state, and robust error handling
 * - Dedicated "🔄 Retry Request" action with attempt counter
 * - Repo sorting: Most Stars, Most Forks, Recently Updated
 * - Quick keyword filter for fetched repositories
 * - Client-side pagination (Previous / Next)
 */
function GitHubSearch() {
  const [query, setQuery]             = useState('facebook');
  const [profile, setProfile]         = useState(null);
  const [repos, setRepos]             = useState([]);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState('');
  const [page, setPage]               = useState(1);
  const [lastQuery, setLastQuery]     = useState('');
  const [retryCount, setRetryCount]   = useState(0);
  const [isDebouncing, setIsDebouncing] = useState(false);
  const [sortBy, setSortBy]           = useState('updated'); // 'updated' | 'stars' | 'forks'
  const [repoFilter, setRepoFilter]   = useState('');
  const debounceRef                   = useRef(null);

  // Fetch profile + repos from GitHub REST API
  const fetchGitHub = useCallback(async (username, isRetry = false) => {
    if (!username.trim()) {
      setProfile(null);
      setRepos([]);
      setError('');
      return;
    }
    setLoading(true);
    setError('');
    setIsDebouncing(false);
    if (!isRetry) setRetryCount(0);
    setPage(1);
    setLastQuery(username.trim());

    try {
      const [userRes, repoRes] = await Promise.all([
        fetch(`https://api.github.com/users/${username.trim()}`),
        fetch(`https://api.github.com/users/${username.trim()}/repos?per_page=100&sort=updated`),
      ]);

      if (userRes.status === 404) {
        setError('GitHub user/organization not found. Please verify the username.');
        setLoading(false);
        return;
      }

      if (userRes.status === 403) {
        throw new Error('GitHub API rate limit exceeded. Please wait a minute and click Retry.');
      }

      if (!userRes.ok) {
        throw new Error(`GitHub REST API returned status: ${userRes.status}`);
      }

      const userData = await userRes.json();
      const repoData = repoRes.ok ? await repoRes.json() : [];
      setProfile(userData);
      setRepos(Array.isArray(repoData) ? repoData : []);
    } catch (err) {
      setError(err.message || 'Network request failed. Please check your internet connection.');
    } finally {
      setLoading(false);
    }
  }, []);

  // Debounced typing effect
  useEffect(() => {
    clearTimeout(debounceRef.current);
    if (!query.trim()) {
      setProfile(null);
      setRepos([]);
      setError('');
      setIsDebouncing(false);
      return;
    }

    setIsDebouncing(true);
    debounceRef.current = setTimeout(() => {
      setIsDebouncing(false);
      fetchGitHub(query);
    }, 400);

    return () => clearTimeout(debounceRef.current);
  }, [query, fetchGitHub]);

  // Initial load
  useEffect(() => {
    fetchGitHub('facebook');
  }, [fetchGitHub]);

  // Manual retry handler
  const handleRetry = () => {
    setRetryCount((c) => c + 1);
    fetchGitHub(lastQuery || query || 'facebook', true);
  };

  // Sort and filter repositories
  const processedRepos = useMemo(() => {
    let list = [...repos];

    // Filter by keyword
    if (repoFilter.trim()) {
      const f = repoFilter.toLowerCase().trim();
      list = list.filter((r) =>
        r.name.toLowerCase().includes(f) ||
        (r.description && r.description.toLowerCase().includes(f)) ||
        (r.language && r.language.toLowerCase().includes(f))
      );
    }

    // Sort
    list.sort((a, b) => {
      if (sortBy === 'stars') return (b.stargazers_count || 0) - (a.stargazers_count || 0);
      if (sortBy === 'forks') return (b.forks_count || 0) - (a.forks_count || 0);
      return new Date(b.updated_at) - new Date(a.updated_at);
    });

    return list;
  }, [repos, repoFilter, sortBy]);

  // Paginated repos
  const totalPages   = Math.max(1, Math.ceil(processedRepos.length / REPOS_PER_PAGE));
  const visibleRepos = processedRepos.slice((page - 1) * REPOS_PER_PAGE, page * REPOS_PER_PAGE);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header */}
      <section className="card" style={{ backgroundColor: 'var(--accent-cream)', borderLeft: '5px solid var(--primary-medium)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h2 style={{ color: 'var(--primary-dark)', margin: 0, fontSize: '1.6rem' }}>
              🐙 Developer GitHub Profile &amp; Repo Explorer
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '0.95rem' }}>
              Live REST API integration with GitHub. Demonstrates real-time debouncing, loading states, retry handling, and pagination.
            </p>
          </div>
          <div>
            <span
              style={{
                fontSize: '0.8rem',
                backgroundColor: isDebouncing ? '#fef3c7' : '#dcfce7',
                color: isDebouncing ? '#b45309' : '#15803d',
                border: `1px solid ${isDebouncing ? '#fde68a' : '#86efac'}`,
                padding: '5px 12px',
                borderRadius: '16px',
                fontWeight: 'bold',
                display: 'inline-block',
              }}
            >
              {isDebouncing ? '⏳ Debouncing (400ms)...' : '⚡ REST API Ready'}
            </span>
          </div>
        </div>
      </section>

      {/* Search Bar Card */}
      <div className="card">
        <div className="form-group" style={{ marginBottom: 0 }}>
          <label className="form-label" htmlFor="github-search" style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span>Enter GitHub Username or Organization</span>
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Auto-searches after you pause typing (Debounce: 400ms)
            </span>
          </label>
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              id="github-search"
              type="text"
              className="form-input"
              placeholder="e.g. torvalds, gaearon, facebook, google"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') fetchGitHub(query); }}
            />
            <button
              className="btn-primary"
              style={{ width: 'auto', whiteSpace: 'nowrap' }}
              onClick={() => fetchGitHub(query)}
              disabled={loading}
            >
              {loading ? '… Fetching' : '🔍 Search'}
            </button>
          </div>
        </div>
      </div>

      {/* Loading State Spinner */}
      {loading && (
        <div className="card" style={{ textAlign: 'center', padding: '48px 24px' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '12px', animation: 'spin 1.5s linear infinite' }}>
            ⏳
          </div>
          <h4 style={{ margin: '0 0 6px 0', color: 'var(--primary-dark)' }}>Connecting to GitHub REST API...</h4>
          <p style={{ margin: 0, color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
            Fetching developer credentials, bio, and public repositories for <strong>@{query}</strong>.
          </p>
        </div>
      )}

      {/* Error with Dedicated Retry Action */}
      {!loading && error && (
        <div
          className="card"
          style={{
            textAlign: 'center',
            padding: '36px 20px',
            backgroundColor: '#fef2f2',
            border: '2px solid #fca5a5',
          }}
        >
          <div style={{ fontSize: '2.5rem', marginBottom: '10px' }}>⚠️</div>
          <h4 style={{ color: '#991b1b', margin: '0 0 8px 0', fontSize: '1.2rem' }}>
            REST API Request Encountered an Error
          </h4>
          <p style={{ color: '#b91c1c', fontWeight: '500', marginBottom: '16px', maxWidth: '540px', margin: '0 auto 18px auto' }}>
            {error}
          </p>
          <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', alignItems: 'center' }}>
            <button
              className="btn-primary"
              style={{ width: 'auto', backgroundColor: '#dc2626', borderColor: '#dc2626' }}
              onClick={handleRetry}
            >
              🔄 Retry Request {retryCount > 0 ? `(Attempt #${retryCount + 1})` : ''}
            </button>
            <button
              className="btn-secondary"
              style={{ width: 'auto' }}
              onClick={() => { setQuery('google'); fetchGitHub('google'); }}
            >
              Try Default: @google
            </button>
          </div>
        </div>
      )}

      {/* Profile Card */}
      {!loading && !error && profile && (
        <section className="card" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', gap: '24px', alignItems: 'center', flexWrap: 'wrap' }}>
            <img
              src={profile.avatar_url}
              alt={`${profile.login} avatar`}
              style={{ width: '96px', height: '96px', borderRadius: '50%', border: '3px solid var(--primary-medium)', boxShadow: 'var(--shadow-sm)' }}
            />
            <div style={{ flex: 1, minWidth: '240px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <h3 style={{ color: 'var(--primary-dark)', fontSize: '1.5rem', margin: 0 }}>
                  {profile.name || profile.login}
                </h3>
                <span style={{ backgroundColor: '#f1f5f9', color: '#475569', padding: '3px 8px', borderRadius: '6px', fontSize: '0.8rem' }}>
                  @{profile.login}
                </span>
                {profile.location && (
                  <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                    📍 {profile.location}
                  </span>
                )}
              </div>

              {profile.bio && (
                <p style={{ marginTop: '8px', fontSize: '0.92rem', color: 'var(--text-primary)', lineHeight: '1.5' }}>
                  {profile.bio}
                </p>
              )}

              <div style={{ display: 'flex', gap: '18px', marginTop: '12px', flexWrap: 'wrap' }}>
                <span style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                  👥 <strong>{profile.followers?.toLocaleString()}</strong> followers
                </span>
                <span style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                  👤 <strong>{profile.following?.toLocaleString()}</strong> following
                </span>
                <span style={{ fontSize: '0.88rem', color: 'var(--text-secondary)' }}>
                  📁 <strong>{profile.public_repos?.toLocaleString()}</strong> public repos
                </span>
                {profile.html_url && (
                  <a
                    href={profile.html_url}
                    target="_blank"
                    rel="noreferrer"
                    style={{ color: 'var(--primary-medium)', fontWeight: '600', fontSize: '0.88rem', textDecoration: 'none' }}
                  >
                    🔗 View on GitHub ↗
                  </a>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Repositories Section with Sort & Filter Controls */}
      {!loading && !error && profile && (
        <section>
          {/* Controls Bar */}
          <div className="card" style={{ padding: '14px 18px', marginBottom: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1, minWidth: '220px' }}>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Filter repositories by name or language..."
                  value={repoFilter}
                  onChange={(e) => { setRepoFilter(e.target.value); setPage(1); }}
                  style={{ padding: '6px 12px', fontSize: '0.88rem' }}
                />
              </div>

              {/* Sort pills */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '0.82rem', color: 'var(--text-muted)', fontWeight: 'bold' }}>Sort:</span>
                <button
                  type="button"
                  className={sortBy === 'stars' ? 'btn-primary' : 'btn-secondary'}
                  style={{ width: 'auto', padding: '5px 12px', fontSize: '0.8rem' }}
                  onClick={() => setSortBy('stars')}
                >
                  ⭐ Stars
                </button>
                <button
                  type="button"
                  className={sortBy === 'forks' ? 'btn-primary' : 'btn-secondary'}
                  style={{ width: 'auto', padding: '5px 12px', fontSize: '0.8rem' }}
                  onClick={() => setSortBy('forks')}
                >
                  🔀 Forks
                </button>
                <button
                  type="button"
                  className={sortBy === 'updated' ? 'btn-primary' : 'btn-secondary'}
                  style={{ width: 'auto', padding: '5px 12px', fontSize: '0.8rem' }}
                  onClick={() => setSortBy('updated')}
                >
                  🕒 Recent
                </button>
              </div>
            </div>
          </div>

          {/* Repos Grid */}
          {processedRepos.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '36px' }}>
              No repositories match your filter.
            </div>
          ) : (
            <>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                  gap: '16px',
                  marginBottom: '20px',
                }}
              >
                {visibleRepos.map((repo) => (
                  <article
                    key={repo.id}
                    className="card"
                    style={{
                      borderTop: '3px solid var(--primary-medium)',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      gap: '12px',
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <a
                          href={repo.html_url}
                          target="_blank"
                          rel="noreferrer"
                          style={{ color: 'var(--primary-dark)', fontWeight: '700', fontSize: '1rem', wordBreak: 'break-word', textDecoration: 'none' }}
                        >
                          {repo.name}
                        </a>
                      </div>

                      {repo.description && (
                        <p style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', marginTop: '6px', lineHeight: 1.45 }}>
                          {repo.description.length > 95 ? repo.description.slice(0, 95) + '…' : repo.description}
                        </p>
                      )}
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.8rem', color: 'var(--text-muted)', paddingTop: '8px', borderTop: '1px solid var(--border-color)' }}>
                      <span>{repo.language ? `💻 ${repo.language}` : 'Code'}</span>
                      <div style={{ display: 'flex', gap: '10px' }}>
                        <span>⭐ {repo.stargazers_count?.toLocaleString()}</span>
                        <span>🔀 {repo.forks_count?.toLocaleString()}</span>
                      </div>
                    </div>
                  </article>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', justifyContent: 'center' }}>
                  <button
                    className="btn-secondary"
                    style={{ width: 'auto', padding: '6px 14px' }}
                    onClick={() => setPage((p) => p - 1)}
                    disabled={page === 1}
                  >
                    ← Prev
                  </button>
                  <span style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', fontWeight: '600' }}>
                    Page {page} of {totalPages} ({processedRepos.length} repos)
                  </span>
                  <button
                    className="btn-secondary"
                    style={{ width: 'auto', padding: '6px 14px' }}
                    onClick={() => setPage((p) => p + 1)}
                    disabled={page === totalPages}
                  >
                    Next →
                  </button>
                </div>
              )}
            </>
          )}
        </section>
      )}
    </div>
  );
}

export default GitHubSearch;
