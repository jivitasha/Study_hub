import React from 'react';

/**
 * Modern, natural SVG icons for StudySphere Academic Portal.
 * Replaces cartoonish emojis with clean, scalable academic vector graphics.
 */

// University / College Crest Shield Logo
export function BrandLogo({ size = 28, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M12 2L3 6v6c0 5.25 3.75 10.15 9 11.5 5.25-1.35 9-6.25 9-11.5V6l-9-4z" fill="rgba(37, 99, 235, 0.15)" />
      <path d="M12 2L3 6l9 4 9-4-9-4z" />
      <path d="M7 10v4c0 1.66 2.24 3 5 3s5-1.34 5-3v-4" />
      <line x1="12" y1="13" x2="12" y2="17" />
    </svg>
  );
}

// Academic Marks / Scorecard Transcript Icon
export function MarksIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="rgba(37, 99, 235, 0.08)" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="9" y1="13" x2="15" y2="13" />
      <line x1="9" y1="17" x2="13" y2="17" />
      <circle cx="9" cy="9" r="1.5" fill="currentColor" />
    </svg>
  );
}

// Precision Focus Chronometer / Study Timer Icon
export function TimerIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <circle cx="12" cy="13" r="8" fill="rgba(37, 99, 235, 0.08)" />
      <line x1="12" y1="9" x2="12" y2="13" strokeWidth="2.5" />
      <line x1="12" y1="13" x2="15" y2="15" strokeWidth="2" />
      <line x1="12" y1="2" x2="12" y2="5" />
      <line x1="10" y1="2" x2="14" y2="2" />
      <line x1="19" y1="6" x2="21" y2="8" />
    </svg>
  );
}

// Natural Student Scholar Silhouette Avatar
export function StudentAvatarIcon({ size = 56, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={className}
      style={{ display: 'block', width: '100%', height: '100%' }}
    >
      {/* Background circle gradient */}
      <circle cx="32" cy="32" r="32" fill="#1e293b" />
      
      {/* Student Graduation Cap */}
      <polygon points="32,10 50,17 32,24 14,17" fill="#3b82f6" />
      <path d="M19 19.5v5.5c0 3 5.8 5.5 13 5.5s13-2.5 13-5.5v-5.5" fill="#1d4ed8" />
      <path d="M47 18v11" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="47" cy="30" r="2" fill="#fbbf24" />

      {/* Head */}
      <circle cx="32" cy="33" r="8" fill="#cbd5e1" />

      {/* Torso / College Blazer */}
      <path
        d="M20 54c0-7 5.4-12 12-12s12 5 12 12"
        fill="#2563eb"
      />
      {/* Shirt collar */}
      <polygon points="32,44 28,48 36,48" fill="#ffffff" />
    </svg>
  );
}

// Natural Mentor / Faculty Professor Silhouette Avatar
export function MentorAvatarIcon({ size = 56, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={className}
      style={{ display: 'block', width: '100%', height: '100%' }}
    >
      {/* Background circle gradient */}
      <circle cx="32" cy="32" r="32" fill="#0f172a" />

      {/* Professor Head & Hair */}
      <path d="M22 26c0-6 4.5-11 10-11s10 5 10 11c0 2-0.5 4-1.5 5.5-2 3-5 4.5-8.5 4.5s-6.5-1.5-8.5-4.5c-1-1.5-1.5-3.5-1.5-5.5z" fill="#94a3b8" />
      <circle cx="32" cy="28" r="8" fill="#e2e8f0" />

      {/* Glasses */}
      <rect x="26" y="26" width="5" height="3" rx="1" stroke="#334155" strokeWidth="1.2" fill="rgba(255,255,255,0.4)" />
      <rect x="33" y="26" width="5" height="3" rx="1" stroke="#334155" strokeWidth="1.2" fill="rgba(255,255,255,0.4)" />
      <line x1="31" y1="27.5" x2="33" y2="27.5" stroke="#334155" strokeWidth="1.2" />

      {/* Academic Faculty Blazer & Tie */}
      <path
        d="M18 54c0-8 6.3-14 14-14s14 6 14 14"
        fill="#1e3a8a"
      />
      <polygon points="32,42 27,48 37,48" fill="#ffffff" />
      <polygon points="32,46 30.5,54 33.5,54" fill="#ef4444" />
    </svg>
  );
}

// Natural Profile / ID Card Icon
export function ProfileIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <rect x="3" y="4" width="18" height="16" rx="3" fill="rgba(37, 99, 235, 0.08)" />
      <circle cx="9" cy="10" r="2.5" />
      <path d="M5.5 17c0-2 2-3 3.5-3s3.5 1 3.5 3" />
      <line x1="15" y1="9" x2="19" y2="9" />
      <line x1="15" y1="13" x2="18" y2="13" />
    </svg>
  );
}

// Modern Dashboard / Academic Overview Icon
export function DashboardIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <rect x="3" y="3" width="7" height="9" rx="1.5" fill="rgba(37, 99, 235, 0.12)" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" fill="rgba(37, 99, 235, 0.12)" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </svg>
  );
}

// Academic Notes Icon
export function NotesIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" fill="rgba(37, 99, 235, 0.08)" />
      <line x1="8" y1="7" x2="16" y2="7" />
      <line x1="8" y1="11" x2="14" y2="11" />
    </svg>
  );
}

// Developer GitHub Search Icon
export function GithubIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
    </svg>
  );
}

// Mentee Roster Icon
export function MenteeRosterIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}

// Logout Icon
export function LogoutIcon({ size = 18, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  );
}

// Attendance Register / Calendar Icon
export function AttendanceIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" fill="rgba(37, 99, 235, 0.08)" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
      <path d="m9 16 2 2 4-4" />
    </svg>
  );
}

// Disciplinary & UMC Warning Shield Icon
export function DisciplineAlertIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="rgba(239, 68, 68, 0.12)" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}

// Academic Quiz / Assessment Icon
export function QuizIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <path d="M9 11l3 3L22 4" />
      <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" fill="rgba(37, 99, 235, 0.08)" />
      <circle cx="8" cy="16" r="1" fill="currentColor" />
      <line x1="12" y1="16" x2="17" y2="16" />
    </svg>
  );
}

// Study Materials Locker / Cart Icon
export function LockerIcon({ size = 20, className = '' }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      style={{ verticalAlign: 'middle', display: 'inline-block' }}
    >
      <circle cx="9" cy="21" r="1" />
      <circle cx="20" cy="21" r="1" />
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" fill="rgba(37, 99, 235, 0.08)" />
    </svg>
  );
}



