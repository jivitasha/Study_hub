import React from 'react';
import { Link } from 'react-router-dom';
import { ProfileIcon } from './Icons';
import { useLocker } from '../../context/LockerContext';

/**
 * Header Component
 * Props passed:
 * - user: Current authenticated user object containing name and role
 * - title: Title of the current active tab/page
 */
function Header({ user, title }) {
  let totalLockerCount = 0;
  try {
    const { totalCount } = useLocker();
    totalLockerCount = totalCount;
  } catch {
    // If outside provider, default 0
  }

  const isStudent = user?.role === 'Student';
  const userInitial = user?.name ? user.name.charAt(0).toUpperCase() : 'U';

  return (
    <header className="header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <h1 className="header-title" style={{ margin: 0 }}>{title}</h1>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
        {/* Locker Cart Badge for Students */}
        {isStudent && (
          <Link
            to="/student/materials"
            style={{
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              backgroundColor: totalLockerCount > 0 ? 'var(--primary-subtle)' : '#ffffff',
              color: totalLockerCount > 0 ? 'var(--primary-medium)' : 'var(--text-secondary)',
              border: `1px solid ${totalLockerCount > 0 ? '#93c5fd' : 'var(--border-color)'}`,
              padding: '6px 14px',
              borderRadius: '20px',
              fontSize: '0.85rem',
              fontWeight: '600',
              boxShadow: totalLockerCount > 0 ? '0 2px 8px rgba(37, 99, 235, 0.15)' : 'none',
              transition: 'all 0.18s ease',
            }}
            title="Open Study Materials Locker"
          >
            <span>🛒 Locker</span>
            <span
              style={{
                backgroundColor: totalLockerCount > 0 ? 'var(--primary-medium)' : '#94a3b8',
                color: '#ffffff',
                padding: '2px 7px',
                borderRadius: '10px',
                fontSize: '0.75rem',
                fontWeight: 'bold',
              }}
            >
              {totalLockerCount}
            </span>
          </Link>
        )}

        {/* User Badge with Avatar & Online Dot */}
        {user && (
          <div
            className="user-badge"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              backgroundColor: '#ffffff',
              boxShadow: 'var(--shadow-sm)'
            }}
          >
            <div
              style={{
                width: '26px',
                height: '26px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #2563eb, #1e40af)',
                color: '#ffffff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '0.8rem',
                fontWeight: 'bold'
              }}
            >
              {userInitial}
            </div>
            <span>{user.name}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.8rem', color: 'var(--primary-medium)', fontWeight: 'bold' }}>
              <span className="pulse-dot" style={{ width: '6px', height: '6px' }}></span>
              {user.role}
            </span>
          </div>
        )}
      </div>
    </header>
  );
}

export default Header;
