import React, { useEffect } from 'react';

/**
 * Toast — lightweight notification that auto-dismisses after `duration` ms.
 *
 * Props:
 *   message   {string}   Text to display
 *   type      {string}   'success' | 'error' | 'info'  (default: 'success')
 *   onClose   {function} Called when the toast should be removed
 *   duration  {number}   Auto-dismiss delay in ms (default: 2500)
 */
function Toast({ message, type = 'success', onClose, duration = 2500 }) {
  useEffect(() => {
    const timer = setTimeout(onClose, duration);
    return () => clearTimeout(timer);
  }, [onClose, duration]);

  const colours = {
    success: { bg: '#eff6ff', border: '#3b82f6', text: '#1e40af' },
    error:   { bg: '#fde8e8', border: '#c81e1e', text: '#c81e1e' },
    info:    { bg: '#f1f5f9', border: '#64748b', text: '#0f172a' },
  };
  const c = colours[type] || colours.success;

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '28px',
        right: '28px',
        zIndex: 9999,
        backgroundColor: c.bg,
        border: `1px solid ${c.border}`,
        color: c.text,
        padding: '12px 20px',
        borderRadius: '8px',
        fontWeight: '600',
        fontSize: '0.92rem',
        boxShadow: '0 4px 12px rgba(0,0,0,0.12)',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        maxWidth: '320px',
        animation: 'fadeIn 0.25s ease',
      }}
    >
      <span>{type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
      <span>{message}</span>
      <button
        onClick={onClose}
        style={{
          marginLeft: 'auto',
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          fontSize: '1rem',
          color: c.text,
          lineHeight: 1,
        }}
        aria-label="Close notification"
      >
        ×
      </button>
    </div>
  );
}

export default Toast;
