import React from 'react';

/**
 * Reusable Badge Component for Student Status
 * Props:
 * - status: 'Excellent' | 'On track' | 'Needs support'
 */
function Badge({ status }) {
  let badgeClass = 'badge-ontrack';
  let icon = '🟡';

  if (status === 'Excellent') {
    badgeClass = 'badge-excellent';
    icon = '🟢';
  } else if (status === 'Needs support') {
    badgeClass = 'badge-needs-support';
    icon = '🔴';
  }

  return (
    <span className={`badge ${badgeClass}`}>
      {icon} {status}
    </span>
  );
}

export default Badge;
