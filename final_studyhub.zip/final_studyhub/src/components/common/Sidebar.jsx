import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { BrandLogo, LogoutIcon } from './Icons';

/**
 * Sidebar Component with clean academic vector logos.
 */
function Sidebar({ navItems }) {
  const navigate   = useNavigate();
  const location   = useLocation();
  const { logout } = useAuth();

  return (
    <div className="sidebar">
      <div className="sidebar-brand">
        <div style={{ color: 'var(--primary-light)', display: 'flex', alignItems: 'center' }}>
          <BrandLogo size={32} />
        </div>
        <div style={{ letterSpacing: '0.5px' }}>StudySphere</div>
      </div>

      <nav className="sidebar-nav">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
            onClick={() => navigate(item.path)}
          >
            <span style={{ display: 'inline-flex', alignItems: 'center', opacity: location.pathname === item.path ? 1 : 0.85 }}>
              {item.icon}
            </span>
            <span>{item.label}</span>
          </button>
        ))}

        <button className="nav-item logout" onClick={logout}>
          <span style={{ display: 'inline-flex', alignItems: 'center' }}>
            <LogoutIcon size={18} />
          </span>
          <span>Logout</span>
        </button>
      </nav>
    </div>
  );
}

export default Sidebar;
