import React from 'react';


function ProgressBar({ percentage, height = '12px' }) {
  const validPercentage = Math.min(100, Math.max(0, percentage));

  return (
    <div className="progress-container" style={{ height }}>
      <div 
        className="progress-fill" 
        style={{ width: `${validPercentage}%` }} 
      />
    </div>
  );
}

export default ProgressBar;
