import React from 'react';

/**
 * Reusable FormInput Component
 * Supports:
 * - Floating/stacked label with optional required star
 * - Real-time error message rendering
 * - Built-in touched/dirty visual state
 * - Clean modern styling aligned with Royal Blue & Slate theme
 */
export function FormInput({
  id,
  name,
  label,
  type = 'text',
  value = '',
  onChange,
  onBlur,
  placeholder = '',
  error = '',
  touched = false,
  required = false,
  disabled = false,
  icon = null,
  helperText = '',
  autoComplete = 'off',
  style = {},
  ...props
}) {
  const hasError = Boolean(error && (touched || error));

  return (
    <div className="form-group" style={{ marginBottom: '16px', ...style }}>
      {label && (
        <label htmlFor={id || name} className="form-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>
            {label}
            {required && <span style={{ color: '#dc2626', marginLeft: '4px' }}>*</span>}
          </span>
          {helperText && (
            <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', fontWeight: 400 }}>
              {helperText}
            </span>
          )}
        </label>
      )}

      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        {icon && (
          <span
            style={{
              position: 'absolute',
              left: '12px',
              color: hasError ? '#dc2626' : 'var(--text-muted)',
              pointerEvents: 'none',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            {icon}
          </span>
        )}

        <input
          id={id || name}
          name={name}
          type={type}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          placeholder={placeholder}
          disabled={disabled}
          autoComplete={autoComplete}
          className="form-input"
          style={{
            paddingLeft: icon ? '40px' : '14px',
            borderColor: hasError ? '#dc2626' : undefined,
            backgroundColor: hasError ? '#fff5f5' : undefined,
          }}
          {...props}
        />
      </div>

      {hasError && (
        <div
          className="error-message"
          style={{
            marginTop: '6px',
            fontSize: '0.82rem',
            color: '#dc2626',
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
          }}
        >
          <span>⚠️</span>
          <span>{error}</span>
        </div>
      )}
    </div>
  );
}

/**
 * Reusable FormSelect Component
 */
export function FormSelect({
  id,
  name,
  label,
  value,
  onChange,
  onBlur,
  options = [],
  error = '',
  touched = false,
  required = false,
  style = {},
}) {
  const hasError = Boolean(error && (touched || error));

  return (
    <div className="form-group" style={{ marginBottom: '16px', ...style }}>
      {label && (
        <label htmlFor={id || name} className="form-label">
          {label}
          {required && <span style={{ color: '#dc2626', marginLeft: '4px' }}>*</span>}
        </label>
      )}

      <select
        id={id || name}
        name={name}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        className="form-select"
        style={{
          borderColor: hasError ? '#dc2626' : undefined,
          backgroundColor: hasError ? '#fff5f5' : undefined,
        }}
      >
        {options.map((opt) => (
          <option key={opt.value ?? opt} value={opt.value ?? opt}>
            {opt.label ?? opt}
          </option>
        ))}
      </select>

      {hasError && (
        <div className="error-message" style={{ marginTop: '6px', fontSize: '0.82rem', color: '#dc2626' }}>
          ⚠️ {error}
        </div>
      )}
    </div>
  );
}

export default FormInput;
