import React from 'react';
import { DEMO_STUDENTS_PROGRESS, INITIAL_TEACHER_FEEDBACK } from '../../data/mockData';
import Badge from '../common/Badge';

/**
 * MentorDashboard (formerly TeacherDashboard) Component
 * Features:
 * - Number of assigned mentees
 * - Coursework completion percentage
 * - Average batch score / CGPA
 * - Mentees needing academic guidance
 * - Recent mentorship notes
 */
function TeacherDashboard({ user }) {
  const totalStudents = DEMO_STUDENTS_PROGRESS.length;
  const avgCompletion = Math.round(
    DEMO_STUDENTS_PROGRESS.reduce((acc, s) => acc + s.completion, 0) / totalStudents
  );
  const avgScore = Math.round(
    DEMO_STUDENTS_PROGRESS.reduce((acc, s) => acc + s.score, 0) / totalStudents
  );
  const needingSupport = DEMO_STUDENTS_PROGRESS.filter(
    (s) => s.status === 'Needs support'
  );

  return (
    <div>
      {/* Welcome Banner */}
      <section className="card" style={{ marginBottom: '24px', backgroundColor: 'var(--accent-cream)' }}>
        <h2>👨‍🏫 Welcome, Mentor {user?.name || 'Dr. Ramesh Verma'}</h2>
        <p style={{ color: 'var(--text-secondary)', marginTop: '4px' }}>
          College Academic Mentorship &amp; Semester Coursework Evaluation Overview
        </p>
      </section>

      {/* 4 Stat Overview Cards */}
      <div className="dashboard-grid">
        <article className="card">
          <div className="stat-card-lbl">👥 Assigned Mentees</div>
          <div className="stat-card-val">{totalStudents} Undergrads</div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">📈 Coursework Completion</div>
          <div className="stat-card-val">{avgCompletion}%</div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">⭐ Batch Average Score</div>
          <div className="stat-card-val">{avgScore}%</div>
        </article>

        <article className="card">
          <div className="stat-card-lbl">⚠️ Needing Academic Mentoring</div>
          <div className="stat-card-val" style={{ color: '#c81e1e' }}>
            {needingSupport.length} Mentees
          </div>
        </article>
      </div>

      {/* Grid for Needing Support and Recent Notes */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        
        {/* Mentees Needing Guidance Panel */}
        <section className="card">
          <h3 style={{ color: 'var(--primary-dark)', marginBottom: '16px' }}>
            🔴 Mentees Requiring Academic Guidance
          </h3>
          {needingSupport.length === 0 ? (
            <p style={{ color: 'var(--text-muted)' }}>All mentees are performing on track with their semester milestones!</p>
          ) : (
            <ul style={{ listStyle: 'none' }}>
              {needingSupport.map((student) => (
                <li
                  key={student.id}
                  style={{
                    padding: '12px',
                    backgroundColor: '#fff5f5',
                    borderRadius: '8px',
                    marginBottom: '10px',
                    borderLeft: '4px solid #c81e1e',
                  }}
                >
                  <div style={{ fontWeight: 'bold' }}>{student.name} (Roll: {student.roll})</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                    Score: {student.score}% | Course Completion: {student.completion}%
                  </div>
                  <div style={{ marginTop: '6px' }}>
                    <Badge status={student.status} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Recent Mentorship Feedback Notes */}
        <section className="card">
          <h3 style={{ color: 'var(--primary-dark)', marginBottom: '16px' }}>
            💬 Recent Mentorship Feedback &amp; Recommendations
          </h3>
          <ul style={{ listStyle: 'none' }}>
            {INITIAL_TEACHER_FEEDBACK.slice(0, 3).map((note) => (
              <li
                key={note.id}
                style={{
                  padding: '12px',
                  backgroundColor: 'var(--accent-cream)',
                  borderRadius: '8px',
                  marginBottom: '10px',
                  border: '1px solid var(--border-color)',
                }}
              >
                <div style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>
                  {note.studentName} — Course: {note.subject}
                </div>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '4px' }}>
                  "{note.text}"
                </p>
              </li>
            ))}
          </ul>
        </section>

      </div>
    </div>
  );
}

export default TeacherDashboard;
