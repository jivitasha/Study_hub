import React, { useState, useEffect } from 'react';
import { DEMO_STUDENTS_PROGRESS, INITIAL_TEACHER_FEEDBACK } from '../../data/mockData';
import Toast from '../common/Toast';

const MENTOR_NOTES_STORAGE_KEY = 'studysphere_mentor_notes';

function getInitialFeedback() {
  try {
    const saved = localStorage.getItem(MENTOR_NOTES_STORAGE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch {
    // fallback
  }
  return INITIAL_TEACHER_FEEDBACK.map((item) => ({
    ...item,
    studentName: 'All Students',
    mentorName: 'Dr. Ramesh Verma',
  }));
}

/**
 * MentorStudentNotes — Mentor view for posting feedback and academic recommendations.
 * Broadcasts notes to all students so every student receives the mentor's guidance.
 */
function TeacherStudentNotes({ user = {} }) {
  // Combine demo students with any newly registered students
  const allStudents = (() => {
    const list = [...DEMO_STUDENTS_PROGRESS];
    try {
      const storedUsers = JSON.parse(localStorage.getItem('studysphere_users')) || [];
      storedUsers
        .filter((u) => u.role === 'Student')
        .forEach((u) => {
          if (!list.some((existing) => existing.name.toLowerCase() === u.name.toLowerCase())) {
            list.push({ id: u.id || u.email, name: u.name, roll: u.id || 'REG2026' });
          }
        });
    } catch {
      // fallback
    }
    return list;
  })();

  const [feedbackList, setFeedbackList] = useState(getInitialFeedback);
  const [selectedStudent, setSelectedStudent] = useState('All Students');
  const [subject, setSubject] = useState('DBMS & SQL');
  const [feedbackText, setFeedbackText] = useState('');
  const [errors, setErrors] = useState({});
  const [toast, setToast] = useState(null);

  // Sync to localStorage whenever feedbackList updates
  useEffect(() => {
    localStorage.setItem(MENTOR_NOTES_STORAGE_KEY, JSON.stringify(feedbackList));
  }, [feedbackList]);

  // Validate fields
  const validate = () => {
    const newErrors = {};
    if (subject.trim().length < 2)       newErrors.subject  = 'Course/Subject name must be at least 2 characters.';
    if (feedbackText.trim().length < 10) newErrors.feedback = 'Mentorship guidance must be at least 10 characters.';
    return newErrors;
  };

  const handleAddFeedback = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});

    const newFeedback = {
      id: Date.now(),
      studentName: selectedStudent,
      subject: subject.trim(),
      text: feedbackText.trim(),
      mentorName: user.name || 'Dr. Ramesh Verma',
      date: new Date().toISOString().split('T')[0],
    };

    const updated = [newFeedback, ...feedbackList];
    setFeedbackList(updated);
    setFeedbackText('');
    setToast({
      message: selectedStudent === 'All Students'
        ? 'Mentorship note published to all students! 🎓'
        : `Mentorship note published for ${selectedStudent}! 🎓`,
      type: 'success',
    });
  };

  const handleDeleteFeedback = (id) => {
    const updated = feedbackList.filter((item) => item.id !== id);
    setFeedbackList(updated);
  };

  return (
    <div>
      {/* Toast notification */}
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Form to Add Mentee Feedback */}
      <section className="card" style={{ marginBottom: '28px' }}>
        <h2>📝 Publish Guidance &amp; Course Notes for Students</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginTop: '4px' }}>
          Notes published here will be delivered to <strong>all students</strong> on their main dashboard and under their notes section.
        </p>

        <form onSubmit={handleAddFeedback} style={{ marginTop: '16px' }}>
          <div className="form-group">
            <label className="form-label" htmlFor="select-student">Recipient Audience</label>
            <select
              id="select-student"
              className="form-select"
              value={selectedStudent}
              onChange={(e) => setSelectedStudent(e.target.value)}
            >
              <option value="All Students">📢 All Students (Broadcast to Entire Batch)</option>
              {allStudents.map((std) => (
                <option key={std.id} value={std.name}>
                  👤 {std.name} (Roll: {std.roll})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="select-subject">Semester Course / Subject</label>
            <input
              id="select-subject"
              type="text"
              className="form-input"
              value={subject}
              onChange={(e) => { setSubject(e.target.value); setErrors((err) => ({ ...err, subject: '' })); }}
              placeholder="e.g., DBMS & SQL, Operating Systems, OOPS in Java"
            />
            {errors.subject && <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>{errors.subject}</div>}
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="feedback-text">
              Mentorship Guidance &amp; Study Recommendations
              <span style={{ color: 'var(--text-muted)', fontWeight: 400, marginLeft: '8px', fontSize: '0.8rem' }}>
                ({feedbackText.trim().length}/10 min chars)
              </span>
            </label>
            <textarea
              id="feedback-text"
              className="form-textarea"
              rows="3"
              placeholder="Provide academic advice, project review, exam prep guidelines, or course notices for students..."
              value={feedbackText}
              onChange={(e) => { setFeedbackText(e.target.value); setErrors((err) => ({ ...err, feedback: '' })); }}
            />
            {errors.feedback && <div className="error-message" style={{ marginTop: '6px', marginBottom: 0 }}>{errors.feedback}</div>}
          </div>

          <button type="submit" className="btn-primary" style={{ width: 'auto' }}>
            💬 Publish Note to Students
          </button>
        </form>
      </section>

      {/* Display Student Feedback Cards */}
      <section>
        <h3 style={{ marginBottom: '14px', color: 'var(--primary-dark)' }}>
          📋 Published Mentor Notes ({feedbackList.length})
        </h3>
        {feedbackList.length === 0 ? (
          <div className="card" style={{ textAlign: 'center', color: 'var(--text-secondary)' }}>
            No notes published yet. Use the form above to add guidance for students.
          </div>
        ) : (
          <div className="notes-grid">
            {feedbackList.map((item) => (
              <article key={item.id} className="note-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <span
                    style={{
                      fontSize: '0.82rem',
                      fontWeight: 'bold',
                      backgroundColor: item.studentName === 'All Students' ? 'var(--primary-subtle)' : '#f1f5f9',
                      color: item.studentName === 'All Students' ? 'var(--primary-medium)' : 'var(--text-primary)',
                      padding: '3px 8px',
                      borderRadius: '8px',
                    }}
                  >
                    {item.studentName === 'All Students' ? '📢 All Students' : `👤 ${item.studentName}`}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleDeleteFeedback(item.id)}
                    style={{ background: 'none', border: 'none', color: '#dc2626', cursor: 'pointer', fontSize: '0.85rem' }}
                    title="Delete Note"
                  >
                    🗑️
                  </button>
                </div>
                <div style={{ fontSize: '0.9rem', fontWeight: 'bold', color: 'var(--primary-dark)', marginTop: '8px' }}>
                  📚 Course: {item.subject}
                </div>
                <div className="note-card-date">
                  📅 {item.date} {item.mentorName ? `· Mentor: ${item.mentorName}` : ''}
                </div>
                <p style={{ fontSize: '0.9rem', color: 'var(--text-primary)', marginTop: '8px', lineHeight: '1.5' }}>
                  "{item.text}"
                </p>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default TeacherStudentNotes;
