import React, { useState, useMemo } from 'react';
import { DEMO_STUDENTS_PROGRESS } from '../../data/mockData';
import Badge from '../common/Badge';

const PAGE_SIZE = 3;

/**
 * StudentProgress — Mentor view for college mentees.
 * Features: search by name, sortable columns (Name, Score), pagination.
 */
function StudentProgress() {
  const [search, setSearch]       = useState('');
  const [sortKey, setSortKey]     = useState('roll');
  const [sortAsc, setSortAsc]     = useState(true);
  const [page, setPage]           = useState(1);

  // Handle column header click
  const handleSort = (key) => {
    if (sortKey === key) {
      setSortAsc((a) => !a);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
    setPage(1);
  };

  // Filter + sort
  const processed = useMemo(() => {
    let data = DEMO_STUDENTS_PROGRESS.filter((s) =>
      s.name.toLowerCase().includes(search.toLowerCase())
    );
    data = [...data].sort((a, b) => {
      let valA = a[sortKey];
      let valB = b[sortKey];
      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
    return data;
  }, [search, sortKey, sortAsc]);

  // Paginate
  const totalPages   = Math.max(1, Math.ceil(processed.length / PAGE_SIZE));
  const currentPage  = Math.min(page, totalPages);
  const pageData     = processed.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  // Sort indicator
  const arrow = (key) => sortKey === key ? (sortAsc ? ' ↑' : ' ↓') : '';

  return (
    <div>
      <section className="card" style={{ marginBottom: '24px' }}>
        <h2 style={{ color: 'var(--primary-dark)', marginBottom: '8px' }}>📊 College Mentee Academic Progress Roster</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
          Overview of assigned undergraduate mentees, semester coursework completion, and academic performance status.
        </p>
      </section>

      {/* Search bar */}
      <div className="card" style={{ marginBottom: '20px' }}>
        <div className="form-group" style={{ marginBottom: 0 }}>
          <label className="form-label" htmlFor="student-search">🔍 Search Mentee by Name</label>
          <input
            id="student-search"
            type="text"
            className="form-input"
            placeholder="Type a mentee's name (e.g. Aarav, Priya)…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          />
        </div>
      </div>

      {/* Table */}
      <div className="table-container">
        <table className="custom-table">
          <thead>
            <tr>
              <th>University Roll No.</th>
              <th
                style={{ cursor: 'pointer', userSelect: 'none' }}
                onClick={() => handleSort('name')}
              >
                Mentee Name{arrow('name')}
              </th>
              <th>Coursework Progress</th>
              <th
                style={{ cursor: 'pointer', userSelect: 'none' }}
                onClick={() => handleSort('score')}
              >
                Semester Score (%){arrow('score')}
              </th>
              <th>Attendance %</th>
              <th>Conduct / UMC</th>
              <th>Academic Status</th>
            </tr>
          </thead>
          <tbody>
            {pageData.length === 0 ? (
              <tr>
                <td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: '24px' }}>
                  No mentees match your search.
                </td>
              </tr>
            ) : (
              pageData.map((student) => (
                <tr key={student.id}>
                  <td><strong>{student.roll}</strong></td>
                  <td>{student.name}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{ flex: 1, backgroundColor: 'var(--bg-cream)', height: '8px', borderRadius: '4px', overflow: 'hidden' }}>
                        <div style={{ width: `${student.completion}%`, backgroundColor: 'var(--primary-medium)', height: '100%' }} />
                      </div>
                      <span>{student.completion}%</span>
                    </div>
                  </td>
                  <td><strong>{student.score}%</strong></td>
                  <td>
                    <span style={{ fontWeight: 'bold', color: student.attendance < 75 ? '#dc2626' : '#16a34a' }}>
                      {student.attendance ? `${student.attendance}%` : '85%'}
                    </span>
                    {student.attendance && student.attendance < 75 && (
                      <span style={{ marginLeft: '6px', fontSize: '0.72rem', backgroundColor: '#fee2e2', color: '#b91c1c', padding: '2px 6px', borderRadius: '4px', fontWeight: 'bold' }}>
                        Shortage
                      </span>
                    )}
                  </td>
                  <td>
                    {student.hasUMC ? (
                      <span style={{ fontSize: '0.75rem', backgroundColor: '#fee2e2', color: '#b91c1c', padding: '3px 8px', borderRadius: '6px', fontWeight: 'bold' }}>
                        ⚖️ Active UMC
                      </span>
                    ) : (
                      <span style={{ fontSize: '0.75rem', color: '#16a34a', fontWeight: '600' }}>
                        ✓ Clear
                      </span>
                    )}
                  </td>
                  <td><Badge status={student.status} /></td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', justifyContent: 'center', marginTop: '16px' }}>
          <button className="btn-secondary" onClick={() => setPage((p) => p - 1)} disabled={currentPage === 1}>
            ← Prev
          </button>
          <span style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', fontWeight: '600' }}>
            Page {currentPage} of {totalPages} &nbsp;·&nbsp; {processed.length} mentee{processed.length !== 1 ? 's' : ''}
          </span>
          <button className="btn-secondary" onClick={() => setPage((p) => p + 1)} disabled={currentPage === totalPages}>
            Next →
          </button>
        </div>
      )}
    </div>
  );
}

export default StudentProgress;
