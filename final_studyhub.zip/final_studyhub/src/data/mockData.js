// LOGIN CREDENTIALS (COLLEGE LEVEL)=======================================================
export const DEMO_CREDENTIALS = {
  Student: { id: 'STU2026', password: 'password123', name: 'Aarav Sharma', class: 'B.Tech CSE - Sem 6', email: 'aarav@studysphere.edu' },
  Mentor: { id: 'MTR2026', password: 'password123', name: 'Dr. Ramesh Verma', class: 'Dept. of Computer Science', email: 'ramesh.verma@studysphere.edu' },
  Teacher: { id: 'MTR2026', password: 'password123', name: 'Dr. Ramesh Verma', class: 'Dept. of Computer Science', email: 'ramesh.verma@studysphere.edu' },
  Parent: { id: 'PAR2026', password: 'password123', name: 'Rajesh Sharma', class: 'Parent of Aarav (CSE)', email: 'rajesh.sharma@gmail.com' },
};

// STUDENT TASKS (COLLEGE SEMESTER)=========================================================
export const INITIAL_STUDENT_TASKS = [
  { id: 1, title: 'Revise State Variables for Foundations of Electrical Engineering (FEE)', completed: true },
  { id: 2, title: 'Complete full syllabus of Java & OOPS for Sessional Test 1 (ST-1)', completed: true },
  { id: 3, title: 'Solve Applied Probability & Statistics question bank', completed: false },
  { id: 4, title: 'Complete Coursera Cloud Architecture graded assignment', completed: false },
];

// STUDENT NOTES (COLLEGE ENGINEERING)======================================================
export const INITIAL_STUDENT_NOTES = [
  { id: 1, title: 'Database Normalization (1NF to BCNF)', content: '1NF: Atomic values only. 2NF: No partial dependency on candidate key. 3NF: No transitive dependencies. BCNF: For every FD X -> Y, X must be a super key.', date: '08/09/2026' },
  { id: 2, title: 'Operating Systems - Deadlock Prevention', content: 'Mutual Exclusion, Hold & Wait, No Preemption, Circular Wait. Banker\'s Algorithm calculates safe state with available and allocation matrices.', date: '01/08/2026' },
];

// MENTEE PROGRESS ROSTER (COLLEGE BATCH)====================================================
export const DEMO_STUDENTS_PROGRESS = [
  { id: 'STU2026', name: 'Aarav Sharma', roll: '22CS101', completion: 88, score: 92, status: 'Excellent', attendance: 70.9, hasUMC: true },
  { id: 'STU2027', name: 'Priya Patel', roll: '22CS102', completion: 82, score: 85, status: 'On track', attendance: 86.4, hasUMC: false },
  { id: 'STU2028', name: 'Rohan Gupta', roll: '22CS103', completion: 48, score: 58, status: 'Needs support', attendance: 64.0, hasUMC: false },
  { id: 'STU2029', name: 'Sneha Verma', roll: '22CS104', completion: 92, score: 96, status: 'Excellent', attendance: 94.2, hasUMC: false },
  { id: 'STU2030', name: 'Vikram Singh', roll: '22CS105', completion: 64, score: 68, status: 'On track', attendance: 78.5, hasUMC: false },
];

// SEMESTER COURSE MARKS====================================================================
export const DEMO_STUDENT_MARKS = [
  { id: 1, subject: 'FEE (Electrical Eng.)', obtained: 92, total: 100 },
  { id: 2, subject: 'Applied Statistics', obtained: 86, total: 100 },
  { id: 3, subject: 'OOPS in Java', obtained: 88, total: 100 },
  { id: 4, subject: 'DBMS & SQL', obtained: 90, total: 100 },
  { id: 5, subject: 'Coursera NPTEL Elective', obtained: 95, total: 100 },
];

// MENTOR FEEDBACK & GUIDANCE==============================================================
export const INITIAL_TEACHER_FEEDBACK = [
  { id: 1, studentName: 'Aarav Sharma', subject: 'DBMS & SQL', text: 'Exceptional database schema design in mini-project! Keep strengthening query indexing.', date: '2026-08-21' },
  { id: 2, studentName: 'Priya Patel', subject: 'Applied Statistics', text: 'Solid understanding of regression models. Ready for upcoming mid-term semester evaluations.', date: '2026-08-22' },
];

export const INITIAL_MENTOR_FEEDBACK = INITIAL_TEACHER_FEEDBACK;

// ============================================================================
// STUDENT CLASS ATTENDANCE & SHORTAGE METRICS (COLLEGE 75% MANDATE)
// ============================================================================
export const STUDENT_ATTENDANCE_SUMMARY = {
  totalConducted: 182,
  totalAttended: 129,
  totalAbsent: 53,
  overallPercentage: 70.9, // Below 75% threshold
  minimumRequired: 75.0,
  shortageCount: 8, // classes needed to reach 75%
  status: 'Critical Shortage', // 'Good' | 'Warning' | 'Critical Shortage'
  lastUpdated: '18 Oct 2026',
};

export const STUDENT_SUBJECT_ATTENDANCE = [
  {
    id: 'sub-1',
    code: 'CS-301',
    subject: 'DBMS & SQL',
    faculty: 'Dr. Ramesh Verma',
    conducted: 42,
    attended: 37,
    absent: 5,
    percentage: 88.1,
    status: 'Good',
    requiredClassesToReach75: 0,
    allowBunk: 7, // can miss 7 classes safely
  },
  {
    id: 'sub-2',
    code: 'MA-302',
    subject: 'Applied Statistics',
    faculty: 'Prof. Sunita Rao',
    conducted: 40,
    attended: 25,
    absent: 15,
    percentage: 62.5, // Severe shortage!
    status: 'Debarred Warning',
    requiredClassesToReach75: 20, // Must attend next 20 consecutive classes
    allowBunk: 0,
  },
  {
    id: 'sub-3',
    code: 'CS-303',
    subject: 'OOPS in Java',
    faculty: 'Prof. Amit Kulkarni',
    conducted: 38,
    attended: 32,
    absent: 6,
    percentage: 84.2,
    status: 'Good',
    requiredClassesToReach75: 0,
    allowBunk: 4,
  },
  {
    id: 'sub-4',
    code: 'EE-304',
    subject: 'FEE (Electrical Eng.)',
    faculty: 'Dr. Harish Chandra',
    conducted: 36,
    attended: 24,
    absent: 12,
    percentage: 66.7, // Shortage!
    status: 'Shortage Warning',
    requiredClassesToReach75: 12,
    allowBunk: 0,
  },
  {
    id: 'sub-5',
    code: 'CS-305L',
    subject: 'Database Systems Lab',
    faculty: 'Er. Neha Gupta',
    conducted: 14,
    attended: 13,
    absent: 1,
    percentage: 92.9,
    status: 'Good',
    requiredClassesToReach75: 0,
    allowBunk: 2,
  },
  {
    id: 'sub-6',
    code: 'OE-306',
    subject: 'Coursera NPTEL Elective',
    faculty: 'Online Academic Cell',
    conducted: 12,
    attended: 11,
    absent: 1,
    percentage: 91.7,
    status: 'Good',
    requiredClassesToReach75: 0,
    allowBunk: 2,
  },
];

export const STUDENT_RECENT_ATTENDANCE_LOG = [
  { id: 1, date: '18 Oct 2026', time: '09:00 - 10:00 AM', subject: 'Applied Statistics', faculty: 'Prof. Sunita Rao', status: 'Absent', room: 'LH-201', remarks: 'Uninformed absence' },
  { id: 2, date: '18 Oct 2026', time: '10:15 - 11:15 AM', subject: 'DBMS & SQL', faculty: 'Dr. Ramesh Verma', status: 'Present', room: 'LH-203', remarks: 'Active participation' },
  { id: 3, date: '17 Oct 2026', time: '02:00 - 04:00 PM', subject: 'Database Systems Lab', faculty: 'Er. Neha Gupta', status: 'Present', room: 'CS-Lab 3', remarks: 'Completed Task 4' },
  { id: 4, date: '16 Oct 2026', time: '11:30 - 12:30 PM', subject: 'FEE (Electrical Eng.)', faculty: 'Dr. Harish Chandra', status: 'Absent', room: 'LH-105', remarks: 'Missed pop quiz' },
  { id: 5, date: '15 Oct 2026', time: '09:00 - 10:00 AM', subject: 'Applied Statistics', faculty: 'Prof. Sunita Rao', status: 'Absent', room: 'LH-201', remarks: 'Consecutive absence' },
  { id: 6, date: '14 Oct 2026', time: '01:00 - 02:00 PM', subject: 'OOPS in Java', faculty: 'Prof. Amit Kulkarni', status: 'Present', room: 'LH-204', remarks: 'Present on time' },
];

// ============================================================================
// DISCIPLINARY ACTIONS & UMC (UNFAIR MEANS CASE) OFFICIAL RECORDS
// ============================================================================
export const STUDENT_UMC_DISCIPLINE_RECORDS = [
  {
    id: 'UMC-2026-OCT-042',
    caseType: 'UMC (Unfair Means Case)',
    severity: 'High / Critical',
    incidentDate: '12 Oct 2026',
    examination: 'Mid-Term Sessional Test (ST-1)',
    subject: 'Applied Statistics (MA-302)',
    examHall: 'Exam Hall C-102 (Seat 44)',
    reportedBy: 'Prof. V. K. Taneja (Center Invigilator)',
    charges: 'Possession of unauthorized handwritten formula notes / cheat sheet during the mid-term examination.',
    committeeVerdict: 'Proctorial Board & Examination Malpractice Committee reviewed the confiscated material and CCTV footage on 14 Oct 2026. Student admitted to the infraction.',
    actionTaken: 'Paper ST-1 for Applied Statistics marked as CANCELLED with 0 Marks awarded. Formal disciplinary censure recorded in the university student file.',
    currentStatus: 'Active Penalty Imposed', // 'Active Penalty Imposed' | 'Resolved / Cleared' | 'Under Investigation'
    parentActionRequired: 'Mandatory parent-proctor conference required before the End-Semester Admit Card can be released. Scheduled with Faculty Mentor Dr. Ramesh Verma.',
    clearedForAdmitCard: false,
    issuedBy: 'Office of the Controller of Examinations & Chief Proctor',
  },
  {
    id: 'DISC-2026-SEP-018',
    caseType: 'Attendance Proxy Warning',
    severity: 'Moderate',
    incidentDate: '24 Sep 2026',
    examination: 'Regular Lecture Session',
    subject: 'FEE (Electrical Eng.)',
    examHall: 'Lecture Hall LH-105',
    reportedBy: 'Dr. Harish Chandra',
    charges: 'Student was marked present via biometric proxy while physically absent during the first hour of class.',
    committeeVerdict: 'First warning issued under Section 4.2 of College Code of Student Conduct.',
    actionTaken: 'Two attendance points deducted; formal warning email dispatched to registered parent contact.',
    currentStatus: 'Closed Warning',
    parentActionRequired: 'Acknowledged by parent on 26 Sep 2026.',
    clearedForAdmitCard: true,
    issuedBy: 'Department Proctorial Committee (CSE)',
  },
];

// ============================================================================
// COMPREHENSIVE 360° STUDENT DOSSIER (EVERY DETAIL FOR PARENTS)
// ============================================================================
export const STUDENT_COMPREHENSIVE_DOSSIER = {
  personal: {
    fullName: 'Aarav Sharma',
    photoUrl: null,
    dob: '14 July 2004',
    gender: 'Male',
    bloodGroup: 'B+',
    universityRollNo: '22CS101',
    registrationNo: 'REG2022-CSE-09842',
    program: 'Bachelor of Technology (B.Tech)',
    department: 'Computer Science & Engineering',
    specialization: 'Artificial Intelligence & Data Engineering',
    semester: 'Semester 6 (3rd Year)',
    section: 'CSE-A',
    batch: '2023 - 2027',
    admissionCategory: 'Merit / JEE Mains',
    residentialStatus: 'Day Scholar (College Transport Bus Route #14)',
  },
  academicStanding: {
    cgpa: 8.72,
    sgpaLastSem: 8.45,
    rankInBatch: '4 / 120 Students',
    totalCreditsRequired: 160,
    creditsEarnedToDate: 114,
    currentSemCredits: 24,
    backlogs: 0,
    academicStatus: 'Good Academic Standing (With Disciplinary Notice)',
  },
  mentor: {
    name: 'Dr. Ramesh Verma',
    designation: 'Associate Professor & Batch Mentor',
    department: 'Dept. of Computer Science & Engineering',
    cabin: 'Room B-304, Block 2, Third Floor',
    email: 'ramesh.verma@studysphere.edu',
    phone: '+91 98765 43210',
    consultationHours: 'Monday - Thursday, 3:00 PM - 5:00 PM',
  },
  parentContact: {
    fatherName: 'Mr. Rajesh Sharma',
    fatherOccupation: 'Senior Project Manager, IT Solutions',
    motherName: 'Mrs. Sunita Sharma',
    registeredPhone: '+91 98111 22334',
    registeredEmail: 'rajesh.sharma@gmail.com',
    emergencyContact: '+91 98111 22335',
    permanentAddress: 'H-42, Shivalik Enclave, Sector 21, New Delhi - 110025',
  },
  institutionalClearances: {
    tuitionFeeStatus: 'Paid in Full (Receipt #TUI-2026-6140)',
    examinationFeeStatus: 'Paid (₹ 3,500)',
    libraryDues: 'Clear (0 books overdue)',
    laboratoryClearance: 'Approved (All lab files submitted)',
    admitCardStatus: 'ON HOLD — Pending Parent UMC Meeting & Attendance Shortage Rectification',
    disciplinaryClearance: 'Action Required (Active UMC Case on file)',
  },
};

// ============================================================================
// FACULTY QUIZZES & ASSESSMENTS (ASSIGNED TO STUDENTS)
// ============================================================================
export const INITIAL_COLLEGE_QUIZZES = [
  {
    id: 'quiz-1',
    title: 'Database Normalization & BCNF Mini-Quiz',
    subject: 'DBMS & SQL',
    mentorName: 'Dr. Ramesh Verma',
    mentorRole: 'Associate Professor & Batch Mentor',
    targetAudience: 'All Students',
    durationMinutes: 10,
    totalMarks: 30,
    dueDate: '2026-10-25',
    createdAt: '2026-10-18',
    status: 'Published',
    description: 'Assess your conceptual understanding of Functional Dependencies, 3NF, BCNF, and lossless decomposition prior to Sessional Test 2.',
    questions: [
      {
        id: 'q1',
        questionText: 'A relation R is considered to be in Boyce-Codd Normal Form (BCNF) if for every non-trivial functional dependency X -> Y:',
        options: [
          'X is a super key of relation R',
          'Y is a prime attribute belonging to any candidate key',
          'X is a single attribute candidate key',
          'Y is functionally determined by a foreign key',
        ],
        correctIndex: 0,
        explanation: 'The strict condition for BCNF states that for every functional dependency X -> Y, the determinant X must be a super key.',
      },
      {
        id: 'q2',
        questionText: 'Which ACID property guarantees that all transactions are committed permanently even if the database server crashes immediately after commit?',
        options: [
          'Atomicity',
          'Consistency',
          'Isolation',
          'Durability',
        ],
        correctIndex: 3,
        explanation: 'Durability ensures that once a transaction has completed and committed, its log records ensure the updates persist across system crashes.',
      },
      {
        id: 'q3',
        questionText: 'Which relational algebra operation corresponds directly to the SQL "SELECT DISTINCT column_name" projection query?',
        options: [
          'Selection (σ)',
          'Projection (π)',
          'Cartesian Product (×)',
          'Set Difference (-)',
        ],
        correctIndex: 1,
        explanation: 'Projection (represented by Greek letter π) outputs only the specified columns and eliminates duplicate tuples in pure relational algebra.',
      },
    ],
  },
  {
    id: 'quiz-2',
    title: 'Applied Statistics: Probability & Hypothesis Testing',
    subject: 'Applied Statistics',
    mentorName: 'Prof. Sunita Rao',
    mentorRole: 'Assistant Professor, Mathematics Dept.',
    targetAudience: 'All Students',
    durationMinutes: 12,
    totalMarks: 20,
    dueDate: '2026-10-28',
    createdAt: '2026-10-19',
    status: 'Published',
    description: 'Mandatory revision quiz covering Normal Distributions, Z-scores, Type I/II errors, and p-value significance.',
    questions: [
      {
        id: 'q1',
        questionText: 'If the null hypothesis is rejected when it is actually true in reality, what type of statistical error has occurred?',
        options: [
          'Type I Error (False Positive)',
          'Type II Error (False Negative)',
          'Sampling Bias Error',
          'Standard Deviation Deficit',
        ],
        correctIndex: 0,
        explanation: 'A Type I error occurs when researchers reject a true null hypothesis (commonly denoted by significance level alpha α).',
      },
      {
        id: 'q2',
        questionText: 'According to the Central Limit Theorem (CLT), the sampling distribution of the sample mean approaches what distribution as sample size n grows large?',
        options: [
          'Uniform Distribution',
          'Poisson Distribution',
          'Normal (Gaussian) Distribution',
          'Exponential Distribution',
        ],
        correctIndex: 2,
        explanation: 'CLT states that regardless of the population distribution, sample means will be normally distributed if n is sufficiently large (typically n >= 30).',
      },
    ],
  },
];

// INITIAL STUDENT QUIZ ATTEMPTS & SUBMISSIONS
export const INITIAL_QUIZ_SUBMISSIONS = [
  {
    quizId: 'quiz-1',
    studentId: 'STU2026',
    studentName: 'Aarav Sharma',
    studentRoll: '22CS101',
    score: 30,
    totalMarks: 30,
    percentage: 100,
    submittedAt: '2026-10-18 16:45',
    answers: { q1: 0, q2: 3, q3: 1 },
    timeTakenSeconds: 340,
  },
];


