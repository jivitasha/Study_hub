import React from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * NotFound — 404 page shown for unmatched routes.
 * Uses existing card + btn-primary CSS classes.
 */
function NotFound() {
  const navigate = useNavigate();

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'var(--bg-cream)',
      }}
    >
      <div className="card" style={{ textAlign: 'center', maxWidth: '420px' }}>
        <div style={{ fontSize: '4rem', marginBottom: '12px' }}>📚</div>
        <h1 style={{ color: 'var(--primary-dark)', fontSize: '2rem', marginBottom: '8px' }}>
          404 — Page Not Found
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '24px' }}>
          Oops! The page you are looking for does not exist or has been moved.
        </p>
        <button className="btn-primary" onClick={() => navigate(-1)}>
          ← Go Back
        </button>
      </div>
    </div>
  );
}

export default NotFound;
