import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export const STORAGE_KEY = 'studysphere_users';
export const CURRENT_USER_KEY = 'studysphere_current_user';

// ==============================================================================
// CLIENT-SIDE PASSWORD SECURITY (FRONTEND DEMO ONLY)
// ==============================================================================
// In accordance with security best practices, we never store plaintext passwords
// in localStorage. We hash passwords client-side using a salted SHA-256 algorithm.
//
// ⚠️ LIMITATION & SECURITY NOTICE:
// StudySphere currently operates as a frontend-only educational demo without a
// backend server or database. While salted client-side hashing prevents plaintext
// password exposure in browser storage, true production security requires an
// authoritative backend with bcrypt/argon2 hashing, secure HTTP-only cookies,
// CSRF protection, and server-side session validation.
// ==============================================================================

function sha256(ascii) {
  function rightRotate(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
  }
  const mathPow = Math.pow;
  const maxWord = mathPow(2, 32);
  const lengthProperty = 'length';
  let i, j;
  let result = '';

  const words = [];
  const asciiBitLength = ascii[lengthProperty] * 8;

  let hash = [];
  const k = [];
  let primeCounter = 0;

  const isComposite = {};
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isComposite[candidate]) {
      for (i = 0; i < 313; i += candidate) {
        isComposite[i] = candidate;
      }
      hash[primeCounter] = (mathPow(candidate, 0.5) * maxWord) | 0;
      k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
    }
  }

  ascii += '\x80';
  while ((ascii[lengthProperty] % 64) - 56) ascii += '\x00';
  for (i = 0; i < ascii[lengthProperty]; i++) {
    j = ascii.charCodeAt(i);
    if (j >> 8) return '';
    words[i >> 2] |= j << ((3 - (i % 4)) * 8);
  }
  words[words[lengthProperty]] = (asciiBitLength / maxWord) | 0;
  words[words[lengthProperty]] = asciiBitLength;

  for (j = 0; j < words[lengthProperty]; ) {
    const w = words.slice(j, (j += 16));
    const oldHash = hash.slice(0, 8);
    for (i = 0; i < 64; i++) {
      const w15 = w[i - 15];
      const w2 = w[i - 2];
      const a = hash[0];
      const e = hash[4];
      const temp1 =
        hash[7] +
        (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) +
        ((e & hash[5]) ^ (~e & hash[6])) +
        k[i] +
        (w[i] =
          i < 16
            ? w[i]
            : (w[i - 16] +
                (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) +
                w[i - 7] +
                (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) |
              0);
      const temp2 =
        (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) +
        ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));

      hash = [(temp1 + temp2) | 0].concat(hash);
      hash[4] = (hash[4] + temp1) | 0;
    }
    for (i = 0; i < 8; i++) {
      hash[i] = (hash[i] + oldHash[i]) | 0;
    }
  }

  for (i = 0; i < 8; i++) {
    for (j = 3; j + 1; j--) {
      const b = (hash[i] >> (j * 8)) & 255;
      result += (b < 16 ? 0 : '') + b.toString(16);
    }
  }
  return result;
}

const PASSWORD_SALT = 'studysphere_salt_v1_';

export function hashPassword(plainPassword) {
  if (!plainPassword) return '';
  return sha256(PASSWORD_SALT + plainPassword);
}

// Seed initial default accounts with hashed credentials (never plaintext)
export const DEFAULT_INITIAL_USERS = [
  {
    name: 'Aarav Sharma',
    email: 'aarav@studysphere.edu',
    password: hashPassword('password123'),
    role: 'Student',
    id: 'STU2026',
    class: 'B.Tech CSE - Semester 6',
  },
  {
    name: 'Dr. Ramesh Verma',
    email: 'ramesh@studysphere.edu',
    password: hashPassword('password123'),
    role: 'Mentor',
    id: 'MTR2026',
    department: 'Computer Science & Engineering',
  },
  {
    name: 'Dr. Ramesh Verma',
    email: 'ramesh.verma@studysphere.edu',
    password: hashPassword('password123'),
    role: 'Mentor',
    id: 'MTR2027',
    department: 'Computer Science & Engineering',
  },
  {
    name: 'Rajesh Sharma',
    email: 'rajesh@studysphere.edu',
    password: hashPassword('password123'),
    role: 'Parent',
    id: 'PAR2026',
  },
  {
    name: 'Rajesh Sharma',
    email: 'rajesh.sharma@gmail.com',
    password: hashPassword('password123'),
    role: 'Parent',
    id: 'PAR2027',
  },
];

export function getStoredUsers() {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_INITIAL_USERS));
      return DEFAULT_INITIAL_USERS;
    }
    const parsed = JSON.parse(data) || [];
    let needsUpdate = false;
    const normalized = parsed.map((u) => {
      let updatedUser = { ...u };
      // Normalize legacy Teacher role to Mentor
      if (updatedUser.role === 'Teacher') {
        updatedUser.role = 'Mentor';
        needsUpdate = true;
      }
      // Migrate any legacy plaintext password to salted hash
      if (
        updatedUser.password &&
        (updatedUser.password.length !== 64 || !/^[0-9a-f]{64}$/i.test(updatedUser.password))
      ) {
        updatedUser.password = hashPassword(updatedUser.password);
        needsUpdate = true;
      }
      return updatedUser;
    });

    if (needsUpdate) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    }
    return normalized;
  } catch (err) {
    console.error('Error accessing stored users:', err);
    return DEFAULT_INITIAL_USERS;
  }
}

export function saveUsers(users) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Error saving users to storage:', err);
  }
}

export function AuthProvider({ children }) {
  // Initialize current user from persisted session in localStorage
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem(CURRENT_USER_KEY);
      if (saved) {
        const u = JSON.parse(saved);
        if (u.role === 'Teacher') u.role = 'Mentor';
        // Ensure passwords are never stored in active session
        delete u.password;
        return u;
      }
      return null;
    } catch {
      return null;
    }
  });

  const [userRole, setUserRole] = useState(() => {
    return currentUser?.role || null;
  });

  // Sync session changes to localStorage (excluding passwords)
  useEffect(() => {
    if (currentUser) {
      const { password: _, ...safeUser } = currentUser;
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(safeUser));
      setUserRole(currentUser.role);
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
      setUserRole(null);
    }
  }, [currentUser]);

  // Synchronize authentication state across browser tabs
  useEffect(() => {
    const handleStorageChange = (e) => {
      if (e.key === CURRENT_USER_KEY) {
        try {
          if (e.newValue) {
            const u = JSON.parse(e.newValue);
            delete u.password;
            setCurrentUser(u);
            setUserRole(u.role);
          } else {
            setCurrentUser(null);
            setUserRole(null);
          }
        } catch {
          // fallback
        }
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  /**
   * register — persists a new user account with hashed password in localStorage.
   */
  const register = ({ name, email, password, role }) => {
    if (!name?.trim() || !email?.trim() || !password || !role) {
      return { ok: false, message: 'All fields (Name, Email, Password, Role) are required.' };
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();

    if (!/\S+@\S+\.\S+/.test(cleanEmail)) {
      return { ok: false, message: 'Please enter a valid email address.' };
    }

    if (password.length < 6) {
      return { ok: false, message: 'Password must be at least 6 characters.' };
    }

    const users = getStoredUsers();
    const exists = users.some((u) => u.email.toLowerCase() === cleanEmail);
    if (exists) {
      return {
        ok: false,
        message: 'An account with this email already exists. Please log in or use another email.',
      };
    }

    const normalizedRole = role === 'Teacher' ? 'Mentor' : role;
    const prefix = normalizedRole === 'Mentor' ? 'MTR' : normalizedRole.toUpperCase().slice(0, 3);
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);

    const newUser = {
      name: cleanName,
      email: cleanEmail,
      password: hashPassword(password),
      role: normalizedRole,
      id: `${prefix}${randomSuffix}`,
      class: normalizedRole === 'Student' ? 'B.Tech CSE - Semester 6' : undefined,
      department: normalizedRole === 'Mentor' ? 'Computer Science & Engineering' : undefined,
    };

    saveUsers([...users, newUser]);

    const { password: _, ...safeUser } = newUser;
    return { ok: true, user: safeUser };
  };

  /**
   * login — validates email, password, and role against stored accounts.
   */
  const login = (role, { email, password }) => {
    if (!email?.trim() || !password) {
      return { ok: false, message: 'Email and password are required.' };
    }

    const cleanEmail = email.trim().toLowerCase();
    const targetRole = role === 'Teacher' ? 'Mentor' : role;
    const users = getStoredUsers();

    // 1. Check if user exists
    const account = users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!account) {
      return {
        ok: false,
        message: `No account found for ${cleanEmail}. Please verify the email or sign up.`,
      };
    }

    // 2. Check password against salted hash (with backward-compatibility)
    const inputHash = hashPassword(password);
    const isPasswordValid = account.password === inputHash || account.password === password;
    if (!isPasswordValid) {
      return {
        ok: false,
        message: 'Invalid password. Please check your credentials and try again.',
      };
    }

    // 3. Check role mismatch
    const accountRole = account.role === 'Teacher' ? 'Mentor' : account.role;
    if (accountRole !== targetRole) {
      return {
        ok: false,
        message: `Role mismatch: This account is registered as ${accountRole}, not ${targetRole}. Please select the ${accountRole} tab to sign in.`,
      };
    }

    // 4. Session established: user logged in (without password in state/session storage)
    const { password: _, ...safeUser } = account;
    const authenticatedUser = { ...safeUser, role: targetRole };
    try {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(authenticatedUser));
    } catch (err) {
      console.error('Failed to persist active session to localStorage:', err);
    }
    setCurrentUser(authenticatedUser);
    setUserRole(targetRole);
    return { ok: true, user: authenticatedUser };
  };

  /**
   * logout — clears the active user session without deleting registered accounts.
   */
  const logout = () => {
    setCurrentUser(null);
    setUserRole(null);
    try {
      localStorage.removeItem(CURRENT_USER_KEY);
    } catch {
      // storage access error
    }
  };

  return (
    <AuthContext.Provider value={{ currentUser, userRole, login, logout, register, getStoredUsers }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
