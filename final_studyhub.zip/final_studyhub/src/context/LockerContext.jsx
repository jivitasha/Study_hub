import React, { createContext, useContext, useState, useEffect } from 'react';

const LOCKER_STORAGE_KEY = 'studysphere_study_locker';

const LockerContext = createContext();

export function LockerProvider({ children }) {
  const [lockerItems, setLockerItems] = useState(() => {
    try {
      const saved = localStorage.getItem(LOCKER_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem(LOCKER_STORAGE_KEY, JSON.stringify(lockerItems));
  }, [lockerItems]);

  // Sync across tabs/windows
  useEffect(() => {
    const handleStorage = () => {
      try {
        const saved = localStorage.getItem(LOCKER_STORAGE_KEY);
        if (saved) setLockerItems(JSON.parse(saved));
      } catch {
        // fallback
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const addToLocker = (item) => {
    setLockerItems((prev) => {
      if (prev.some((i) => i.id === item.id)) return prev;
      return [item, ...prev];
    });
  };

  const removeFromLocker = (itemId) => {
    setLockerItems((prev) => prev.filter((i) => i.id !== itemId));
  };

  const clearLocker = () => {
    setLockerItems([]);
  };

  const isInLocker = (itemId) => {
    return lockerItems.some((i) => i.id === itemId);
  };

  return (
    <LockerContext.Provider
      value={{
        lockerItems,
        totalCount: lockerItems.length,
        addToLocker,
        removeFromLocker,
        clearLocker,
        isInLocker,
      }}
    >
      {children}
    </LockerContext.Provider>
  );
}

export function useLocker() {
  const context = useContext(LockerContext);
  if (!context) {
    throw new Error('useLocker must be used within a LockerProvider');
  }
  return context;
}

export default LockerContext;
