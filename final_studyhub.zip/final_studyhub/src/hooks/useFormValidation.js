import { useState, useCallback } from 'react';

/**
 * Custom hook for React form handling & validation strategies (Modules 55-60)
 * Handles:
 * - Form state tracking
 * - Validation rules (required, minLength, email format, pattern, custom match)
 * - Touched field blur states
 * - Error reporting and clearing
 */
export function useFormValidation(initialValues = {}, validationRules = {}) {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  // Validate a single field
  const validateField = useCallback((name, value, allValues = values) => {
    const rules = validationRules[name];
    if (!rules) return '';

    if (rules.required && (!value || String(value).trim() === '')) {
      return rules.requiredMessage || `${rules.label || name} is required.`;
    }

    if (rules.minLength && String(value).trim().length < rules.minLength) {
      return `${rules.label || name} must be at least ${rules.minLength} characters.`;
    }

    if (rules.isEmail) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(String(value).trim())) {
        return 'Please enter a valid academic/personal email address.';
      }
    }

    if (rules.matchField) {
      if (value !== allValues[rules.matchField]) {
        return rules.matchMessage || `Does not match ${rules.matchField}.`;
      }
    }

    if (rules.custom && typeof rules.custom === 'function') {
      const customErr = rules.custom(value, allValues);
      if (customErr) return customErr;
    }

    return '';
  }, [validationRules, values]);

  // Handle input change
  const handleChange = useCallback((e) => {
    const { name, value } = e.target;
    setValues((prev) => {
      const updated = { ...prev, [name]: value };
      // Real-time error clearance
      const fieldError = validateField(name, value, updated);
      setErrors((prevErr) => ({ ...prevErr, [name]: fieldError }));
      return updated;
    });
  }, [validateField]);

  // Handle blur
  const handleBlur = useCallback((e) => {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const fieldError = validateField(name, value, values);
    setErrors((prev) => ({ ...prev, [name]: fieldError }));
  }, [validateField, values]);

  // Validate all fields (on submit)
  const validateAll = useCallback(() => {
    const newErrors = {};
    const newTouched = {};

    Object.keys(validationRules).forEach((field) => {
      newTouched[field] = true;
      const err = validateField(field, values[field], values);
      if (err) newErrors[field] = err;
    });

    setTouched(newTouched);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [validationRules, validateField, values]);

  // Reset form
  const resetForm = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
  }, [initialValues]);

  return {
    values,
    errors,
    touched,
    setValues,
    handleChange,
    handleBlur,
    validateAll,
    resetForm,
  };
}

export default useFormValidation;
